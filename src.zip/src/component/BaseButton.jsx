import React from 'react'

export default function BaseButton({content, bgColor,color,px, py, bRad, bgHv, onClick}) {
  return (
    <button
        onClick={onClick}
        className={'cu-po bd-2-solid-black trans-0.dot4s ' + (bgHv == 'white' ? 'hv-white-btn': "hv-black-btn")}
        style={{
            backgroundColor: bgColor,
            color,
            paddingLeft: px,
            paddingRight: px,
            paddingTop: py,
            paddingBottom: py,
            borderRadius: bRad,
            fontWeight: 'bolder',
        }}
    >
        {content}
    </button>
  )
}
