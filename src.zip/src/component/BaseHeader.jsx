/* eslint-disable jsx-a11y/anchor-is-valid */
import { DownOutlined, UnorderedListOutlined } from "@ant-design/icons";
import { Col, Dropdown, Menu, Row, Space } from "antd";
import React, { useEffect, useState } from "react";
import ohm from "../asset/img/crystal-blue.png";
import BaseButton from "./BaseButton";
const onClick = ({ key }) => {
  // message.info(`Click on item ${key}`);
};
const menu = (
  <Menu
    onClick={onClick}
    items={[
      {
        label: (
          <a target="_blank" rel="noopener noreferrer" href="/usdg-pro">
            Institutional
          </a>
        ),
        key: "1",
      },
      {
        label: (
          <a target="_blank" rel="noopener noreferrer" href="/incubator">
            Ventures
          </a>
        ),
        key: "2",
      },
      {
        label: (
          <a target="_blank" rel="noopener noreferrer" href="/grants">
            Charity
          </a>
        ),
        key: "3",
      },
    ]}
  />
);

export default function BaseHeader({ color = "black", size }) {
  const [openMenuMobile, setOpenMenuMobile] = useState(false);
  useEffect(()=>{
    if(size == 'lg' || size == 'xl'){
      setOpenMenuMobile(false)
      setPaddingHor('pd-hor-3rem')
      setPaddingVer('pd-ver-5rem')
    }
    else if(size == 'md'){
      setPaddingHor('pd-hor-2rem')
      setPaddingVer('pd-ver-20')
    }
    else if(size == 'sm' || size == 'xs'){
      setPaddingHor('pd-hor-1rem')
      setPaddingVer('pd-ver-20')
    }
  }, [size])

  const [paddingHor, setPaddingHor] = useState('pd-hor-3rem')
  const [paddingVer, setPaddingVer] = useState('pd-ver-5rem')
  const menuMobile = () => (
    <Space
      size={30}
      className="fs-1rem w-100p"
      style={{
        position: "fixed",
        zIndex: 10,
        background: "#EFE9E0",
        transition: "0.4s",
        height: openMenuMobile ? 800 : 0,
        overflow: "hidden",
      }}
    >
      <Space
        direction="vertical"
        className="h-100p w-100p fs-2rem"
        style={{ height: 800, width: "100%" }}
        size={25}
      >
        <a
          href="/dao/stake"
          className={`cl-${color} fw-900 header-hover trans-0dot4s`}
        >
          STAKE
        </a>
        <a
          href="/dao/bond"
          className={`cl-${color} fw-900 header-hover trans-0dot4s`}
        >
          BOND
        </a>
        {/* <a href="#" className={`cl-${color} fw-900 header-hover trans-0dot4s`}>
        BOND
      </a> */}
        {/* <a
          href="/ecosystem"
          className={`cl-${color} fw-900 header-hover trans-0dot4s`}
        >
          ECOSYSTEM
        </a> */}
        <a href="#" className={`cl-${color} fw-900 header-hover trans-0dot4s`}>
          <Dropdown overlay={menu}>
            {/* <a onClick={(e) => e.preventDefault()}> */}
            <Space>
              INITIATIVES
              <DownOutlined />
            </Space>
            {/* </a> */}
          </Dropdown>
        </a>
        <a href="#" className={`cl-${color} fw-900 header-hover trans-0dot4s`}>
          LEARN
        </a>
        <a
          href="/transparency"
          className={`cl-${color} fw-900 header-hover trans-0dot4s`}
        >
          TRANSPARENCY
        </a>
        <a href="#" className={`cl-${color} fw-900 header-hover trans-0dot4s`}>
          GOVERNANCE
        </a>
      </Space>
    </Space>
  );
  return (
    <header className={`${paddingHor} w-100p ${paddingVer} cl-${color}`}>
      <Row align="middle" justify="space-between">
        <Col>
          <a href="/" className={`head-flex cl-${color} fw-900  trans-0dot4s`}>
            <img
              src={ohm}
              alt=""
              style={{ height: 24, backgroundColor: 'transparent' }}
              className="item-head"
            />
            <span className="fw-900 fs-1dot2rem mg-0 pd-0 item-head">CRYSTAL</span>
          </a>
        </Col>
        {size == "lg" || size == "xl" && (
          <Col>
            <Space size={30} className="fs-1rem">
              <a
                href="/dao/stake"
                className={`cl-${color} fw-900 header-hover trans-0dot4s`}
              >
                STAKE
              </a>
              <a
                href="/dao/bond"
                className={`cl-${color} fw-900 header-hover trans-0dot4s`}
              >
                BOND
              </a>
              {/* <a href="#" className={`cl-${color} fw-900 header-hover trans-0dot4s`}>
              BOND
            </a> */}
              {/* <a
                href="/ecosystem"
                className={`cl-${color} fw-900 header-hover trans-0dot4s`}
              >
                ECOSYSTEM
              </a> */}
              <a
                href="#"
                className={`cl-${color} fw-900 header-hover trans-0dot4s`}
              >
                <Dropdown overlay={menu}>
                  {/* <a onClick={(e) => e.preventDefault()}> */}
                  <Space>
                    INITIATIVES
                    <DownOutlined />
                  </Space>
                  {/* </a> */}
                </Dropdown>
              </a>
              <a
                href="#"
                className={`cl-${color} fw-900 header-hover trans-0dot4s`}
              >
                LEARN
              </a>
              <a
                href="/transparency"
                className={`cl-${color} fw-900 header-hover trans-0dot4s`}
              >
                TRANSPARENCY
              </a>
              <a
                href="#"
                className={`cl-${color} fw-900 header-hover trans-0dot4s`}
              >
                GOVERNANCE
              </a>
              <BaseButton
                bgHv="white"
                content="ENTER APP"
                bgColor="black"
                color="white"
                px={10}
                py={8}
                bRad={20}
              />
            </Space>
          </Col>
        )}
        {size !== "lg" && size !== "xl" && (
          <Row align="middle" gutter={16}>
            <Col>
              <BaseButton
                bgHv="white"
                content={<UnorderedListOutlined />}
                bgColor="transparent"
                color="black"
                px={20}
                py={8}
                bRad={20}
                onClick={() => setOpenMenuMobile(!openMenuMobile)}
              />
            </Col>
            <Col>
              <BaseButton
                bgHv="white"
                content="ENTER APP"
                bgColor="black"
                color="white"
                px={10}
                py={8}
                bRad={20}
              />
            </Col>
          </Row>
        )}
      </Row>
      {size !== 'lg' && size !== "xl" && menuMobile()}
    </header>
  );
}
