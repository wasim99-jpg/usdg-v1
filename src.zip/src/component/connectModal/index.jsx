import CloseIcon from "@mui/icons-material/Close";
import DownloadIcon from "@mui/icons-material/Download";
import Alert from "@mui/material/Alert";
import AlertTitle from "@mui/material/AlertTitle";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Modal from "@mui/material/Modal";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import { useWeb3React } from "@web3-react/core";
import { useConnectWallet } from "customhook/useConnectWallet";
import { useAppSelector } from "customhook/useStore";
import React, { useEffect, useState } from "react";
import { useCookies } from "react-cookie";
import ReactLoading from "react-loading";
import { connect, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { selectIsWrongNetWork } from "redux/connectionSlice/selector";
import { getVerifyAdminStart } from "redux/connectionSlice/slice";
import { showMessage } from "redux/layout/slice";
import BaseWalletService from "service/BaseWalletService";
import { isSupportChainId } from "utils/helper";
import cbw from "../../assets/cbw.png";
import mm from "../../assets/mm.png";
import wc from "../../assets/wc.png";
import { modalStyle } from "../../theme";

const ConnectModal = ({ isOpen, onModalClose }) => {
  const wallet = new BaseWalletService();
  const dispatch = useDispatch();
  const { library, account, chainId, active,deactivate } = useWeb3React();
  const { connectInjected } = useConnectWallet();
  const isWrongNetWork = useAppSelector(selectIsWrongNetWork);
  const [cookies, setCookie] = useCookies(["provider","token"]);
  const [connecting, setConnecting] = useState(false);
  const [metamaskUnavalible, setMetaMaskUnavalible] = useState(false);
  const [signing, setSigning] = useState(false);
  const redirect = useNavigate();

  const authorize = async () => {
    const signature = await wallet.getSignature(account, library);
    dispatch(getVerifyAdminStart({ address: account, signature, redirect }))
  };

  useEffect(() => {
    if (account && active && isSupportChainId(chainId)) {
      setSigning(true)
      authorize().then(()=>null).catch((error)=>{
        dispatch(showMessage({
          type:'error',
          content: error.message
        }))
        deactivate();
        onModalClose();
        setConnecting(false);
      });;
    }
  }, [account, chainId, active]);

  const handleConnect = async () => {
    setConnecting(true);
    connectInjected({
      callbackError: (error) => {
        if (error.name === "UserRejectedRequestError") {
          alert(error.message);
        } else {
          setMetaMaskUnavalible(true);
        }
        setConnecting(false);
      },
    });
  };

  useEffect(() => {
    if (active) {
      setCookie("provider", "injected");
    }
  }, [chainId, cookies.provider, active]);

  return (
    <Modal open={isOpen}>
      <Box
        sx={{
          ...modalStyle,
          width: 320,
        }}
      >
        <IconButton
          aria-label="close"
          sx={{ position: "absolute", right: 8, top: 8 }}
          onClick={() => {
            onModalClose();
            setConnecting(false);
            deactivate()
          }}
        >
          <CloseIcon />
        </IconButton>
        <Typography variant="h6" component="h2">
          Select Wallet
        </Typography>
        <Stack
          spacing={2}
          sx={{
            py: 2,
            img: {
              width: 32,
              height: 32,
            },
          }}
        >
          <Button
            variant="outlined"
            startIcon={<img src={cbw} alt="cbw" />}
            disabled
          >
            Coinbase Wallet
          </Button>
          <Button
            variant="outlined"
            startIcon={<img src={wc} alt="wc" />}
            disabled
          >
            Wallet Connect
          </Button>
          <Button
            disabled={connecting || metamaskUnavalible}
            startIcon={<img src={mm} alt="mm" />}
            variant="outlined"
            onClick={handleConnect}
          >
            Metamask
          </Button>
        </Stack>
        {metamaskUnavalible ? (
          <Stack direction="column" spacing={2}>
            <Typography variant="p" gutterBottom component="div">
              It seems that you have not installed Metamask. Please install now.
            </Typography>
            <Button variant="outlined" endIcon={<DownloadIcon />}>
              Install Metamask
            </Button>
          </Stack>
        ) : null}
        {connecting ? (
          <>
          {isWrongNetWork ? (
            <Alert severity="error" sx={{ mb: 2 }}>
              <AlertTitle>Wrong Network</AlertTitle>
              It seems that you are connecting to an unsupported network.
              Please change network on your wallet to BSC
            </Alert>
          ) : signing?(
            <Alert severity="warning" sx={{ mb: 2 }}>
              Sign the signature
          </Alert>
          ):(
            <Alert severity="warning" sx={{ mb: 2 }}>
              Connecting to MetaMask
            </Alert>
          )}

          <div style={{ display: "flex", justifyContent: "center" }}>
            <ReactLoading
              type="spin"
              color="#BF8E31"
              height={96}
              width={96}
            />
          </div>
        </>
        ) : null}
      </Box>
    </Modal>
  );
};

const mapStateToProps = (state) => {
  return {
    messageVisible: state.messageVisible,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    showMsg: (config) => dispatch(showMessage(config)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(ConnectModal);
