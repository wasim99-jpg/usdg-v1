import { Col, Row } from "antd";
import React, { useEffect, useState } from "react";
import ohm from "../asset/img/crystal-blue.png";
import discord from "../asset/img/discord.svg";
import github from "../asset/img/github.svg";
import reddit from "../asset/img/reddit.svg";
import telegram from "../asset/img/telegram.svg";
import twitter from "../asset/img/twitter.svg";
import youtube from "../asset/img/youtube.svg";
export default function BaseFooter({ size }) {
  useEffect(() => {
    if (size == "lg" || size == "xl") {
      setPaddingHor("pd-hor-3rem");
      setPaddingVer("pd-ver-5rem");
    } else if (size == "md") {
      setPaddingHor("pd-hor-2rem");
      setPaddingVer("pd-ver-20");
    } else if (size == "sm" || size == "xs") {
      setPaddingHor("pd-hor-1rem");
      setPaddingVer("pd-ver-20");
    }
  }, [size]);

  const [paddingHor, setPaddingHor] = useState("pd-hor-3rem");
  const [paddingVer, setPaddingVer] = useState("pd-ver-5rem");
  return (
    <footer
      className={`pd-ver-10rem bg-cl-141722 cl-white ${paddingHor} mg-top-200`}
    >
      <Row gutter={[, 20]}>
        <Col xl={6} lg={24} md={24} sm={24} xs={24}>
          <Row align="bottom">
            <Col>
              <img
                src={ohm}
                alt=""
                style={{ height: 24 }}
                className="item-head"
              />
            </Col>
            <Col>
              <span className="fw-bold">CRYSTAL</span>
            </Col>
          </Row>
          <div>
            <img src={twitter} alt="" style={{ height: 50, margin: 10 }} />
            <img src={discord} alt="" style={{ height: 50, margin: 10 }} />
            <img src={github} alt="" style={{ height: 50, margin: 10 }} />
          </div>
          <div>
            {/* <img src={instagram} alt="" style={{ height: 50, margin: 10 }} /> */}
            <img src={telegram} alt="" style={{ height: 50, margin: 10 }} />
            <img src={youtube} alt="" style={{ height: 50, margin: 10 }} />
            <img src={reddit} alt="" style={{ height: 50, margin: 10 }} />
          </div>
          <div></div>
        </Col>
        <Col xl={4} lg={6} md={12} sm={12} xs={12}>
          <p style={{fontSize: '1.4rem'}}>Products</p>
          <p>PAXG</p>
          <p>USDC</p>
          <p>USDT</p>
        </Col>
        <Col xl={4} lg={6} md={12} sm={12} xs={12}>
          <p style={{fontSize: '1.4rem'}}>Learn</p>
          <p>DOCS</p>
          <p>BLOG</p>
          <p>MEDIUM</p>
        </Col>
        <Col xl={4} lg={6} md={12} sm={12} xs={24}>
          <p style={{fontSize: '1.4rem'}}>Contact us</p>
          <p>JOIN DISCORD</p>
          <p>MEDIA INQUIRIES</p>
        </Col>
        <Col xl={4} lg={6} md={12} sm={12} xs={24}>
          <p style={{fontSize: '1.4rem'}}>Monthly Digest</p>
          <input
            type="text"
            placeholder="Email address"
            style={{
              width: "100%",
              border: "none",
              color: "black",
              padding: 10,
              borderRadius: 20,
            }}
          />
        </Col>
      </Row>
    </footer>
  );
}
