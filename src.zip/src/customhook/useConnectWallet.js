import { useMemo } from "react";
import { useWeb3React } from "@web3-react/core";
import { injected } from "../component/connectModal/connectors";

export const useConnectWallet = () => {
  const { activate, deactivate } = useWeb3React();
  const connect = useMemo(() => {
    return {
      connectInjected({ metamaskNotFound, callbackSuccess, callbackError }) {
        injected.isAuthorized().then(async (isAuthorized) => {
          callbackSuccess && callbackSuccess();
          await activate(injected, undefined, true).catch((error) => {
            callbackError && callbackError();
          });
        });
      },
      connectDeactivate() {
        deactivate();
      },
    };
  }, []);

  return connect;
};
