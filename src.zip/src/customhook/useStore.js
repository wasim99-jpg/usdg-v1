import { shallowEqual, useSelector } from "react-redux";

export const useAppSelector = (state) => useSelector(state, shallowEqual);
