import { Col, Row, Space } from "antd";
import chart1 from "../../asset/img/chart-1.png";
import chart2 from "../../asset/img/chart-2.png";

import { useEffect, useState } from "react";
import BaseButton from "../../component/BaseButton";
export default function Section4({size}) {
  const [height, setHeight] = useState(200)
  function handleHeight(){
    const width = window.innerWidth;

    if(width > 1600) setHeight(200)
    else if(width <= 1600 && width >= 1386) setHeight(250);
    else if(width < 1386 && width >= 1200) setHeight(350);
    else setHeight('')
  }
  useEffect(()=>{
    window.addEventListener('resize', handleHeight)
  }, [])
  useEffect(()=>{
    handleHeight()
  }, [])
  console.log("height", height)
  return (
    <div className=" mg-top-200">
      <Space direction="vertical" size={50}>
        <p className="fs-3dot1rem fw-bold mg-0 txt-center">How to Participate</p>
        <Row gutter={[,16]}>
          <Col xl={12} lg={24} className={`bg-cl-B4E6F2  ${size == 'xl' ? 'bd-rad-left pd-4rem': 'bd-rad-30 pd-2rem'}  cl-white`}  data-aos-delay="200"  data-aos="fade-up">
            <div>
              <Space direction="vertical" size={0} >
                <Row justify="space-between">
                  <Col className="cl-white fw-bold"  style={{color: 'black'}}>Flexible Deposits</Col>
                  <Col>
                    <img
                      src={chart1}
                      alt=""
                      style={{ width: "7.75vw", maxWidth: 149 }}
                    />
                  </Col>
                </Row>
                <Space direction="vertical" size={20} style={{display: 'flex', justifyContent: 'space-between'}}  >
                  <p className="fs-2rem"  style={{color: 'black'}}>Staking</p>
                  <p style={{color: 'black', height:height,paddingRight: '7.75vw'}}>
                    Staking is the primary means by which most users will likely
                    interact with CRYSTAL and represents the most flexible option
                    available. The APY offered to users is updated daily to reflect
                    our actual revenues, which varies depending on market conditions.
                    We also built in a 1% fee and an automatic 24-hour delay to the
                    smart contract for unstaking; this helps us to recoup any fees
                    and slippage associated with unwinding the delta-neutral trading
                    positions we use to generate yield but also to disincentivize
                    disruptive short-term capital flows and possible attack vectors.
                  </p>
                  <BaseButton
                    bgHv="black"
                    bgColor="transparent"
                    color="black"
                    px={20}
                    py={5}
                    bRad={20}
                    content="STAKE"
                  />
                </Space>
              </Space>
            </div>
          </Col>

          <Col xl={12}lg={24}  className={`bg-cl-96D2E1  ${size == 'xl' ? 'bd-rad-right pd-4rem': 'bd-rad-30 pd-2rem'}`}   data-aos-delay="400"  data-aos="fade-up">
            <div>
              <Space direction="vertical"  size={0}>
                <Row justify="space-between">
                  <Col className="fw-bold"  style={{color: 'black'}}>Fixed Deposits</Col>
                  <Col>
                    <img
                      src={chart2}
                      alt=""
                      style={{ width: "7.75vw", maxWidth: 149 }}
                    />
                  </Col>
                </Row>
                <Space direction="vertical" size={20} style={{display: 'flex', justifyContent: 'space-between'}}  >
                  <p className="fs-2rem" style={{color: 'black'}}>Bonding</p>
                  <p  style={{color: 'black', height: height,paddingRight: '7.75vw'}}>
                    Bonding allows CRYSTAL to offer users a fixed APY in exchange
                    for having their funds locked in the platform for a set amount
                    of time. The APY offered is updated daily to reflect market
                    conditions and takes into account expected fees and slippage.
                    Funds from bonding are typically invested in delta-neutral trades
                    which mirror the duration of the bond so as to eliminate maturity
                    mismatching and mitigate the platform's liquidity risk profile.
                  </p>
                  <BaseButton
                    bgHv="black"
                    bgColor="transparent"
                    color="black"
                    px={20}
                    py={5}
                    bRad={20}
                    content="BOND"
                  />
                </Space>
              </Space>
            </div>
          </Col>
        </Row>
      </Space>
    </div>
  );
}
