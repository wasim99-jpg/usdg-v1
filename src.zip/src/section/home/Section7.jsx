import { Col, Row } from "antd";
import React from "react";
import ArrowRight from "../../asset/img/arrow-right.png";
import BaseButton from "../../component/BaseButton";

export default function Section7({size}) {
  return (
    <div className="mg-top-200">
      <Row gutter={[,20]}>
        <Col lg={8}>
          <p className={`${size == 'xl' ? 'fs-4rem': 'fs-2rem'}  fw-bold`}>Blog Posts</p>
          <BaseButton
            bgHv="black"
            bgColor="white"
            color="black"
            px={20}
            py={5}
            bRad={20}
            content="VIEW ALL ARTICLES"
          />
        </Col>
        <Col lg={16}>
          <div className="bd-1-solid-black pd-2rem bd-rad-2dot3vw hv-white cu-po mg-bot-20"   data-aos-delay="200"  data-aos="fade-down">
            <Row justify="space-between" className="w-100p">
              <Col span={16}>
                <p className="fs-2rem">
                The Case for Centralized Finance in Decentralized Markets
                </p>
                <p className="cl-gray fs-1dot2rem">MAR 31, 2022</p>
              </Col>
              <Col span={2}>
                <img src={ArrowRight} alt="" style={{ width: 30 }} />
              </Col>
            </Row>
          </div>

          <div className="bd-1-solid-black pd-2rem bd-rad-2dot3vw hv-white cu-po mg-bot-20"   data-aos-delay="400"  data-aos="fade-down">
            <Row justify="space-between" className="w-100p">
              <Col span={16}>
                <p className="fs-2rem">
                How CRYSTAL Generates Yields for Its Users: A Deep Dive
                </p>
                <Row>
                  <Col>
                    <p className="cl-gray fs-1dot2rem">MAR 25, 2022</p>
                  </Col>
                  {/* <Col>
                    <p>
                      Welcome back to the CRYSTAL Fundamental Series. If you’re
                      new here, go back and check out the CRYSTAL Foundations
                      article, in which we presented an overview of CRYSTAL.
                    </p>
                  </Col> */}
                </Row>
              </Col>
              <Col span={2}>
                <img src={ArrowRight} alt="" style={{ width: 30 }} />
              </Col>
            </Row>
          </div>

          <div className="bd-1-solid-black pd-2rem bd-rad-2dot3vw hv-white cu-po mg-bot-20"   data-aos-delay="600"  data-aos="fade-down">
            <Row justify="space-between" className="w-100p">
              <Col span={16}>
                <p className="fs-2rem">
                Why Transparency Changes the Crypto Lending Game
                </p>
                <Row>
                  <Col>
                    <p className="cl-gray fs-1dot2rem">MAR 18, 2022</p>
                  </Col>
                  {/* <Col>
                    <p>
                      In the first part of the CRYSTAL Fundamentals series, we
                      shared the foundations of CRYSTAL by defining the Who,
                      What, Why, and How of CRYSTAL.
                    </p>
                  </Col> */}
                </Row>
              </Col>
              <Col span={2}>
                <img src={ArrowRight} alt="" style={{ width: 30 }} />
              </Col>
            </Row>
          </div>
        </Col>
      </Row>
    </div>
  );
}
