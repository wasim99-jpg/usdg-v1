import { Col, Row, Space } from "antd";
import CountUp from "react-countup";
import img5 from "../../asset/img/img-5.svg";

export default function Section5({size}) {
  return (
    <div className="mg-top-200">
      <Row>
        <Col xl={10} lg={10} md={24} xs={24} sm={24}>
          <p className={`${size == 'xl' ? 'fs-4rem': 'fs-2rem'}  fw-bold`}>Community {size == 'xxl' || size == 'xl' ? <br/> : '' } Stats</p>
        </Col>
        <Col xl={14} lg={14} md={24} xs={24} sm={24}>
          <Space direction="vertical w-100p">
            <div className="bd-bot-1-solid-black pd-bot-5rem" data-aos='fade-down'>
              <Row>
                <Col span={4}>
                  <img src={img5} alt="" />
                </Col>
                <Col>
                  <p className="mg-0 title-1">Twitter Followers</p>
                  <CountUp
                    suffix="+"
                    end={150000}
                    duration={3}
                    separator=","
                    decimal=","
                    className="stat"
                  />
                </Col>
              </Row>
            </div>

            <div className="bd-bot-1-solid-black pd-bot-5rem mg-top-60"  data-aos='fade-down'>
              <Row>
                <Col span={4}>
                  <img src={img5} alt="" />
                </Col>
                <Col>
                  <p className="mg-0 title-1">Discord Members</p>
                  <CountUp
                    suffix="+"
                    end={80000}
                    duration={3}
                    separator=","
                    decimal=","
                    className="stat"
                  />
                </Col>
              </Row>
            </div>
          </Space>
        </Col>
      </Row>
    </div>
  );
}
