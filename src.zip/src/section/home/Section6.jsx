import { Col, Row, Space } from "antd";
import React from "react";
import ArrowRight from "../../asset/img/arrow-right.png";
import img6 from "../../asset/img/img-6.png";
import BaseButton from "../../component/BaseButton";
import currency from "../../asset/img/currency.png";
import fundraising from "../../asset/img/fundraising.png";
import group from "../../asset/img/group.png";
import launch from "../../asset/img/launch.png";
import readingBook from "../../asset/img/reading-book.png";
import school from "../../asset/img/school.png";
 

export default function Section6({size}) {
  return (
    <div className="mg-top-200">
      <p className={`${size == 'xl' ? 'fs-4rem': 'fs-2rem'}  fw-bold`}>Initiatives</p>
      <Row data-aos="fade-down">
        <Col xl={6} lg={12} xs={24} sm={24} className="bg-cl-transparent pd-10 ">
          <Space
            direction="vertical"
            size={50}
            className="bg-cl-white pd-2rem bd-rad-30 w-100p initiatives"
            
          >
            <div className="txt-right initiatives">
              <img
                src={school}
                alt=""
                style={{
                  width: "7.75vw",
                  maxWidth: 149,
                   
                }}
              />
            </div>
            <Space direction="vertical" className="w-100p initiatives">
              <p className="fs-2rem mg-0 initiatives">Institutional</p>
              <p className="h-100 initiatives">
                Treasury management-as-a-service for both crypto-native and non-native corporates
              </p>
              <BaseButton
                bgHv="black"
                bgColor="transparent"
                color="white"
                px={20}
                py={5}
                bRad={20}
                content={<img src={ArrowRight} style={{ height: 24 }} alt="" />}
              />
            </Space>
          </Space>
        </Col>
        <Col xl={6} lg={12} xs={24} sm={24} className="bg-cl-transparent pd-10">
          <Space
            direction="vertical"
            size={50}
            className="bg-cl-white pd-2rem bd-rad-30  w-100p initiatives"
          >
            <div className="txt-right">
              <img
                src={fundraising}
                alt=""
                style={{
                  width: "7.75vw",
                  maxWidth: 149,
                }}
              />
            </div>
            <Space direction="vertical w-100p initiatives">
              <p className="fs-2rem mg-0">Charity</p>
              <p className="h-100">
              Maximize your social impact by donating your APY to highly effective charities 
              </p>
              <BaseButton
                bgHv="black"
                bgColor="transparent"
                color="white"
                px={20}
                py={5}
                bRad={20}
                content={<img src={ArrowRight} style={{ height: 24 }} alt="" />}
              />
            </Space>
          </Space>
        </Col>
        <Col xl={6} lg={12} xs={24} sm={24} className="bg-cl-transparent pd-10">
          <Space
            direction="vertical"
            size={50}
            className="bg-cl-white pd-2rem bd-rad-30 w-100p initiatives"
          >
            <div className="txt-right">
              <img
                src={launch}
                alt=""
                style={{
                  width: "7.75vw",
                  maxWidth: 149,
                }}
              />
            </div>
            <Space direction="vertical" className=" w-100p">
              <p className="fs-2rem mg-0">Ventures</p>
              <p className="h-100">Gain access to exclusive early stage deals by redirecting your APY to Ventures</p>
              <BaseButton
                bgHv="black"
                bgColor="transparent"
                color="white"
                px={20}
                py={5}
                bRad={20}
                content={<img src={ArrowRight} style={{ height: 24 }} alt="" />}
              />
            </Space>
          </Space>
        </Col>
        <Col xl={6} lg={12} xs={24} sm={24} className="bg-cl-transparent pd-10">
          <Space
            direction="vertical"
            size={50}
            className="bg-cl-white pd-2rem bd-rad-30 w-100p initiatives"
          >
            <div className="txt-right">
              <img
                src={currency}
                alt=""
                style={{
                  width: "7.75vw",
                  maxWidth: 149,
                }}
              />
            </div>
            <Space direction="vertical" className="w-100p">
              <p className="fs-2rem mg-0">Stablecoin</p>
              <p className="h-100">
                CRYSTAL's very own stablecoin, backed by the platform's assets and ongoing revenues. Work in progress.
              </p>
              <BaseButton
                bgHv="black"
                bgColor="transparent"
                color="white"
                px={20}
                py={5}
                bRad={20}
                content={<img src={ArrowRight} style={{ height: 24 }} alt="" />}
              />
            </Space>
          </Space>
        </Col>
      </Row>
    </div>
  );
}
