import { Col, Row, Space } from "antd";
import { useEffect } from "react";
import BaseButton from "../../component/BaseButton";
export default function Section1({size}) {
  useEffect(() => {
    const video = document.getElementById("my-video");
    video.play();
  }, []);
  return (
    <div className="pd-bot-15rem">
      <Row gutter={[, 20]}>
        <Col lg={10}>
          <div className="t-5rem z-i-2 " data-aos="fade-down">
            <Space direction="vertical" size={50}>
              <Row>
                <Col lg={16}>
                  <p className="fs-3dot7vw pos-rel mg-0 fw-bold">
                  Transparent. Lending. Redefined.{" "}
                  </p>
                </Col>
              </Row>
              <Row>
                <Col md={12} lg={18} className="fs-1rem">
                CRYSTAL is the first centralized lending protocol to give 
                  users unparalleled transparency into our portfolio and the
                  underlying strategies used to generate yield for depositors.
                  Why you ask? Why not? We've got nothing to hide.
                </Col>
              </Row>
              <Row>
                <Col>
                  <BaseButton
                    bgHv="white"
                    content="ENTER APP"
                    bgColor="black"
                    color="white"
                    px={20}
                    py={8}
                    bRad={20}
                  />
                </Col>
              </Row>
            </Space>
          </div>
        </Col>
        <Col
          md={24}
          lg={14}
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <video 
            id="my-video"
            controls
            muted
            autoPlay={"autoplay"}
            // preLoad="auto"
            // loop 
            className="video" 
            data-wf-ignore="true"
            style={{borderRadius: 40}}
          >
            {/* <source src={video} data-src={video} data-wf-ignore="true" /> */}
            <source src="Crystal.mp4" data-src="Crystal.mp4" data-wf-ignore="true" />
          </video>
        </Col>
      </Row>
    </div>
  );
}
