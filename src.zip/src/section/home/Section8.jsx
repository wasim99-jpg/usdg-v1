import { Col, Row } from "antd";
import React, { useState } from "react";
import { Collapse } from "react-collapse";
import arrowDown from "../../asset/img/arrow-down.png";
import BaseButton from "../../component/BaseButton";
const { Panel } = Collapse;

const renderCollapse = () => {};

export default function Section8({size}) {
  const [isOpen1, setIsOpen1] = useState(false);
  const [isOpen2, setIsOpen2] = useState(false);
  const [isOpen3, setIsOpen3] = useState(false);
  const [isOpen4, setIsOpen4] = useState(false);
  const [isOpen5, setIsOpen5] = useState(false);
  const toggle = (open) => {
    switch (open) {
      case 1: {
        setIsOpen1(!isOpen1);
        return;
      }
      case 2: {
        setIsOpen2(!isOpen2);
        return;
      }
      case 3: {
        setIsOpen3(!isOpen3);
        return;
      }
      case 4: {
        setIsOpen4(!isOpen4);
        return;
      }
      case 5: {
        setIsOpen5(!isOpen5);
        return;
      }

    }
  };
  return (
    <div className="mg-top-200">
      <Row gutter={[,20]}>
        <Col xl={8} lg={8} md={24} xs={24} sm={24}>
          <p className={`${size == 'xl' ? 'fs-4rem': 'fs-2rem'}  fw-bold`}>FAQ</p>
          <BaseButton
            bgHv="black"
            bgColor="white"
            color="black"
            px={20}
            py={5}
            bRad={20}
            content="VIEW ALL ARTICLES"
          />
        </Col>
        <Col xl={16} lg={16}  md={24} xs={24} sm={24}>
          <div className={`mg-bot-100 bd-bot-1-solid-black ${size == 'xl' || size == 'lg' ? 'pd-bot-3rem' : 'pd-bot-1rem'} pd-hor-2rem`}>
            <div className="d-flex al-i-center jus-between w-100p">
              <p className="fs-2rem mg-0">What is CRYSTAL?</p>
              <div className="cu-po hv-black-btn" onClick={() => toggle(1)}>
                <img src={arrowDown} alt="" style={{ height: size == 'xl' || size == 'lg' ? 50 : 30 }} />
              </div>
            </div>
            <Collapse isOpened={isOpen1}>
              <div className="pd-top-2rem pd-right-4rem">
              CRYSTAL is, to our knowledge, the first centralized crypto lending
                platform that provides users with unparalleled transparency into its 
                underlying yield-generation strategies.
              </div>
            </Collapse>
          </div>

          <div className={`mg-bot-100 bd-bot-1-solid-black ${size == 'xl' || size == 'lg' ? 'pd-bot-3rem' : 'pd-bot-1rem'} pd-hor-2rem`}>
            <div className="d-flex al-i-center jus-between w-100p">
              <p className="fs-2rem mg-0">How does CRYSTAL generate its yields?</p>
              <div className="cu-po hv-black-btn" onClick={() => toggle(2)}>
                <img src={arrowDown} alt="" style={{ height: size == 'xl' || size == 'lg' ? 50 : 30 }}  />
              </div>
            </div>
            <Collapse isOpened={isOpen2}>
              <div className="pd-top-2rem pd-right-4rem">
                CRYSTAL employs arbitrage and other delta-neutral trading strategies
                to generate a high yet sustainable yield for its users. All lending
                platforms do this to some extent because the supply of crypto available
                for lending far exceeds the organic demand for borrowing at present.
                We're just more honest and open about it.
              </div>
            </Collapse>
          </div>

          <div className={`mg-bot-100 bd-bot-1-solid-black ${size == 'xl' || size == 'lg' ? 'pd-bot-3rem' : 'pd-bot-1rem'} pd-hor-2rem`}>
            <div className="d-flex al-i-center jus-between w-100p">
              <p className="fs-2rem mg-0">
              Why is transparency so important to CRYSTAL?
              </p>
              <div className="cu-po hv-black-btn" onClick={() => toggle(3)}>
                <img src={arrowDown} alt="" style={{ height: size == 'xl' || size == 'lg' ? 50 : 30 }}  />
              </div>
            </div>
            <Collapse isOpened={isOpen3}>
              <div className="pd-top-2rem pd-right-4rem">
                Following the collapse of centralized lenders such as Celsius, BlockFi
                and Babel, it should be abundantly clear to everyone that the "secret
                sauce" argument these platforms use to justify their lack of transparency
                is often an excuse to cover up excessive risk-taking behind the scenes.
                The team at CRYSTAL believes that transparency is one of the hallmarks of
                the decentralized economy, and the best way to mitigate the moral hazard
                problem. Trust, but verify. 
              </div>
            </Collapse>
          </div>

          <div className={`mg-bot-100 bd-bot-1-solid-black ${size == 'xl' || size == 'lg' ? 'pd-bot-3rem' : 'pd-bot-1rem'} pd-hor-2rem`}>
            <div className="d-flex al-i-center jus-between w-100p">
              <p className="fs-2rem mg-0">What if someone steals your trading secrets?</p>
              <div className="cu-po hv-black-btn" onClick={() => toggle(4)}>
                <img src={arrowDown} alt="" style={{ height: size == 'xl' || size == 'lg' ? 50 : 30 }}  />
              </div>
            </div>
            <Collapse isOpened={isOpen4}>
            <div className="pd-top-2rem pd-right-4rem">
                The delta-neutral strategies that we employ are not well-kept secrets,
                by any means. Retail traders can utilize them on their own, but there
                are economies of scale and basic efficiency improvements that you gain
                from delegating your funds to pro traders in a large centralized pool
                rather than juggling your crypto portfolio alongside your day job. 
              </div>
            </Collapse>
          </div>

          <div className={`mg-bot-100 bd-bot-1-solid-black ${size == 'xl' || size == 'lg' ? 'pd-bot-3rem' : 'pd-bot-1rem'} pd-hor-2rem`}>
            <div className="d-flex al-i-center jus-between w-100p">
              <p className="fs-2rem mg-0">What tokens do you accept for staking?</p>
              <div className="cu-po hv-black-btn" onClick={() => toggle(5)}>
                <img src={arrowDown} alt="" style={{ height: size == 'xl' || size == 'lg' ? 50 : 30 }}  />
              </div>
            </div>
            <Collapse isOpened={isOpen5}>
              <div className="pd-top-2rem pd-right-4rem">
                We only accept stablecoins such as USDC, USDT and PAXG at the moment.
                However, we are constantly looking to add to our list of supported
                tokens. Please reach out to a member of our team should you have any enquiries.
              </div>
            </Collapse>
          </div>
        </Col>
      </Row>
    </div>
  );
}
