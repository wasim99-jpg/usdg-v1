import { Col, Row, Space } from "antd";
import ArrowRight from "../../asset/img/arrow-right.png";
import BaseButton from "../../component/BaseButton";
import ReadingBook from "../../asset/img/reading-book.png";
import Dashboard from "../../asset/img/dashboard.png";
import Group from "../../asset/img/group.png";

export default function Section3({size}) {
  return (
    <div className="mg-top-200">
      <Space direction="vertical" size={0}>
        <Row  data-aos="fade-down">
          <Col xl={10} lg={24} sm={24} xs={24}>
            <p className="fs-3dot1rem fw-bold mg-0">
            Transparency: <br/> The Only Way to Truly Build Trust
            </p>
          </Col>
        </Row>
        <Row  data-aos="fade-down">
          <Col xl={10} lg={16} sm={16} xs={16}>
            <p className="fs-rem"  style={{height: size == 'xl' ? 220: ''}}>
            There's a reason Centralized Finance, or CeFi, is ironically so big
              in the decentralised world - people naturally want to delegate functions
              to those they feel are better equipped to perform them. Basic economics.
              However, the spectacular CeFi failures of 2022 remind us that no matter
              how large or smart a team might be, a lack of oversight invariably leads
              to the problem of moral hazard, and transparency is the only proven defence.
            </p>
          </Col>
        </Row>
        <Row>
          <Col>
            <Row justify='space-between' gutter={[, 24]}>
              <Col xxl={7} xl={7} lg={24} className="bg-cl-B4E6F2 pd-2rem bd-rad-2dot3vw" style={{color: 'black'}}  data-aos="fade-down">
                <Space direction="vertical" style={{width: '100%'}} size={size == 'xl' ? 48 : 16}>
                  <Row>
                    <Col span={24} className="txt-right">
                      <img
                        src={Dashboard}
                        alt=""
                        style={{
                          width: 80,
                        }}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col span={12}>
                      <p className=" fs-2rem mg-0"  style={{height: size == 'xl' ? 120: ''}}>Public Dashboard</p>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <p className="subtitle-1 fs-1rem" style={{height: size == 'xl' ? 200: ''}}>
                      CRYSTAL provides a monitoring dashboard for users that
                        updates in real-time, querying, aggregating and presenting
                        relevant data from exchanges via API about the treasury's 
                        liquidity and capital adequacy.
                      </p>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <BaseButton
                        bgHv="black"
                        color="white"
                        bgColor="transparent"
                        px={20}
                        py={5}
                        bRad={20}
                        content={
                          <img src={ArrowRight} style={{ height: 30 }} alt="" />
                        }
                      />
                    </Col>
                  </Row>
                </Space>
              </Col>
              <Col  xxl={7} xl={7} lg={24}  className="bg-cl-B4E6F2 pd-2rem bd-rad-2dot3vw"  style={{color: 'black'}}    data-aos-delay="200"  data-aos="fade-down">
                <Space direction="vertical"  style={{width: '100%'}}   size={size == 'xl' ? 48 : 16}>
                  <Row>
                    <Col span={24} className="txt-right">
                      <img
                        src={ReadingBook}
                        alt=""
                        style={{
                          width: 80,
                        }}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col span={12}>
                      <p className=" fs-2rem mg-0"  style={{height: size == 'xl' ? 120: ''}}>Read-Only Logins</p>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <p className="subtitle-1  fs-1rem"  style={{height: size == 'xl' ? 200: ''}}>
                      Still don't trust us? That's perfectly understandable. 
                        That's why we've released read-only login details for
                        the exchanges on which we trade and custody CRYSTAL's
                        funds. Easily verify the numbers we report for yourself.
                      </p>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <BaseButton
                        bgHv="black"
                        color="white"
                        bgColor="transparent"
                        px={20}
                        py={5}
                        bRad={20}
                        content={
                          <img src={ArrowRight} style={{ height: 30 }} alt="" />
                        }
                      />
                    </Col>
                  </Row>
                </Space>
              </Col>
              <Col  xxl={7} xl={7} lg={24}  className="bg-cl-B4E6F2 pd-2rem bd-rad-2dot3vw"  style={{color: 'black'}}     data-aos-delay="400"  data-aos="fade-down">
                <Space direction="vertical"  style={{width: '100%'}}   size={size == 'xl' ? 48 : 16}>
                  <Row>
                    <Col span={24} className="txt-right">
                      <img
                        src={Group}
                        alt=""
                        style={{
                          width: 80,
                        }}
                      />
                    </Col>
                  </Row>
                  <Row>
                    <Col span={12}>
                      <p className=" fs-2rem mg-0"  style={{height: size == 'xl' ? 120: ''}}>Team Members</p>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                    <p className="subtitle-1  fs-1rem"   style={{height: size == 'xl' ? 200: ''}}>
                        Removing the veil of anonymity is no guarantee of success,  
                        but we believe it is a good starting point. CRYSTAL
                        counts licensed and regulated fund managers from firms
                        such as <a href="https://www.signum.capital/about/" target="_blank" rel="noreferrer"> Signum Capital</a> among its investors and traders.
                      </p>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <BaseButton
                        bgHv="black"
                        bgColor="transparent"
                        color="white"
                        px={20}
                        py={5}
                        bRad={20}
                        content={
                          <img src={ArrowRight} style={{ height: 30 }} alt="" />
                        }
                      />
                    </Col>
                  </Row>
                </Space>
              </Col>
            </Row>
          </Col>
        </Row>
      </Space>
    </div>
  );
}
