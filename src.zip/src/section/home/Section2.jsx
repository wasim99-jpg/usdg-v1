import { Col, Row, Space } from "antd";
import React, { useEffect } from "react";
import CountUp from "react-countup";

export default function Section2({ size }) {
  useEffect(() => {}, [size]);
  return (
    <div className={`pos-rel  ov-x-hidden  `}>
      <div
        className={`bd-rad-2dot3vw z-i-2 w-100p bd-1-solid-black ${
          size == "xl" ? "pd-ver-5rem" : "pd-ver-2rem"
        } `}
      >
        <div
          className={`pos-rel ${size == "xl" ? "pd-hor-3rem" : "pd-hor-1rem"} `}
        >
          <Space direction="vertical w-100p" size={size == "xl" ? 120 : 50}>
            <Row justify="space-between">
              <Col xl={6} lg={24} md={24} sm={24} xs={24}>
                <p className="fs-3dot1rem">Protocol Stats</p>
              </Col>
              <Col xxl={18} xl={18} lg={24} md={24} sm={24} xs={24}>
                <Row>
                  <Col span={12}>
                    <div>
                      <p className="fs-1rem mg-0">Treasury Market Value</p>
                      <CountUp
                        prefix="$"
                        end={328779042}
                        duration={3}
                        separator=","
                        decimal=","
                        className={size == "xl" || size == 'lg' ? "stat" : "stat-2"}
                      />
                    </div>
                  </Col>
                  <Col span={12}>
                    <div>
                      <p className="fs-1rem mg-0">Number of Depositors</p>
                      <CountUp
                        suffix="+"
                        end={25542}
                        duration={3}
                        separator=","
                        decimal=","
                        className={size == "xl" || size == 'lg' ? "stat" : "stat-2"}
                      />
                    </div>
                  </Col>
                </Row>
                <Row justify="space-between" style={{marginTop: 100}}>
                  <Col span={12}>
                    <div>
                      <p className="fs-1rem mg-0" style={{ height: size == 'xs' || size == 'sm' ? 60: ''}}>
                        Average Stablecoin Interest Rate&nbsp;
                      </p>
                      <CountUp
                        suffix="%"
                        end={10.55}
                        duration={3}
                        separator=","
                        decimal="."
                        decimals={2}
                        className={size == "xl" || size == 'lg' ? "stat" : "stat-2"}
                      />
                    </div>
                  </Col>
                  <Col  span={12}>
                    <div>
                      <p className="fs-1rem mg-0" style={{ height: size == 'xs' || size == 'sm' ? 60: ''}}>
                        Current Ratio&nbsp;</p>
                      <CountUp
                        suffix="%"
                        end={133.38}
                        duration={3}
                        separator=","
                        decimal="."
                        decimals={2}
                        className={size == "xl" || size == 'lg' ? "stat" : "stat-2"}
                      />
                    </div>
                  </Col>
                </Row>
              </Col>
            </Row>
          </Space>
        </div>
      </div>
    </div>
  );
}
