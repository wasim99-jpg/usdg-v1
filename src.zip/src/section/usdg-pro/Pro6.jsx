import React from "react";

export default function Pro6({size}) {
  let titleSize = 'fs-4rem';
  if (size == 'xl') titleSize = 'fs-4rem';
  else if (size == 'lg') titleSize = 'fs-2rem';
  else titleSize = 'fs-2rem';
  return (
    <div className="mg-top-200 txt-center">
      <p className={` ${titleSize} fw-bold`}>Explore our Bonds Marketplace</p>
      <p>Bonds give you a superior market rate.</p>
      <div>
        <button
          className="hv-3 bd-1-solid-white "
          style={{
            paddingLeft: 10,
            paddingRight: 10,
            padding: 10,
            borderRadius: 20,
            color: "black",
            cursor: "pointer",
            transition: "0.4s",
            fontSize: "0.8rem",
          }}
        >
          BONDS MARKETPLACE
        </button>
      </div>
      <div>
        <img
          width="100%"
          src="https://assets.website-files.com/621f51702b01b7fee7ff903a/62290ec3023c7c7ac795f88b_Group%2022-2-2-2-2.png"
          alt=""
        />
      </div>
    </div>
  );
}
