import React, { useEffect, useState } from 'react'
import Pro1 from './Pro1'
import Pro2 from './Pro2'
import Pro3 from './Pro3'
import Pro4 from './Pro4'
import Pro5 from './Pro5'
import Pro6 from './Pro6'

export default function IndexUsdgPro({size}) {
  const [paddingHor, setPaddingHor] = useState('pd-hor-3rem')
  useEffect(() => {
    if (size == 'lg') {
      setPaddingHor('pd-hor-3rem')
    }
    else if(size == 'md'){
      setPaddingHor('pd-hor-2rem')
    }
    else if (size == 'sm' || size == 'xs') {
      setPaddingHor('pd-hor-1rem')
    }
  }, [size])
  return (
    <div  className={`${paddingHor}`}>
        <Pro1 size={size}/>
        <Pro2 size={size}/>
        <Pro3 size={size}/>
        <Pro4 size={size}/>
        <Pro5 size={size}/>
        <Pro6 size={size}/>
    </div>
  )
}
