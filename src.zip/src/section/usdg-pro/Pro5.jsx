import { Col, Row } from "antd";
import React from "react";
const SmallView = () => {
  return (
    <div>
      <p className="txt-center fs-1dot5rem">All win, win for all</p>
      <div>
        <p className="txt-center fs-1dot5rem mg-0">Community</p>
        <p className="txt-center ">Swap LPS to receive discounted tokens</p>
        <div
          style={{ background: "#1B232F" }}
          className="txt-center pd-ver-2rem bd-rad-30"
        >
          <p className=" mg-0">Better Price</p>
          <p className="fs-0dot8rem">Opportunity to buy discounted tokens</p>
        </div>
        <div
          style={{ background: "#1B232F" }}
          className="txt-center pd-ver-2rem bd-rad-30 mg-top-20"
        >
          <p className="fs-1dot2rem mg-0">Lower Risk</p>
          <p className="fs-0dot8rem">No exposure to Impermanent loss</p>
        </div>
      </div>
      <div className="txt-center mg-bot-20 mg-top-20">
        <img className="w-100p" src="https://assets.website-files.com/621f51702b01b7fee7ff903a/62290acac427f72a86b9684d_connection%20mob.svg" alt="" />
      </div>
      <div>
        <p className="txt-center fs-1dot5rem mg-0">Protocol</p>
        <p className="txt-center ">Diversified treasuries to protect liquidity</p>
        <div
          style={{ background: "#1B232F" }}
          className="txt-center pd-ver-2rem bd-rad-30"
        >
          <p className="fs-1dot2rem mg-0">Long-Term Liquidity</p>
          <p className="fs-0dot8rem">Grow your liquidity floor</p>
        </div>
        <div
          style={{ background: "#1B232F" }}
          className="txt-center pd-ver-2rem bd-rad-30 mg-top-20"
        >
          <p className="fs-1dot2rem mg-0">New Revenue Streams</p>
          <p className="fs-0dot8rem">Capture fees from DEX trades</p>
        </div>
      </div>
    </div>
  )
}
export default function Pro5({ size }) {
  return (
    <div className=" mg-top-200">
      {(size != 'xs' && size != 'sm') && <>
        <Row>
          <Col span={8} className="txt-center">
            <p className={`mg-0 ${size == 'xl' ? 'fs-2rem' : 'fs-1dot2rem'}`}>Community</p>
            <p className="fs-0dot8rem">Swap LPS to receive discounted tokens</p>
          </Col>
          <Col span={8} className="txt-center">
            <p className={`mg-0 ${size == 'xl' ? 'fs-2rem' : 'fs-1dot2rem'}`}>A win, win for all</p>
          </Col>
          <Col span={8} className="txt-center">
            <p className={`mg-0 ${size == 'xl' ? 'fs-2rem' : 'fs-1dot2rem'}`}>Protocol</p>
            <p className="fs-0dot8rem">
              Diversified treasuries to protect liquidity
            </p>
          </Col>
        </Row>
        <Row className="d-flex jus-between">
          <Col
            span={9}
            style={{ height: 500, flexDirection: "column" }}
            className="d-flex jus-around"
          >
            <div
              style={{ background: "#1B232F" }}
              className="txt-center pd-ver-2rem bd-rad-30"
            >
              <p className=" mg-0">Better Price</p>
              <p className="fs-0dot8rem">Opportunity to buy discounted tokens</p>
            </div>
            <div
              style={{ background: "#1B232F" }}
              className="txt-center pd-ver-2rem bd-rad-30 mg-top-20"
            >
              <p className="fs-1dot2rem mg-0">Lower Risk</p>
              <p className="fs-0dot8rem">No exposure to Impermanent loss</p>
            </div>
          </Col>
          <Col span={6}>

            <img
              width='100%'
              height={500}
              src="https://assets.website-files.com/621f51702b01b7fee7ff903a/62290acab5eab5e9c5c5fa3c_connectors%20desk.svg"
              alt=""
            />
          </Col>
          <Col
            span={9}
            style={{ height: 500, flexDirection: "column" }}
            className="d-flex jus-around"
          >
            <div
              style={{ background: "#1B232F" }}
              className="txt-center pd-ver-2rem bd-rad-30"
            >
              <p className="fs-1dot2rem mg-0">Long-Term Liquidity</p>
              <p className="fs-0dot8rem">Grow your liquidity floor</p>
            </div>
            <div
              style={{ background: "#1B232F" }}
              className="txt-center pd-ver-2rem bd-rad-30 mg-top-20"
            >
              <p className="fs-1dot2rem mg-0">New Revenue Streams</p>
              <p className="fs-0dot8rem">Capture fees from DEX trades</p>
            </div>
          </Col>
        </Row>
      </>
      } 

      {
        (size == 'sm' || size == 'xs') && <SmallView/>
      }

    </div>
  );
}
