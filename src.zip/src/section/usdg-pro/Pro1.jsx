import { Col, Row } from "antd";
import React from "react";
import BaseButton from "../../component/BaseButton";

export default function Pro1({ size }) {
  let titleSize = 'fs-4rem';
  if (size == 'xl') titleSize = 'fs-4rem';
  else if (size == 'lg') titleSize = 'fs-2rem';
  else titleSize = 'fs-2rem';
  return (
    <div className="">
      <Row justify="space-between" align="bottom" gutter={[,20]}>
        <Col xl={{span: 14, order: 2}} lg={24} md={24} xs={24} sm={24} className={size != 'xl' ? 'txt-center' : ''}>
          <video
            id="b6cd0007-e921-aba8-7f6e-980995e76d23-video"
            autoplay="autoplay"
            loop=""
            style={{
              // width: "100%",
              maxWidth: '100%',
              height: "100%",
              borderRadius: 30,
            }}
            muted=""
            playsinline=""
            data-wf-ignore="true"
            data-object-fit="cover"
          >
            <source
              src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228b885b3fc54a4678137cf_Olympus_Portal_Animation_06_TS-transcode.mp4"
              data-wf-ignore="true"
            />
            <source
              src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228b885b3fc54a4678137cf_Olympus_Portal_Animation_06_TS-transcode.webm"
              data-wf-ignore="true"
            />
          </video>
        </Col>
        <Col xl={9} lg={24} md={24} xs={24} sm={24}>
          <p className={`fw-bold ${titleSize} ${size != 'xl' ? 'txt-center' : ''}`}>
            Bond Marketplace For Protocol Owned Liquidity
          </p>
          <p className={`${size != 'xl' ? 'txt-center' : ''}`}>
            Introducing Olympus’ unique cross-chain bonding mechanism to other
            protocols as a service
          </p>
          <Row gutter={[12, 12]}>
            <Col xl={12} lg={24} md={24} xs={24} sm={24}>
              <button
                className="hv-3 bd-1-solid-white "
                style={{
                  width: '100%',
                  paddingLeft: 10,
                  paddingRight: 10,
                  padding: 10,
                  borderRadius: 20,
                  color: "black",
                  cursor: "pointer",
                  transition: "0.4s",
                  fontSize: '0.8rem',
                  fontWeight: 700
                }}
              >
                BONDS MARKETPLACE
              </button>
            </Col>
            <Col xl={10} lg={24} md={24} xs={24} sm={24}>
              <button
                className="hv-3 bd-1-solid-white hv-4"
                style={{
                  width: '100%',
                  paddingLeft: 10,
                  paddingRight: 10,
                  padding: 10,
                  borderRadius: 20,
                  color: "white",
                  cursor: "pointer",
                  transition: "0.4s",
                  fontSize: '0.8rem',
                  fontWeight: 700,
                  background: 'transparent',
                }}
              >
                LEARN MORE
              </button>
            </Col>


          </Row>
        </Col>

      </Row>
    </div>
  );
}
