import { Col, Row } from "antd";
import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick-theme.css";
import "slick-carousel/slick/slick.css";
export default function Pro2({ size }) {
  let titleSize = 'fs-4rem';
  if (size == 'xl') titleSize = 'fs-4rem';
  else if (size == 'lg') titleSize = 'fs-2rem';
  else titleSize = 'fs-2rem';
  return (
    <div className="mg-top-200">
      <p className={`${titleSize} fw-bold txt-center`}>CRYSTAL Pro Partners</p>
      <Slider>
        <div>
          <Row
            className="d-flex jus-between"
            style={{
              display: "flex !important",
              justifyContent: "space-between",
            }}
          >
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Barnbridge</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdff9cbae002e69cd378_logo-11.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Alchemix</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfe449206f01319bede_logo-10.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Float</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8e93efe77a2e66c999_logo-2.png"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Frax</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfe725c5970de1ac2cb_logo-5.svg"
                  alt=""
                />
              </a>
            </Col>




          </Row>
          <Row
            className="d-flex jus-between"
            style={{
              display: "flex !important",
              justifyContent: "space-between",
            }}
          >
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Pendle</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8e1a161756a596a3b8_logo-4.png"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>StakeDAO</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8e8516d68d05b825b9_logo-3.png"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Synapse</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8e493b8ebd8457174a_logo-1.png"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Thorstarter</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfdc86b1033a01925e5_logo-2.svg"
                  alt=""
                />
              </a>

            </Col>




          </Row>
          <Row
            className="d-flex jus-between"
            style={{
              display: "flex !important",
              justifyContent: "space-between",
            }}
          >
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Invert Finance</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be016c24f2a47443f845_logo-7.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Pool Together</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfe1eb29adfc2b1fd91_logo-6.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Liquid Driver</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfdb3fc545dec816495_logo-1.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>

              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Spooky Finance</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8ffe5d987922a94f15_logo.png"
                  alt=""
                />
              </a>
            </Col>



          </Row>
        </div>


        <div>
          <Row
            className="d-flex jus-between"
            style={{
              display: "flex !important",
              justifyContent: "space-between",
            }}
          >
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Barnbridge</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdff9cbae002e69cd378_logo-11.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Alchemix</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfe449206f01319bede_logo-10.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Float</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8e93efe77a2e66c999_logo-2.png"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Frax</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfe725c5970de1ac2cb_logo-5.svg"
                  alt=""
                />
              </a>
            </Col>




          </Row>
          <Row
            className="d-flex jus-between"
            style={{
              display: "flex !important",
              justifyContent: "space-between",
            }}
          >
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Pendle</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8e1a161756a596a3b8_logo-4.png"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>StakeDAO</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8e8516d68d05b825b9_logo-3.png"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Synapse</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8e493b8ebd8457174a_logo-1.png"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Thorstarter</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfdc86b1033a01925e5_logo-2.svg"
                  alt=""
                />
              </a>

            </Col>




          </Row>
          <Row
            className="d-flex jus-between"
            style={{
              display: "flex !important",
              justifyContent: "space-between",
            }}
          >
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Invert Finance</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be016c24f2a47443f845_logo-7.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Pool Together</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfe1eb29adfc2b1fd91_logo-6.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>
              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Liquid Driver</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228bdfdb3fc545dec816495_logo-1.svg"
                  alt=""
                />
              </a>
            </Col>
            <Col xl={6} lg={6} md={12} sm={12} xs={12}>

              <a
                href="/"
                className="d-flex jus-between al-i-center bd-top-bot-1-solid-gray pd-1rem"
                style={{ color: "white" }}
              >
                <span>Spooky Finance</span>
                <img
                  height={45}
                  src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6228be8ffe5d987922a94f15_logo.png"
                  alt=""
                />
              </a>
            </Col>



          </Row>
        </div>


      </Slider>
    </div>
  );
}
