import { Col, Row } from "antd";
import React from "react";

export default function Pro4({size}) {
  return (
    <div className="mg-top-200">
      <Row gutter={[,20]}>
        <Col xl={12} lg={12} md={24} xs={24} sm={24}>
          <p className="fs-3rem fw-bold mg-0">What is Olympus Pro?</p>
        </Col>
        <Col xl={12} lg={12} md={24} xs={24} sm={24}>
          <p className={size == 'xl' || size == 'lg' ? "fs-0dot8rem": 'fs-1rem'}>
            Olympus Pro introduces the innovative bonding mechanism of Olympus
            as a service for other protocols. Similar to bonding on Olympus,
            Olympus Pro allows a user to exchange existing liquidity for the
            protocol’s native token at a discount. In exchange, the protocol
            owns the liquidity instead of renting it, which helps secure
            longevity and price stability for everyone involved.
          </p>
        </Col>
      </Row>
    </div>
  );
}
