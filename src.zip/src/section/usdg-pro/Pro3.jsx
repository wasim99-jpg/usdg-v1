import { Col, Row } from "antd";
import React from "react";
import img5 from "../../asset/img/img-5.svg";
import img12 from "../../asset/img/img-12.svg";
import img13 from "../../asset/img/img-13.svg";
export default function Pro3({ size }) {
  let titleSize = 'fs-4rem';
  if (size == 'xl') titleSize = 'fs-4rem';
  else if (size == 'lg') titleSize = 'fs-2rem';
  else titleSize = 'fs-2rem';
  return (
    <div className="mg-top-200">
      {(size == 'xs' || size == 'sm') && <p className={`${titleSize} fw-bold`}>
        The Problem with Existing Yield Farms
      </p>}
      <Row gutter={[32, 32]}>
        <Col xl={{span: 12, order: 1}} lg={{span: 12, order: 1}} md={{span: 12, order: 1}} xs={{span: 24, order: 2}} sm={{span: 24, order: 2}}>
          {(size == 'xl' || size == 'lg' || size == 'md') && <p className={`${titleSize} fw-bold`}>
            The Problem with Existing Yield Farms
          </p>}
          <div>
            <Row gutter={4}>
              <Col span={12}>
                <div>
                  <p className={`mg-0 ${size !== 'xl' || size !== 'lg' ? 'fs-1dot2rem' : 'fs-2rem'}`}>Sell Pressure</p>
                  <p className="fs-0dot8rem">
                    Token prices are highly subject to sell pressure from the
                    yield farming community, making price unstable.
                  </p>
                </div>
              </Col>
              <Col span={12}>
                <div>
                  <p className={`mg-0 ${size !== 'xl' || size !== 'lg' ? 'fs-1dot2rem' : 'fs-2rem'}`}>Transient Liquidity</p>
                  <p className="fs-0dot8rem">
                    Liquidity in yield farms is highly transient and unreliable
                    for the protocol.
                  </p>
                </div>
              </Col>
            </Row>
            <Row gutter={4}>
              <Col span={12}>
                <div>
                  <p className={`mg-0 ${size !== 'xl' || size !== 'lg' ? 'fs-1dot2rem' : 'fs-2rem'}`}>Imperament Loss</p>
                  <p className="fs-0dot8rem">
                    Due to the mechanics of yield farms, the upside when a token
                    appreciates in value is capped due to impermanent loss.
                  </p>
                </div>
              </Col>
              <Col span={12}>
                <div>
                  <p className={`mg-0 ${size !== 'xl' || size !== 'lg' ? 'fs-1dot2rem' : 'fs-2rem'}`}>Price Volatility</p>
                  <p className="fs-0dot8rem">
                    Volatile token prices negatively impact communities and
                    cause instability for the protocol.
                  </p>
                </div>
              </Col>
            </Row>
          </div>
        </Col>
        <Col xl={{span: 12, order: 2}} lg={{span: 12, order: 2}} md={{span: 12, order: 2}}  xs={{span: 24, order: 1}} sm={{span: 24, order: 1}}>
          <div style={{ background: "#1B232F" }} className="pd-2rem bd-rad-30">
            <Row
              align="middle"
              justify="space-between"
              className="bd-bot-1-solid-798399 pd-bot-2rem"
            >
              <Col>
                <img src={img5} alt="" style={{ height: 40 }} />
              </Col>
              <Col className="cl-gray">— Nansen, Analysis of Masterchef</Col>
            </Row>
            <div className="pd-top-2rem">
              <div>
                <span style={{ width: "60%" }} className="d-inl-block">
                  FIRST 24 HOURS
                </span>
                <span style={{ width: "40%" }} className="d-inl-block">
                  DAY 3
                </span>
              </div>
              <div>
                <img src={img12} alt="" style={{ width: "60%" }} />
                <img src={img13} alt="" style={{ width: "40%" }} />
              </div>
              <div className="d-flex">
                <div style={{ width: "60%" }}>
                  <div
                    style={{
                      height: 150,
                      width: 1,
                      background: "#798399",
                      marginLeft: "1vw",
                    }}
                  ></div>
                </div>
                <div style={{ width: "40%" }}>
                  <div
                    style={{
                      height: 150,
                      width: 1,
                      background: "#798399",
                      marginLeft: "1vw",
                    }}
                  ></div>
                </div>
              </div>
              <div className="d-flex">
                <div style={{ width: '60%' }}>
                  <p className="fw-bold fs-3rem">58%</p>
                  <p>
                    of yield farmers that enter a farm on the day it launches
                    remain after 24 hours.
                  </p>
                </div>
                <div style={{ width: '40%' }}>
                  <p className="fw-bold fs-3rem">30%</p>
                  <p>30% of the initial users remain after 72 hours.</p>
                </div>
              </div>
            </div>
          </div>
        </Col>
      </Row>
    </div>
  );
}
