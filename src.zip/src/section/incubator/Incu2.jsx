import { Col, Row } from "antd";
import React from "react";

export default function Incu2({size}) {
  return (
    <div className="mg-top-200">
      <Row>
        <Col xl={8} lg={8} md={24} xs={24} sm={24}>
          <p className={`${size == 'xl' ? 'fs-3rem': 'fs-2rem'} fw-bold pd-right-20`}>What is CRYSTAL Incubator?</p>
        </Col>
        <Col xl={8} lg={8} md={24}>
          <p className="fs-1rem">
          CRYSTAL Incubator brings community bootstrapping, advice, assistance,
            testing, access to our launch liquidity/products, exposure to high
            quality stakeholders, and most importantly the support of the
            greatest DeFi community the world has ever seen - the Ohmies.
          </p>
        </Col>
        <Col xl={8} lg={8} md={24}  xs={24} sm={24} className={size != 'xl' || size != 'lg' ? 'txt-center': ''}>
          <img
            width="100%"
            style={{maxWidth: 220}}
            src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6246ef5e524aea709aaf0cf9_image%20849-p-500.png"
            alt=""
          />
        </Col>
      </Row>
    </div>
  );
}
