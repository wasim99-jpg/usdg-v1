import { Col, Row } from "antd";
import React from "react";

export default function Incu4({size}) {
  return (
    <div className="mg-top-200">
      <Row>
        <Col xl={12} lg={24}>
          <p className={size == 'xl' ? "fs-3rem fw-bold": 'fs-2rem  fw-bold'}>3,3 Meets VC</p>
          <p className="fs-0dot8rem">
            We shall strive to enable radical ideas to become reality. Through
            this, Olympus (itself a radical idea) becomes a reality.
          </p>
          <Row gutter={16}>
            <Col xl={12} lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Collaboration</p>
                  <p className="fs-0dot8rem">
                    Olympus collaborates with partners for co-marketing and
                    access to the Olympus community.
                  </p>
                </div>
              </div>
            </Col>
            <Col xl={12} lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">OHMdebtor</p>
                  <p className="fs-0dot8rem">
                    Partners are able to apply for use of the OHMdebtor function
                    program allowing for accelerated OHM liquidity while still
                    holding their sOHM.
                  </p>
                </div>
              </div>
            </Col>
          </Row>
        </Col>
        <Col xl={12} lg={24} md={24} xs={24} sm={24} className={`${size == 'xl'? 'txt-right': 'txt-center'}`}>
          <img
            style={{maxWidth: 350}}
            src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6246ef5fc7bbb62967afe83a_image%20850-p-500.png"
            alt=""
          />
        </Col>
      </Row>
      <Row style={{marginTop: 100}}>
        <Col xl={12} lg={24} md={24} sm={24} xs={24}>
          <p  className={size == 'xl' ? "fs-3rem fw-bold": 'fs-2rem  fw-bold'}>Olympus Incubator Partners</p>
        </Col>
        <Col xl={12} lg={24} md={24} sm={24} xs={24}>
          <Row gutter={16}>
            <Col xl={12} lg={12} md={12} sm={24} xs={24}>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">Vesta Finance</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624712d2f7c73346d0463020_Group%2014.png"
                  alt=""
                />
              </div>
            </Col>

            <Col xl={12} lg={12} md={12} sm={24} xs={24}>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">Volt Protocol</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624dd72fb5d9cf13c37e2233_volt_logo.png"
                  alt=""
                />
              </div>
            </Col>
           
          </Row>
        </Col>
      </Row>

      <Row style={{marginTop: 100}}>
        <Col xl={12} lg={24} md={24} sm={24} xs={24}>
          <p  className={size == 'xl' ? "fs-3rem fw-bold": 'fs-2rem  fw-bold'}>Olympus Incubator Partners</p>
        </Col>
        <Col xl={12} lg={24} md={24} sm={24} xs={24}>
          <Row gutter={16}>
            <Col  xl={12} lg={12} md={12} sm={24} xs={24}>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">DebtDAO</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624712ef15abe744a37eaef7_1.png"
                  alt=""
                />
              </div>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">FlatDAO</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/6247130a057b69855dd3ea00_Group%2025.png"
                  alt=""
                />
              </div>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">GoddessDAO</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624712d2f7c73346d0463020_Group%2014.png"
                  alt=""
                />
              </div>
            </Col>

            <Col  xl={12} lg={12} md={12} sm={24} xs={24}>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">JonesDAO</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624712fc328bd792072d5a52_Group%2012.png"
                  alt=""
                />
              </div>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">PhantomDAO</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/6247133b9dc1eeed7558115f_Group%2013.png"
                  alt=""
                />
              </div>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">PrimeDAO</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624712d2f7c73346d0463020_Group%2014.png"
                  alt=""
                />
              </div>
              <div className="bd-top-bot-1-solid-gray d-flex jus-between pd-1rem al-i-center cu-po">
                <p className="fs-1dot5rem mg-0">SilentDAO</p>
                <img
                  height={45}
                  src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/6247134eba2dd0f55678b738_silentdao_logo_edit%201.png"
                  alt=""
                />
              </div>
            </Col>
           
          </Row>
        </Col>
      </Row>

      

      
    </div>
  );
}
