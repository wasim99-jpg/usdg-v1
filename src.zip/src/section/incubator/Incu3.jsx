import { Col, Row } from "antd";
import React from "react";

export default function Incu3({size}) {
  return (
    <div className="mg-top-200">
      <Row>
        <Col xl={6} lg={24} md={24} xs={24} sm={24}>
          <p className={size == 'xl' ? "fs-3rem fw-bold": 'fs-2rem  fw-bold'}>CRYSTAL Incubator</p>
          <p>
            Our flagship offering at the seed- level through to launch and
            beyond.
          </p>
        </Col>
        <Col xl={18} lg={24} md={24} xs={24} sm={24}>
          <Row gutter={16}>
            <Col xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Support</p>
                  <p className="fs-0dot8rem">
                    Support from the ideation phase in tokenomics, seed funding,
                    strategy, talent and resources at each step in the launch
                    process.
                  </p>
                </div>
              </div>
            </Col>
            <Col xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Advisory Services</p>
                  <p className="fs-0dot8rem">
                    Advisory services such brand audits,as operational best
                    practices, Discord and Notion frameworks, compensation
                    advice and introduction to trusted legal advisory services.
                  </p>
                </div>
              </div>
            </Col>
            <Col xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">OHMdebtor</p>
                  <p className="fs-0dot8rem">
                    Incubatees are able to apply for use of the OHMdebtor
                    function program allowing for accelerated OHM liquidity
                    while still holding their sOHM.
                  </p>
                </div>
              </div>
            </Col>
            <Col xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Marketing</p>
                  <p className="fs-0dot8rem">
                    Co-marketing opportunities and direct marketing to the
                    Olympus Community through community calls, Twitter and other
                    modes of marketing support.
                  </p>
                </div>
              </div>
            </Col>
            <Col xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Governance</p>
                  <p className="fs-0dot8rem">
                    Governance participation and support (for example in being
                    added to Frax or Curve gauges) and access to new products or
                    services offered by Olympus.
                  </p>
                </div>
              </div>
            </Col>
            <Col xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Success</p>
                  <p className="fs-0dot8rem">Incubatee success program</p>
                </div>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>

      <Row style={{ marginTop: 80 }}>
        <Col xl={6}  lg={24} md={24} xs={24} sm={24}>
          <p  className={size == 'xl' ? "fs-3rem fw-bold": 'fs-2rem fw-bold'}>CRYSTAL Launch Partnerships</p>
          <p>
            Our flagship offering at the seed- level through to launch and
            beyond.
          </p>
        </Col>
        <Col xl={18}  lg={24} md={24} xs={24} sm={24}>
          <Row gutter={16}>
            <Col  xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Launch Support</p>
                  <p className="fs-0dot8rem">
                    Launch support and ongoing endorsements from Olympus.
                  </p>
                </div>
              </div>
            </Col>
            <Col  xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Collaboration</p>
                  <p className="fs-0dot8rem">
                    Olympus collaborates with partners for co-marketing and
                    access to the Olympus community.
                  </p>
                </div>
              </div>
            </Col>
            <Col  xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">OHMdebtor</p>
                  <p className="fs-0dot8rem">
                    Partners are able to apply for use of the OHMdebtor function
                    program allowing for accelerated OHM liquidity while still
                    holding their sOHM.
                  </p>
                </div>
              </div>
            </Col>
            <Col  xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Web3</p>
                  <p className="fs-0dot8rem">
                    Assistance sourcing or hiring web3 talent.
                  </p>
                </div>
              </div>
            </Col>
            <Col  xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Governance</p>
                  <p className="fs-0dot8rem">
                    Governance participation and support (for example in being
                    added to Frax or Curve gauges) and access to new products or
                    services offered by Olympus.
                  </p>
                </div>
              </div>
            </Col>
            <Col  xl={8}  lg={12} md={12} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray">
                <div style={{ height: 70 }}></div>
                <div style={{ height: 130 }}>
                  <p className="fs-1dot5rem mg-0">Treasury</p>
                  <p className="fs-0dot8rem">
                  CRYSTAL receives 3.3% of a partner’s token to hodl in its
                    treasury.
                  </p>
                </div>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>
    </div>
  );
}
