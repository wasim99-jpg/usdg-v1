import React, { useEffect, useState } from 'react'
import Incu1 from './Incu1'
import Incu2 from './Incu2'
import Incu3 from './Incu3'
import Incu4 from './Incu4'
import Incu5 from './Incu5'
import Incu6 from './Incu6'

export default function IndexIncu({size}) {
  const [paddingHor, setPaddingHor] = useState('pd-hor-3rem')
  useEffect(() => {
    if (size == 'lg') {
      setPaddingHor('pd-hor-3rem')
    }
    else if(size == 'md'){
      setPaddingHor('pd-hor-2rem')
    }
    else if (size == 'sm' || size == 'xs') {
      setPaddingHor('pd-hor-1rem')
    }
  }, [size])
  return (
    <div className={`${paddingHor}`}>
        <Incu1 size={size}/>
        <Incu2 size={size}/>
        <Incu3 size={size}/>
        <Incu4 size={size}/>
        <Incu5 size={size}/>
        <Incu6 size={size}/>
    </div>
  )
}
