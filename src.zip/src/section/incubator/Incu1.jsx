import { Col, Row } from "antd";
import React from "react";
import BaseButton from "../../component/BaseButton";

export default function Incu1({ size }) {
  return (
    <div>
      <Row justify="space-between" align="bottom">

        <Col xl={{ span: 11, order: 2 }} lg={{ span: 11, order: 2 }} md={24} sm={24} xs={24}>
          <div>
            <video
              id="hero-video"
              autoplay="autoplay"
              loop="loop"
              class="content-cover"
              muted=""
              style={{ width: '100%' }}
              playsinline=""
              data-wf-ignore="true"
              data-object-fit="cover"
              className="bd-rad-30"
            >
              <source
                src="https://storage.googleapis.com/landing-page-420/Web%20Videos%20%5BFor%20Hosting%5D/incubator-desktop.mp4"
                data-src="https://storage.googleapis.com/landing-page-420/Web%20Videos%20%5BFor%20Hosting%5D/incubator-desktop.mp4"
                data-wf-ignore="true"
              />
            </video>
          </div>
        </Col>

        <Col xl={{ span: 10, order: 1 }} lg={{ span: 10, order: 1 }} md={24} sm={24} xs={24}>
          <p className={`${size == 'xl' ? 'fs-3rem' : 'fs-2rem'} fw-bold`}>
            Harness the Power of CRYSTAL to Launch and Grow Your Project.
          </p>
          <p>
            Leverage CRYSTAL's expertise to bootstrap your community, create
            effective growth strategies, and join a flourishing econOHMy.
          </p>
          <div className={size != 'xl' || size != 'lg' ? 'txt-center': ''}>
            <BaseButton
              bgHv="white"
              content="LEARN MORE"
              bgColor="black"
              color="white"
              px={20}
              py={10}
              bRad={20}
            />
          </div>
        </Col>
      </Row>
    </div>
  );
}
