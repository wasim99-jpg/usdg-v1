import React from "react";
import BaseButton from "../../component/BaseButton";

export default function Incu6({size}) {
  return (
    <div className="mg-top-200 txt-center">
      <p className={size == 'xl' ? "fs-3rem fw-bold": 'fs-2rem  fw-bold mg-0'}>Explore our Grants Program</p>
      <p>
        Olympus Grants is your go to for getting involved in the Olympus
        Ecosystem
      </p>
      <div className="mg-bot-20">
        <BaseButton
          bgHv="white"
          content="LEARN MORE"
          bgColor="black"
          color="white"
          px={20}
          py={10}
          bRad={20}
        />
      </div>
      <div className="txt-center">
        <img
          width='80%'
          style={{maxWidth: 550}}
          src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6246e99c2f302ea48df041e8_Group%2023.png"
          alt=""
        />
      </div>
    </div>
  );
}
