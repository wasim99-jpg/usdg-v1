import { Col, Row } from "antd";
import React from "react";

export default function Incu5({size}) {
  return (
    <div className="mg-top-200">
      <Row>
        <Col xl={12} lg={12} md={24} xs={24} sm={24}>
          <p className={size == 'xl' ? "fs-3rem fw-bold": 'fs-2rem  fw-bold'}>Sporos Program</p>
          <p className="fs-1dot2rem">
            We also fund companies that just started and have nothing more than
            an idea. Our Sporos program will support you with ideation,
            mentoring, guidance, and funding to turn your idea into a high
            growth business.
          </p>
        </Col>
        <Col xl={12} lg={12} md={24} xs={24} sm={24} className='txt-center'>
          <img
            style={{maxWidth: 300}}
            src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6246ef5ff4f62c140011bf4c_image%20851-p-500.png"
            alt=""
          />
        </Col>
      </Row>
    </div>
  );
}
