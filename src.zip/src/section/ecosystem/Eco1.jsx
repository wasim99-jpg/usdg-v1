import { Col, Row } from 'antd'
import React from 'react'

export default function Eco1() {
    return (
        <div>
            <Row justify='space-between' gutter={[, 20]}>
                <Col xl={{span: 12, order: 2}} lg={{span:12, order: 2}} md={24} xs={24} sm={24}>
                    <div>
                        <video
                            id="d1ddb6ca-6aa4-bfe1-8355-135bfed7d5c3-video"
                            autoplay=""
                            loop=""
                            style={{ width: '100%', borderRadius: 40 }}
                            muted=""
                            playsinline=""
                            data-wf-ignore="true"
                            data-object-fit="cover">
                            <source src="https://assets.website-files.com/621f51702b01b7fee7ff903a/62236e44324d2c7e6bdd1d98_Olympus_Animation_Pillars_05_TS-transcode.mp4" data-wf-ignore="true" />
                            <source src="https://assets.website-files.com/621f51702b01b7fee7ff903a/62236e44324d2c7e6bdd1d98_Olympus_Animation_Pillars_05_TS-transcode.webm" data-wf-ignore="true" />

                        </video>
                    </div>
                </Col>
                <Col xl={{span: 8, order: 1}} lg={{span: 8, order: 1}} md={24} xs={24} sm={24} data-aos-delay="200" data-aos="fade-down">
                <p className='fw-bold fs-2rem mg-0'>A Closer Look at the CRYSTAL Ecosystem</p>
                    <p>A successful reserve currency requires a rich ecosystem to be utilized within. By creating a system of crypto-backed assets, valuable partnerships, usability across DeFi, and carefully managed tokenomics - Olympus gains [alt: maintains] persistent value as a reserve currency.</p>
                    <p>Olympus is focused on building this ecosystem across three main pillars - purchasing power, broad acceptance, and high utility.</p>
                </Col>

            </Row>
        </div>
    )
}
