import { Col, Row } from 'antd';
import React from 'react';
import ArrowRight from "../../asset/img/arrow-right.png";
import img10 from "../../asset/img/img-10.png";
import BaseButton from '../../component/BaseButton';

export default function Eco2({ size }) {
    return (
        <div className='mg-top-200'>
            <Row justify='space-between'>
                <Col xl={6} lg={6} md={24} xs={24} sm={24} className='pd-ver-2rem' data-aos-delay="200" data-aos="fade-down">
                    <p className='fw-bold fs-3rem'>Purchasing Power</p>
                    <p>Strong purchasing power forms the foundation of a successful reserve currency. Olympus preserves purchasing power with a combination of tokenomics, sound policy decisions, and active treasury management - which in turn drives user confidence in PAXG's real and persistent value.</p>
                    <div className='txt-center'>
                        <img width={150} src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6223710bd24c682e6967b89f_Olympus_Objects_HighUtility_01_TS_00000%204-p-500.png" alt="" />
                    </div>
                </Col>
                <Col xl={16} lg={16} md={24} xs={24} sm={24}>
                    <div className='bg-cl-white pd-2rem bd-rad-20'>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po' data-aos-delay="200" data-aos="fade-down">
                            <Row align='middle'>
                                <Col xl={8} lg={24} md={24} xs={24} sm={24}>
                                    <img src={img10} alt="" height={size == 'xl' ? 200 : 100} />
                                </Col>
                                <Col xl={16} lg={24} md={24} xs={24} sm={24}>
                                    <p className='fs-2rem'>CRYSTAL Pro</p>
                                    <p className='mg-bot-20'>Instead of renting liquidity in traditional yield farms, Olympus Pro provides protocols with the ability to use Olympus’ unique bonding mechanism to generate owned liquidity - benefiting both the protocol and it’s community over the long-term.</p>
                                    <BaseButton
                                        bgHv="black"
                                        bgColor="white"
                                        color="white"
                                        px={20}
                                        py={5}
                                        bRad={20}
                                        content={
                                            <img src={ArrowRight} style={{ height: 40 }} alt="" />
                                        }
                                    />
                                </Col>


                            </Row>
                            <div style={{ height: 50 }}></div>
                        </div>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po' data-aos-delay="400" data-aos="fade-down">
                            <Row justify='space-between'>
                                <Col>
                                    <p className='cl-gray fs-1dot2rem'>Treasury Management</p>
                                </Col>
                                <Col>
                                    <img src={ArrowRight} height={30} alt="" />
                                </Col>
                            </Row>
                            <div>
                                <p className='fs-2rem mg-0'>OnlyZaps</p>
                                <p className='mg-bot-20'>Stake or bond token in one-click</p>

                            </div>

                            <div style={{ height: 50 }}></div>
                        </div>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po' data-aos-delay="600" data-aos="fade-down">
                            <Row justify='space-between'>
                                <Col>
                                    <p className='cl-gray fs-1dot2rem'>Purcharsing power</p>
                                </Col>
                                <Col>
                                    <img src={ArrowRight} height={30} alt="" />
                                </Col>
                            </Row>
                            <div>
                                <p className='fs-2rem mg-0'>Bonding</p>
                                <p className='mg-bot-20'>Trade token for PAXG at a discount</p>

                            </div>

                            <div style={{ height: 50 }}></div>
                        </div>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po' data-aos-delay="800" data-aos="fade-down">
                            <Row justify='space-between'>
                                <Col>
                                    <p className='cl-gray fs-1dot2rem'>TokenOmics</p>
                                </Col>
                                <Col>
                                    <img src={ArrowRight} height={30} alt="" />
                                </Col>
                            </Row>
                            <div>
                                <p className='fs-2rem mg-0'>Hermes</p>
                                <p className='mg-bot-20'>Tokenizzed bond market and yield curves</p>

                            </div>

                            <div style={{ height: 50 }}></div>
                        </div>
                    </div>
                </Col>
            </Row>
        </div>
    )
}
