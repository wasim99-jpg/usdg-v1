import { Col, Row } from 'antd';
import React from 'react';
import ArrowRight from "../../asset/img/arrow-right.png";
import img11 from "../../asset/img/img-11.jpg";
import BaseButton from '../../component/BaseButton';
export default function Eco4({size}) {
    return (
        <div className='mg-top-200'>
            <Row justify='space-between'>
                <Col xl={6} className='pd-ver-2rem'   data-aos="fade-down">
                    <p className='fw-bold fs-3rem'>High Utility</p>
                    <p>Finally, to reach mass-adoption, PAXG must achieve high utility. Olympus is rapidly building new protocols and partnering with community initiatives to continue to expand the use cases for OHM.</p>
                </Col>
                <Col xl={16}>
                    <div className='bg-cl-white pd-2rem bd-rad-20'>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po'>
                            <Row align='middle'>
                                <Col xl={16}  lg={{span: 24, order: 1}}  md={{span: 24, order: 2}}  xs={{span: 24, order: 2}}  sm={{span: 24, order: 2}} data-aos-delay='200' data-aos='fade-down'>
                                    <p className='fs-2rem'>CRYSTAL Incubator</p>
                                    <p className='mg-bot-20'>Protocols that utilize or build on top of PAXG or other Olympus products are eligible to receive investment and access to Olympus products and advisors via the incubator. This ensures that the Olympus ecosystem continues to flourish with the expansion of promising new projects.</p>
                                    <BaseButton
                                        bgHv="black"
                                        bgColor="white"
                                        color="white"
                                        px={20}
                                        py={5}
                                        bRad={20}
                                        content={
                                            <img src={ArrowRight} height={40} alt="" />
                                        }
                                    />
                                </Col>
                                <Col xl={8} lg={{span: 24, order: 1}}  md={{span: 24, order: 1}}  xs={{span: 24, order: 1}}  sm={{span: 24, order: 1}}>
                                    <img src={img11} alt="" height={size == 'xl' ? 250: 100} />
                                </Col>
                            </Row>
                            <div style={{ height: 50 }}></div>
                        </div>
                        <Row gutter={32}>
                            <Col span={12}  data-aos='fade-right' data-aos-duration='1000'>
                                <div className='bd-bot-1-solid-black mg-bot-20 cu-po'>
                                    <Row justify='space-between'>
                                        <Col>
                                            <p className='cl-gray fs-1dot2rem'>ULTILITY</p>
                                        </Col>
                                        <Col>
                                            <img src={ArrowRight} height={30} alt="" />
                                        </Col>
                                    </Row>
                                    <div>
                                        <p className={` ${size == 'xl' ? ' fs-2rem': 'fs-1dot2rem'} mg-0 h-50`}>CRYSTAL Give</p>
                                        <p className='mg-bot-20 h-50'>Yield redirection for perpetual no-loss effortless donations</p>

                                    </div>

                                    <div style={{ height: 50 }}></div>
                                </div>
                            </Col>
                            <Col span={12}  data-aos='fade-left' data-aos-duration='1000'>
                                <div className='bd-bot-1-solid-black mg-bot-20 cu-po'>
                                    <Row justify='space-between'>
                                        <Col>
                                            <p className='cl-gray fs-1dot2rem'>ULTILITY</p>
                                        </Col>
                                        <Col>
                                            <img src={ArrowRight} height={30} alt="" />
                                        </Col>
                                    </Row>
                                    <div>
                                        <p className={` ${size == 'xl' ? ' fs-2rem': 'fs-1dot2rem'} mg-0 h-50`}>CRYSTAL Grants</p>
                                        <p className='mg-bot-20 h-50'>Funding Ohmies contributing to the ecOHMsystem</p>

                                    </div>

                                    <div style={{ height: 50 }}></div>
                                </div>
                            </Col>
                        </Row>
                        <Row gutter={32}>
                            <Col span={12}  data-aos='fade-right' data-aos-duration='1000'>
                                <div className='bd-bot-1-solid-black mg-bot-20 cu-po'>
                                    <Row justify='space-between'>
                                        <Col>
                                            <p className='cl-gray fs-1dot2rem'>ULTILITY</p>
                                        </Col>
                                        <Col>
                                            <img src={ArrowRight} height={30} alt="" />
                                        </Col>
                                    </Row>
                                    <div>
                                        <p className={`${size == 'xl' ? ' fs-2rem': 'fs-1dot2rem'} mg-0 h-50`}>CRYSTAL Odyssey</p>
                                        <p className='mg-bot-20 h-50'>A liquid secondary market for NFTs</p>

                                    </div>

                                    <div style={{ height: 50 }}></div>
                                </div>
                            </Col>
                            <Col span={12}  data-aos='fade-left' data-aos-duration='1000'>
                                <div className='bd-bot-1-solid-black mg-bot-20 cu-po'>
                                    <Row justify='space-between'>
                                        <Col>
                                            <p className='cl-gray fs-1dot2rem'>ULTILITY</p>
                                        </Col>
                                        <Col>
                                            <img src={ArrowRight} height={30} alt="" />
                                        </Col>
                                    </Row>
                                    <div>
                                        <p className={`${size == 'xl' ? ' fs-2rem': 'fs-1dot2rem'} mg-0  h-50`}>Agora News</p>
                                        <p className='mg-bot-20 h-50'>Media for Ohmies, by Ohmies</p>

                                    </div>

                                    <div style={{ height: 50 }}></div>
                                </div>
                            </Col>
                        </Row>
                        
                    </div>
                </Col>

            </Row>
        </div>
    )
}
