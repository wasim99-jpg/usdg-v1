import { Col, Row } from 'antd';
import React from 'react';
import ArrowRight from "../../asset/img/arrow-right.png";

export default function Eco5({size}) {
    return (
        <div className='mg-top-200'>
            <Row align='middle' justify='space-between' className='mg-bot-20'>
                <Col lg={6} xl={8} data-aos='fade-right' data-aos-duration='1000'>
                    <p className='fw-bold fs-3rem'>Partnering with CRYSTAL</p>
                </Col>
                <Col xl={12} data-aos='fade-left' data-aos-duration='1000'>
                    <div className='w-60p'>CRYSTAL' various initiatives make it easy to partner and contribute to the quickly growing ecosystem. If you are working on a protocol, and looking to partner, check out some of our programs below:</div>
                </Col>
            </Row>

            <Row className='d-flex jus-between' gutter={[10, 10]}>
                <Col xl={6} lg={12} md={12} xs={24} sm={24}  className='' data-aos='fade-down' data-aos-delay='200'>
                    <div className={` bd-2-solid-black ${size == 'xl' || size == 'lg' ? 'h-150': 'h-100'} bd-rad-20 pd-1rem trans-0dot4s cu-po hv-2`}>
                        <div className='txt-right'><img src={ArrowRight} alt="" height={30} /></div>
                        <p className={`${size == 'xl' || size == 'lg' ? 'fs-2rem': 'fs-1dot2rem'}`}>CRYSTAL Incubator</p>
                    </div>

                </Col>
                <Col xl={6} lg={12}md={12} xs={24} sm={24}  className='' data-aos='fade-down' data-aos-delay='400'>
                    <div className={` bd-2-solid-black ${size == 'xl' || size == 'lg' ? 'h-150': 'h-100'} bd-rad-20 pd-1rem trans-0dot4s cu-po hv-2`}>
                    <div className='txt-right'><img src={ArrowRight} alt="" height={30} /></div>
                    <p className={`${size == 'xl' || size == 'lg' ? 'fs-2rem': 'fs-1dot2rem'}`}>CRYSTAL Pro</p>
                    </div>

                   
                </Col>
                <Col xl={6}lg={12}md={12}xs={24} sm={24}   className='' data-aos='fade-down' data-aos-delay='600'>
                    <div className={` bd-2-solid-black ${size == 'xl' || size == 'lg' ? 'h-150': 'h-100'} bd-rad-20 pd-1rem trans-0dot4s cu-po hv-2`}>
                    <div className='txt-right'><img src={ArrowRight} alt="" height={30} /></div>
                    <p className={`${size == 'xl' || size == 'lg' ? 'fs-2rem': 'fs-1dot2rem'}`}>CRYSTAL Grants</p>
                    </div>

                 
                </Col>
                <Col xl={6}lg={12}md={12} xs={24} sm={24}  className='' data-aos='fade-down' data-aos-delay='800'>
                    <div className={` bd-2-solid-black ${size == 'xl' || size == 'lg' ? 'h-150': 'h-100'} bd-rad-20 pd-1rem trans-0dot4s cu-po hv-2`}>
                        
                    <div className='txt-right'><img src={ArrowRight} alt="" height={30} /></div>
                    <p className={`${size == 'xl' || size == 'lg' ? 'fs-2rem': 'fs-1dot2rem'}`}>CRYSTAL Give</p>
                    </div>

                </Col>
            </Row>
        </div>
    )
}
