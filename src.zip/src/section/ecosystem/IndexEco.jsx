import React, { useEffect, useState } from 'react'
import Eco1 from './Eco1'
import Eco2 from './Eco2'
import Eco3 from './Eco3'
import Eco4 from './Eco4'
import Eco5 from './Eco5'
import Eco6 from './Eco6'

export default function IndexEco({size}) {
  const [paddingHor, setPaddingHor] = useState('pd-hor-3rem')
  useEffect(() => {
    if (size == 'lg') {
      setPaddingHor('pd-hor-3rem')
    }
    else if(size == 'md'){
      setPaddingHor('pd-hor-2rem')
    }
    else if (size == 'sm' || size == 'xs') {
      setPaddingHor('pd-hor-1rem')
    }
  }, [size])
  return (
    <div className={`${paddingHor}`}>
        <Eco1 size={size}/>
        <Eco2 size={size}/>
        <Eco3 size={size}/>
        <Eco4 size={size}/>
        <Eco5  size={size}/>
        <Eco6 size={size}/>
    </div>
  )
}
