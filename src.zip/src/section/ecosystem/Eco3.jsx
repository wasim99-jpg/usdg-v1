import { Col, Row } from 'antd';
import React from 'react';
import ArrowRight from "../../asset/img/arrow-right.png";
import img11 from "../../asset/img/img-11.jpg";
import BaseButton from '../../component/BaseButton';

export default function Eco3({size}) {
  return (
    <div className='mg-top-200'>
            <Row justify='space-between'>
                
                <Col xl={16} lg={16} md={{span: 24, order: 2}}  xs={{span: 24, order: 2}}  sm={{span: 24, order: 2}}>
                    <div className='bg-cl-white pd-2rem bd-rad-20'>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po'  data-aos-delay="200"  data-aos="fade-down">
                            <Row align='middle'>
                                <Col xl={{span: 16, order: 1}} lg={{span: 16, order: 1}} md={{span: 24, order: 2}} xs={{span: 24, order: 2}} sm={{span: 24, order: 2}}>
                                    <p className='fs-3rem'>Proteus</p>
                                    <p className='mg-bot-20'>Proteus aims to provide Olympus liquidity to major chains via partnerships with Ethereum, Avalanche, Arbitrum, Polygon, Fantom, Moonriver, and Terra. This helps ensure that OHM is a highly liquid asset, regardless of which blockchain you’re transacting on.</p>
                                    <BaseButton
                                        bgHv="black"
                                        bgColor="white"
                                        color="white"
                                        px={20}
                                        py={5}
                                        bRad={20}
                                        content={
                                            <img src={ArrowRight} style={{ height: 40 }} alt="" />
                                        }
                                    />
                                </Col>
                                <Col xl={8} lg={8} md={{span: 24, order: 1}} className='txt-right'>
                                    <img src={img11} alt="" height={size == 'xl' || size == 'lg' ? 220: 100} />
                                </Col>
                            </Row>
                            <div style={{ height: 50}}></div>
                        </div>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po'  data-aos-delay="400"  data-aos="fade-down">
                            <Row justify='space-between'>
                                <Col>
                                    <p className='cl-gray fs-1dot2rem'>universal acceptance</p>
                                </Col>
                                <Col>
                                <img src={ArrowRight} height={30} alt="" />
                                </Col>
                            </Row>
                            <div>
                                <p className='fs-3rem mg-0'>Cross-Chain Native</p>
                                <p className='mg-bot-20'>Olympus branches on all major chains</p>

                            </div>

                            <div style={{ height: 50}}></div>
                        </div>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po'  data-aos-delay="600"  data-aos="fade-down">
                            <Row justify='space-between'>
                                <Col>
                                    <p className='cl-gray fs-1dot2rem'>universal acceptance</p>
                                </Col>
                                <Col>
                                <img src={ArrowRight} height={30} alt="" />
                                </Col>
                            </Row>
                            <div>
                                <p className='fs-3rem mg-0'>PAXG Debtor Function</p>
                                <p className='mg-bot-20'>Treasury asset + liquidity unlocked</p>

                            </div>

                            <div style={{ height: 50}}></div>
                        </div>
                        <div className='bd-bot-1-solid-black mg-bot-20 cu-po'  data-aos-delay="800"  data-aos="fade-down">
                            <Row justify='space-between'>
                                <Col>
                                    <p className='cl-gray fs-1dot2rem'>universal acceptance</p>
                                </Col>
                                <Col>
                                <img src={ArrowRight} height={30} alt="" />
                                </Col>
                            </Row>
                            <div>
                                <p className='fs-3rem mg-0'>Concentrated Liquidity</p>
                                <p className='mg-bot-20'>Tokenized bond market and yield curves</p>

                            </div>

                            <div style={{ height: 50}}></div>
                        </div>
                    </div>
                </Col>
                <Col xl={6} lg={6}  md={{span: 24, order: 1}}  xs={{span: 24, order: 1}}  sm={{span: 24, order: 1}} className='pd-ver-2rem'  data-aos="fade-down">
                    <p className='fw-bold fs-3rem'>Universal Acceptance</p>
                    <p className='pd-right-20'>A successful reserve currency must also be liquid and easily tradable for other assets. Olympus works on providing deep liquidity for PAXG across a wide variety of trading pairs and blockchains.</p>
                </Col>
            </Row>
        </div>
  )
}
