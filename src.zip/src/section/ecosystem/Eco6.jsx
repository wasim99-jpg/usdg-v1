import React from 'react'
import img11 from '../../asset/img/img-11.png'
import BaseButton from '../../component/BaseButton'
export default function Eco6({size}) {
  return (
    <div className='mg-top-200'  data-aos='fade-down' data-aos-delay='200'>
        <p className='txt-center fs-3rem fw-bold'>Get started on CRYSTAL</p>
        <div className='txt-center'>
        <BaseButton
              bgHv="white"
              content="ENTER APP"
              bgColor="black"
              color="white"
              px={20}
              py={10}
              bRad={20}
            />
        </div>

        <div className='txt-center mg-top-60'>
            <img src={img11} alt="" width={size == 'xl' || size == 'lg' ? 500: 250}/>
        </div>

    </div>
  )
}
