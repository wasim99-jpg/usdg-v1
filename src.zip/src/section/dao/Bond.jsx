import React from 'react';

const Bond = () => {
    return (
        <div className='fw-bold txt-center fs-2rem'>
            Coming Soon
        </div>
    );
};

export default Bond;