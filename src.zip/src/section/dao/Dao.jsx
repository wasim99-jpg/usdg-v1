import { useWeb3React } from "@web3-react/core";
import { InjectedConnector } from "@web3-react/injected-connector";
import { Col, Row } from 'antd';
import React, { useEffect } from 'react';
import { useDispatch } from "react-redux";
import { Link, Route, Switch, useHistory } from 'react-router-dom';
import bond from '../../asset/img/bond.png';
import logo from '../../asset/img/crystal-blue.png';
import dashboard from '../../asset/img/dashboard.png';

import stake from '../../asset/img/stake.png';
import wallet from '../../asset/img/wallet.png';
import { useConnectWallet } from "../../customhook/useConnectWallet";
import { Connect_Wallet } from '../../redux/action';
import Bond from './Bond';
import Dashboard from './Dashboard';
import Stake from './Stake';
import UpdateAPY from './UpdateApy';
const Dao = () => {
    const { library, account, chainId, active, deactivate, activate } =
    useWeb3React();
    const injected = new InjectedConnector({});
    const dispatch = useDispatch();
    const dispatchLogin = (account) => dispatch(Connect_Wallet({address:account}))
    useEffect(() => {
        activate(injected);
        dispatchLogin(account)
      }, [account]);
      const { connectInjected } = useConnectWallet();
      const handleConnect = async () => {
        connectInjected({
          callbackError: (error) => {
            if (error.name === "UserRejectedRequestError") {
              alert(error.message);
            } 
          },
        });
      };
      const history = useHistory()
    return (
        <div className='d-flex  bg-cl-163554'>
            <div className=' bg-cl-white h-100vh cl-black0 w-300' style={{border: '1px solid #141722 '}}>
                <div className='d-center'>
                    <div className='txt-center cu-po pd-top-1rem' onClick={()=>history.push("/")}>
                        <img src={logo} alt="" style={{ width: 40 }} />
                        <p className='fw-bold fs-1dot2rem'>CRYSTAL</p>
                    </div>

                </div>
                <Link to='/dao/dashboard' className='fw-bold cl-black0 d-block cu-po trans-0dot3s pd-10 hv-gray'><img src={dashboard} style={{ height: 30, marginRight: 15 }} alt="" /> Dashboard</Link>
                <Link to='/dao/bond' className='fw-bold cl-black0 d-block cu-po trans-0dot3s pd-10 hv-gray'><img src={bond} style={{ height: 30, marginRight: 15 }} alt="" /> Bond</Link>
                <Link to='/dao/stake' className='fw-bold cl-black0 d-block cu-po trans-0dot3s pd-10 hv-gray'><img src={stake} style={{ height: 30, marginRight: 15 }} alt="" /> Stake PAXG</Link>
                <Link to='/dao/stake' className='fw-bold cl-black0 d-block cu-po trans-0dot3s pd-10 hv-gray'><img src={stake} style={{ height: 30, marginRight: 15 }} alt="" /> Stake USDT</Link>
                <Link to='/dao/stake' className='fw-bold cl-black0 d-block cu-po trans-0dot3s pd-10 hv-gray'><img src={stake} style={{ height: 30, marginRight: 15 }} alt="" /> Stake USDC</Link>
                <Link to='/dao/update-apy' className='fw-bold cl-black0 d-block cu-po trans-0dot3s pd-10 hv-gray'><img src={stake} style={{ height: 30, marginRight: 15 }} alt="" /> Update APY</Link>
            </div>
            <div className='flex-1-0-auto pd-2rem'>
                <Row justify='end' style={{marginBottom: 20}}>
                    <Col>
                        <div className='trans-0dot3s bg-cl-white pd-hor-1rem pd-ver-5 fw-bold d-flex al-i-center bd-rad-10 cu-po hv-blue maindashboard_text'><img src={wallet} alt="" style={{ height: 32, marginRight: 10 }} onClick={()=>handleConnect()}/> {account?account:"Connect"}</div>
                    </Col>
                </Row>
                <div>
                    <Switch>
                        <Route path='/dao/dashboard' exact>
                            <Dashboard />
                        </Route>
                        <Route path='/dao/bond' exact>
                            <Bond />
                        </Route>
                        <Route path='/dao/stake' exact>
                            <Stake/>
                        </Route>
                         <Route path='/dao/update-apy' exact>
                            <UpdateAPY/>
                        </Route>
                    </Switch>
                </div>
            </div>

        </div>
    );
};

export default Dao;