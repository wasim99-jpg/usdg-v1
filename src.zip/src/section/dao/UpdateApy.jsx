import { Button, notification } from "antd";
import { useEffect, useState } from "react";
// import { injected } from 'connectors';
import { CheckOutlined } from "@ant-design/icons";
import { Input } from "antd";
import { getCurrentIndex, updateAPY } from "../../service/api";

export default function UpdateAPY() {
  const [currentApy, setCurrentApy] = useState("");
  const [timeClaim, setTimeClaim] = useState("");
  const [fee, setFee] = useState("");
  useEffect(() => {
    getCurrentIndexAPY();
  }, []);
  const getCurrentIndexAPY = async () => {
    const res = await getCurrentIndex();
    setCurrentApy(res.APY);
    setFee(res.fee);
    setTimeClaim(res.time);
  };
  const onUpdateApy = async () => {
    await updateAPY(currentApy, fee,timeClaim);
    notification.open({
      message: "CRYSTAL ",
      description: "Successfully Updated Settings",
      icon: <CheckOutlined style={{ color: "#10e98f" }} />,
      onClick: () => {
        console.log("Notification Clicked!");
      },
    });
  };
  return (
    <div className="pd-hor-7rem pd-ver-2rem">
      <div className="bg-cl-white pd-2rem bd-rad-20">
        <div style={{ display: "flex" }}>
          <Input
            addonBefore={"APY : "}
            value={currentApy}
            placeholder="APY"
            onChange={(e) => setCurrentApy(e.target.value)}
          />
        </div>
        <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
          <Input
            addonBefore={"Fee : "}
            value={fee}
            placeholder="Fee"
            onChange={(e) => setFee(e.target.value)}
          />
        </div>
        <div style={{ display: "flex", flexDirection: "row", marginTop: 10 }}>
          <Input
            addonBefore={"Time Claim (unit Minute) : "}
            value={timeClaim}
            placeholder="Time Claim"
            onChange={(e) => setTimeClaim(e.target.value)}
          />
        </div>
        <Button style={{ margin: 10,borderRadius:7  }}   type="primary" onClick={() => onUpdateApy()}>
          Update
        </Button>
      </div>
    </div>
  );
}
