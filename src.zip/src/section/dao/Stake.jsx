import { useWeb3React } from "@web3-react/core";
import { Button, Col, Divider, Modal, notification, Row } from "antd";
import { BigNumber } from "bignumber.js";
import { useEffect, useState } from "react";
import metamask from "../../asset/img/metamask.png";
import { useConnectWallet } from "../../customhook/useConnectWallet";
import BaseWalletService from "../../service/BaseWalletService";
// import { injected } from 'connectors';
import { InfoCircleOutlined } from "@ant-design/icons";
import { InjectedConnector } from "@web3-react/injected-connector";
import { Alert, Input, Tabs } from "antd";
import { useSelector } from "react-redux";
import { claimToken, getCurrentIndex, unStakeFunc } from "../../service/api";
import apy from "../../service/apy.json";
export default function Stake() {
  const [APY, setApy] = useState(apy.apy);
  const [currentIndex, setCurrentIndex] = useState("");
  useEffect(() => {
    getCurrentIndexAPY();
  }, []);
  const getCurrentIndexAPY = async () => {
    const res = await getCurrentIndex();
    setApy(res.APY);
    setCurrentIndex(res.currenIndex);
    setFee(res.fee);
  };
  const [fee, setFee] = useState("1");
  const [balance, setBalance] = useState(0);
  const [balancePool, setBalancePool] = useState();
  const [totalSupply, setTotalSupply] = useState(0);
  const [balanceAddress, setBalanceAddress] = useState();
  const [unStakeBalance, setUnStakeBalance] = useState();
  const account = useSelector((e) => e.address);
  const { TabPane } = Tabs;
  const { library, chainId, active, deactivate, activate } = useWeb3React();
  const { connectInjected } = useConnectWallet();
  // console.log(library, account, chainId, active, deactivate);
  const [openModal, setOpenModal] = useState(false);
  const [valeSatke, setValeStake] = useState("");
  const [valeUnSatke, setValeUnStake] = useState("");
  const handleOk = () => {
    setOpenModal(false);
  };
  const [isShowAprrove, setIsShowApprove] = useState(true);
  const [acceptWarning, setAcceptWarning] = useState(false);
  const [claimValue, setClaimValue] = useState(0);
  const [isClaim, setIsClaim] = useState(false);
  const getStakeInfor = async () => {
    const a = await wallet.getStakeInforPool(library, account);
    const res = convertNumberToNoExponents(
      new BigNumber(a.toString()).dividedBy(Math.pow(10, 18))
    );
    const totalSupply = await wallet.getTotalSupply(library, account);
    const balancePool = convertNumberToNoExponents(
      new BigNumber(res.toString())
        .dividedBy(Math.pow(10, 18))
        .multipliedBy(0.00000002)
    );
    const isApprove = await wallet.allowancePAXG(library, account);
    const balanceApprove = new BigNumber(isApprove.toString())
      .dividedBy(Math.pow(10, 18))
      .toString();

    if (balanceApprove != "0") {
      setIsShowApprove(false);
    }
    setBalance(res);
    setBalancePool(balancePool);
    setUnStakeBalance(
      format2(
        Number(
          new BigNumber(totalSupply.toString())
            .dividedBy(Math.pow(10, 18))
            .minus(new BigNumber(a.toString()).dividedBy(Math.pow(10, 18)))
            .toString()
        )
      )
    );
  };
  const getTotalSupply = async () => {
    const totalSupply = await wallet.getTotalSupply(library, account);
    setTotalSupply(
      convertNumberToNoExponents(
        new BigNumber(totalSupply.toString()).dividedBy(Math.pow(10, 18))
      )
    );
    setUnStakeBalance();
  };
  const getBalanceAddress = async () => {
    const a = await wallet.getBalanceAddress(library, account);
    const res = convertNumberToNoExponents(
      new BigNumber(a.toString()).dividedBy(Math.pow(10, 18))
    );
    setBalanceAddress(res);
  };
  const wallet = new BaseWalletService();
  const injected = new InjectedConnector({});
  const onChange = (key) => {};
  const handleCancel = () => {
    setOpenModal(false);
  };
  const showModal = () => {
    setOpenModal(true);
  };
  const handleConnect = async () => {
    connectInjected({
      callbackError: (error) => {
        if (error.name === "UserRejectedRequestError") {
          alert(error.message);
        } else {
          openModal(true);
        }
      },
    });
  };

  function convertNumberToNoExponents(number) {
    const data = String(number).split(/[eE]/);
    if (data.length == 1) return data[0];

    let z = "";
    const sign = number < 0 ? "-" : "";
    const str = data[0].replace(".", "");
    let mag = Number(data[1]) + 1;

    if (mag < 0) {
      z = sign + "0.";
      while (mag++) z += "0";
      return z + str.replace(/^\-/, "");
    }
    mag -= str.length;
    while (mag--) z += "0";
    return str + z;
  }
  useEffect(() => {
    activate(injected).then(() => {});
    getStakeInfor();
    getBalanceAddress();
  }, [account]);
  const [timeCount, setTimeCount] = useState(20);
  const handleStake = async () => {
    const maxBalace = await wallet.getBalanceAddress(library, account);
    if (
      new BigNumber(maxBalace.toString()).isLessThan(
        new BigNumber(valeSatke).multipliedBy(Math.pow(10, 18))
      )
    ) {
      notification.open({
        message: "CRYSTAL ",
        description: "Insufficient PAXG",
        icon: <InfoCircleOutlined style={{ color: "#c71e12" }} />,
        onClick: () => {
          console.log("Notification Clicked!");
        },
      });
    } else {
      try {
        const res = await wallet.stake(
          library,
          account,
          convertNumberToNoExponents(
            new BigNumber(valeSatke).multipliedBy(Math.pow(10, 18)).toString()
          ),
          account,
          balance
        );
        await claimToken(
          account,
          convertNumberToNoExponents(
            new BigNumber(valeSatke)
              .dividedBy(currentIndex)
              .multipliedBy(Math.pow(10, 18))
              .decimalPlaces(0)
              .toString()
          )
        );
      } catch (error) {}

      await getStakeInfor();
    }
  };

  const handleUnStake = async () => {
    const maxBalace = await wallet.getBalanceSPAXG(library, account);
    if (
      new BigNumber(maxBalace.toString()).isLessThan(
        new BigNumber(valeUnSatke).multipliedBy(Math.pow(10, 18))
      )
    ) {
      notification.open({
        message: "CRYSTAL ",
        description: "Insufficient sPAXG",
        icon: <InfoCircleOutlined style={{ color: "#c71e12" }} />,
        onClick: () => {
          console.log("Notification Clicked!");
        },
      });
    } else {
      const res = await wallet.unStake(
        library,
        account,
        convertNumberToNoExponents(
          new BigNumber(valeUnSatke).multipliedBy(Math.pow(10, 18)).toString()
        ),
        account,
        convertNumberToNoExponents(
          new BigNumber(valeUnSatke)
            .multipliedBy((100 - Number(fee)) / 100)
            .multipliedBy(new BigNumber(currentIndex))
            .multipliedBy(Math.pow(10, 18))
            .decimalPlaces(0)
            .toString()
        )
      );
      await unStakeFunc(
        account,
        convertNumberToNoExponents(
          new BigNumber(valeUnSatke)
            .multipliedBy((100 - Number(fee)) / 100)
            .multipliedBy(new BigNumber(currentIndex))
            .multipliedBy(Math.pow(10, 18))
            .decimalPlaces(0)
            .toString()
        )
      );
      await getStakeInfor();
    }
  };
  const currenIndex = () => {
    return (
      ((new Date().getTime() - 1656303751036) / (100 * 60 * 60 * 3)) * 0.002 +
      2.073
    )
      .toString()
      .slice(0, 6);
  };
  const handleApprove = async () => {
    const res = await wallet.approve(
      library,
      account,
      convertNumberToNoExponents(
        new BigNumber(valeSatke).multipliedBy(Math.pow(10, 19)).toString()
      ),
      account
    );

    setIsShowApprove(false);
  };
  function format2(n) {
    return n.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,");
  }
  const TotalValueDeposited = () => {
    const total = Number(
      new BigNumber(balance).multipliedBy(currenIndex()).toString()
    );
    return format2(total);
  };
  const handleClickStakeMax = () => {
    setValeStake(balanceAddress);
  };
  const handleClickUnStakeMax = async () => {
    const unStakeMax = await wallet.getBalanceSPAXG(library, account);
    setValeUnStake(
      convertNumberToNoExponents(
        new BigNumber(unStakeMax.toString()).dividedBy(Math.pow(10, 18))
      )
    );
  };
  const onCloseWarning = () => {
    setAcceptWarning(true);
  };
  const handleClaim = async () => {
    const res = await wallet.claim(account, claimValue);
    setIsClaim(false);
  };

  // const countDownClaim = async () => {
  //   let time = 20;
  //   let interval = setInterval(() => {
  //     time = time - 1;
  //     setTimeCount(time);
  //     if (time === 0) {
  //       clearInterval(interval);
  //       setIsClaim(true);
  //     }
  //   }, 1000);
  // };

  return (
    <div className="pd-hor-7rem pd-ver-2rem bg-cl-163554 maindashboard_text">
      <div className="bg-cl-white pd-2rem bd-rad-20 maindashboard_text">
        <div>
          <p className="fs-1dot2rem mg-0  fw-bold">Stake PAXG</p>
          <p className="fs-0dot8rem">
            <span className="fw-bold">{timeCount} mins</span> to next Current Index rebase
          </p>
        </div>
        <Row>
          <Col span={8}>
            <div className="txt-center">
              <p className="cl-gray mg-0 fs-1dot2rem">APY</p>
              <p className="fs-1dot2rem fw-bold">{APY}%</p>
            </div>
          </Col>
          <Col span={8}>
            <div className="txt-center">
              <p className="cl-gray mg-0 fs-1dot2rem">Total Value Deposited</p>
              <p className="fs-1dot2rem fw-bold">${TotalValueDeposited()}</p>
            </div>
          </Col>
          <Col span={8}>
            <div className="txt-center">
              <p className="cl-gray mg-0 fs-1dot2rem">Current Index</p>
              <p className="fs-1dot2rem fw-bold">{currentIndex} sPAXG</p>
            </div>
          </Col>
        </Row>

        {!account && (
          <div>
            <Button
              style={{
                border: "none",
                height: 40,
                paddingLeft: 20,
                paddingRight: 20,
                cursor: "pointer",
                borderRadius: 10,
                display: "block",
                margin: "auto",
                background: "#759AAE",
                color: "white",
              }}
              onClick={showModal}
            >
              Connect Wallet
            </Button>
            <p className="txt-center mg-top-20">
            Connect your wallet to stake PAXG
            </p>
          </div>
        )}
        <p className="txt-center mg-top-20">
          First Time staking <b>PAXG</b>? Please approve CRYSTAL to use
          your <b>PAXG</b> for staking. &nbsp;
        </p>
        {isShowAprrove && (
          <Button
            style={{
              border: "none",
              height: 40,
              paddingLeft: 20,
              paddingRight: 20,
              cursor: "pointer",
              borderRadius: 10,
              display: "block",
              margin: "auto",
              background: "#759AAE",
              color: "white",
              marginBottom: 10,
            }}
            onClick={handleApprove}
          >
            Approve Token
          </Button>
        )}
        {/* {isClaim && (
          <Button
            style={{
              marginTop: 10,
              border: "none",
              height: 40,
              paddingLeft: 20,
              paddingRight: 20,
              cursor: "pointer",
              borderRadius: 10,
              display: "block",
              margin: "auto",
              background: "#759AAE",
              color: "white",
            }}
            onClick={handleClaim}
          >
            Claim
          </Button>
        )} */}
        {account && (
          <Tabs
            style={{
              display: "flex",
              alignContent: "center",
              justifyContent: "center",
            }}
            defaultActiveKey="1"
            onChange={onChange}
          >
            <TabPane tab="Stake" key="1">
              <div style={{ display: "flex", flexDirection: "row" }}>
                <Input
                  placeholder="Amount Stake"
                  value={valeSatke}
                  onChange={(e) => setValeStake(e.target.value)}
                />
                <Button onClick={handleClickStakeMax}>Max</Button>
                <Button onClick={handleStake}>Stake</Button>
              </div>
            </TabPane>
            <TabPane tab="UnStake" key="2">
              <Alert
                style={{ marginBottom: 5 }}
                message="Unstaking will cost 1% and take 1 day to process. Close to acknowledge and begin unstaking."
                type="error"
                closable
                onClose={onCloseWarning}
              />
              <div style={{ display: "flex", flexDirection: "row" }}>
                <Input
                  disabled={!acceptWarning}
                  placeholder="Amount UnStake"
                  value={valeUnSatke}
                  onChange={(e) => setValeUnStake(e.target.value)}
                />
                <Button
                  disabled={!acceptWarning}
                  onClick={handleClickUnStakeMax}
                >
                  Max
                </Button>
                <Button disabled={!acceptWarning} onClick={handleUnStake}>
                  UnStake
                </Button>
              </div>
            </TabPane>
          </Tabs>
        )}
        <p className="txt-center mg-top-20">&nbsp;</p>
        <p>
          <Row>
            <Col xs={30} xl={8}>
              <b>Unstaked Balance</b>
            </Col>
            <Col xs={24} xl={8}>
              &nbsp;
            </Col>
            <Col xs={25} xl={8} style={{ float: "right" }}>
              {unStakeBalance} PAXG
            </Col>
          </Row>
          <Row>
            <Col xs={30} xl={8}>
              <b>Token Staked Balance</b>
            </Col>
            <Col xs={24} xl={8}>
              &nbsp;
            </Col>
            <Col xs={25} xl={8} style={{ float: "right" }}>
              {format2(Number(balance))} PAXG
            </Col>
          </Row>
          <Divider></Divider>
          <Row>
            <Col xs={30} xl={8}>
              <b>Next Reward Amount</b>
            </Col>
            <Col xs={24} xl={8}>
              &nbsp;
            </Col>
            <Col xs={25} xl={8} style={{ float: "right" }}>
              0.0000 sPAXG
            </Col>
          </Row>
          <Row>
            <Col xs={30} xl={8}>
              <b>APY (30-Day Average)</b>
            </Col>
            <Col xs={24} xl={8}>
              &nbsp;
            </Col>
            <Col xs={25} xl={8} style={{ float: "right" }}>
              0.1587 %
            </Col>
          </Row>
          <Row>
            <Col xs={30} xl={8}>
              <b>APY (90-Day Average)</b>
            </Col>
            <Col xs={24} xl={8}>
              &nbsp;
            </Col>
            <Col xs={25} xl={8} style={{ float: "right" }}>
              2.4070 %
            </Col>
          </Row>
        </p>
      </div>

      <Modal
        visible={openModal}
        onOk={handleOk}
        onCancel={handleCancel}
        width={800}
        footer={null}
      >
        <div className="w-100p d-flex" style={{ height: 500 }}>
          <div
            className="w-300 bd-right-1-solid-gray h-100p pd-right-20"
            style={{ height: 500 }}
          >
            <p className="fs-1dot2rem fw-bold">Connect a Wallet</p>
            <div>
              <p className="cl-gray fw-bold mg-0">Recommended</p>
              <div className="hv-1 cu-po trans-0dot3s">
                <img src={metamask} alt="" height={35} />
                &nbsp;
                <span className="fw-bold">MetaMask</span>
              </div>
            </div>
          </div>
          <div style={{ height: 500, flex: "1 0 0" }}>
            <div className="fw-bold txt-center fs-1dot2rem">
              What is the Wallet?
            </div>
            <div className="pd-3rem">
              <div className="d-flex al-i-center mg-auto">
                <div>
                  <img src={src1} alt="" height={50} />
                </div>
                <div style={{ width: 20 }}></div>
                <div>
                  <p className="fw-bold mg-0">
                    A home for your digital address
                  </p>
                  <p>
                    Wallets are used to send, receive, store, and display
                    digital assets like Ethereum and NFTs.
                  </p>
                </div>
              </div>
              <div className="d-flex al-i-center mg-auto">
                <div>
                  <img src={src2} alt="" height={50} />
                </div>
                <div style={{ width: 20 }}></div>
                <div>
                  <p className="fw-bold mg-0">A New Way to Log In</p>
                  <p>
                  Instead of creating new accounts and passwords on every
                    website, just connect your wallet.
                  </p>
                </div>
              </div>
            </div>
            <div className="txt-center">
              <Button onClick={() => handleConnect()}>Connect MetaMask</Button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}

const src2 =
  "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGZpbGw9Im5vbmUiIHZpZXdCb3g9IjAgMCA0OCA0OCI+PHBhdGggZmlsbD0idXJsKCNhKSIgZD0iTTAgMTZjMC01LjYgMC04LjQgMS4wOS0xMC41NGExMCAxMCAwIDAgMSA0LjM3LTQuMzdDNy42IDAgMTAuNCAwIDE2IDBoMTZjNS42IDAgOC40IDAgMTAuNTQgMS4wOWExMCAxMCAwIDAgMSA0LjM3IDQuMzdDNDggNy42IDQ4IDEwLjQgNDggMTZ2MTZjMCA1LjYgMCA4LjQtMS4wOSAxMC41NGExMC4wMDEgMTAuMDAxIDAgMCAxLTQuMzcgNC4zN0M0MC40IDQ4IDM3LjYgNDggMzIgNDhIMTZjLTUuNiAwLTguNCAwLTEwLjU0LTEuMDlhMTAgMTAgMCAwIDEtNC4zNy00LjM3QzAgNDAuNCAwIDM3LjYgMCAzMlYxNloiLz48cGF0aCBmaWxsPSJ1cmwoI2IpIiBkPSJNMCAxNmMwLTUuNiAwLTguNCAxLjA5LTEwLjU0YTEwIDEwIDAgMCAxIDQuMzctNC4zN0M3LjYgMCAxMC40IDAgMTYgMGgxNmM1LjYgMCA4LjQgMCAxMC41NCAxLjA5YTEwIDEwIDAgMCAxIDQuMzcgNC4zN0M0OCA3LjYgNDggMTAuNCA0OCAxNnYxNmMwIDUuNiAwIDguNC0xLjA5IDEwLjU0YTEwLjAwMSAxMC4wMDEgMCAwIDEtNC4zNyA0LjM3QzQwLjQgNDggMzcuNiA0OCAzMiA0OEgxNmMtNS42IDAtOC40IDAtMTAuNTQtMS4wOWExMCAxMCAwIDAgMS00LjM3LTQuMzdDMCA0MC40IDAgMzcuNiAwIDMyVjE2WiIvPjxwYXRoIGZpbGw9IiMwMDAiIGZpbGwtb3BhY2l0eT0iLjA0IiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xLjEzMyA5LjUxM0MxIDExLjEzMSAxIDEzLjE4MyAxIDE2djE2YzAgMi44MTcgMCA0Ljg3LjEzMyA2LjQ4Ni4xMzEgMS42MDYuMzg3IDIuNjk1Ljg0OCAzLjZhOSA5IDAgMCAwIDMuOTMzIDMuOTMzYy45MDUuNDYxIDEuOTk0LjcxNyAzLjYuODQ4QzExLjEzIDQ3IDEzLjE4MyA0NyAxNiA0N2gxNmMyLjgxNyAwIDQuODcgMCA2LjQ4Ni0uMTMzIDEuNjA2LS4xMzEgMi42OTUtLjM4NyAzLjYtLjg0OGE5IDkgMCAwIDAgMy45MzMtMy45MzNjLjQ2MS0uOTA1LjcxNy0xLjk5NC44NDgtMy42QzQ3IDM2Ljg3IDQ3IDM0LjgxNiA0NyAzMlYxNmMwLTIuODE3IDAtNC44Ny0uMTMzLTYuNDg3LS4xMzEtMS42MDUtLjM4Ny0yLjY5NC0uODQ4LTMuNTk5YTkgOSAwIDAgMC0zLjkzMy0zLjkzM2MtLjkwNS0uNDYxLTEuOTk0LS43MTctMy42LS44NDhDMzYuODcgMSAzNC44MTYgMSAzMiAxSDE2Yy0yLjgxNyAwLTQuODcgMC02LjQ4Ny4xMzMtMS42MDUuMTMxLTIuNjk0LjM4Ny0zLjU5OS44NDhhOSA5IDAgMCAwLTMuOTMzIDMuOTMzYy0uNDYxLjkwNS0uNzE3IDEuOTk0LS44NDggMy42Wk0xLjA5IDUuNDZDMCA3LjYgMCAxMC40IDAgMTZ2MTZjMCA1LjYgMCA4LjQgMS4wOSAxMC41NGExMCAxMCAwIDAgMCA0LjM3IDQuMzdDNy42IDQ4IDEwLjQgNDggMTYgNDhoMTZjNS42IDAgOC40IDAgMTAuNTQtMS4wOWExMC4wMDEgMTAuMDAxIDAgMCAwIDQuMzctNC4zN0M0OCA0MC40IDQ4IDM3LjYgNDggMzJWMTZjMC01LjYgMC04LjQtMS4wOS0xMC41NGExMCAxMCAwIDAgMC00LjM3LTQuMzdDNDAuNCAwIDM3LjYgMCAzMiAwSDE2QzEwLjQgMCA3LjYgMCA1LjQ2IDEuMDlhMTAgMTAgMCAwIDAtNC4zNyA0LjM3WiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PHBhdGggZmlsbD0idXJsKCNjKSIgZD0iTTMgMTQuMmMwLTMuOTIgMC01Ljg4Ljc2My03LjM3OGE3IDcgMCAwIDEgMy4wNi0zLjA1OUM4LjMxOCAzIDEwLjI4IDMgMTQuMiAzaDE5LjZjMy45MiAwIDUuODggMCA3LjM3OC43NjNhNyA3IDAgMCAxIDMuMDU5IDMuMDZDNDUgOC4zMTggNDUgMTAuMjggNDUgMTQuMnYxOS42YzAgMy45MiAwIDUuODgtLjc2MyA3LjM3OGE3IDcgMCAwIDEtMy4wNiAzLjA1OUMzOS42ODIgNDUgMzcuNzIgNDUgMzMuOCA0NUgxNC4yYy0zLjkyIDAtNS44OCAwLTcuMzc4LS43NjNhNyA3IDAgMCAxLTMuMDU5LTMuMDZDMyAzOS42ODIgMyAzNy43MiAzIDMzLjhWMTQuMloiLz48cGF0aCBmaWxsPSJ1cmwoI2QpIiBmaWxsLW9wYWNpdHk9Ii43IiBkPSJNMyAxNC4yYzAtMy45MiAwLTUuODguNzYzLTcuMzc4YTcgNyAwIDAgMSAzLjA2LTMuMDU5QzguMzE4IDMgMTAuMjggMyAxNC4yIDNoMTkuNmMzLjkyIDAgNS44OCAwIDcuMzc4Ljc2M2E3IDcgMCAwIDEgMy4wNTkgMy4wNkM0NSA4LjMxOCA0NSAxMC4yOCA0NSAxNC4ydjE5LjZjMCAzLjkyIDAgNS44OC0uNzYzIDcuMzc4YTcgNyAwIDAgMS0zLjA2IDMuMDU5QzM5LjY4MiA0NSAzNy43MiA0NSAzMy44IDQ1SDE0LjJjLTMuOTIgMC01Ljg4IDAtNy4zNzgtLjc2M2E3IDcgMCAwIDEtMy4wNTktMy4wNkMzIDM5LjY4MiAzIDM3LjcyIDMgMzMuOFYxNC4yWiIgc3R5bGU9Im1peC1ibGVuZC1tb2RlOnNjcmVlbiIvPjxwYXRoIGZpbGw9IiMwMDAiIGZpbGwtb3BhY2l0eT0iLjIiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMuNTk0IDkuNjQzQzMuNSAxMC43ODUgMy41IDEyLjIzMiAzLjUgMTQuMnYxOS42YzAgMS45NjggMCAzLjQxNS4wOTQgNC41NTcuMDkzIDEuMTM2LjI3NSAxLjkyOC42MTQgMi41OTRhNi41IDYuNSAwIDAgMCAyLjg0MSAyLjg0Yy42NjcuMzQgMS40NTguNTIyIDIuNTk0LjYxNSAxLjE0Mi4wOTQgMi41ODkuMDk0IDQuNTU3LjA5NGgxOS42YzEuOTY4IDAgMy40MTUgMCA0LjU1Ny0uMDk0IDEuMTM2LS4wOTMgMS45MjgtLjI3NSAyLjU5NC0uNjE0YTYuNDk5IDYuNDk5IDAgMCAwIDIuODQtMi44NDFjLjM0LS42NjYuNTIyLTEuNDU4LjYxNS0yLjU5NC4wOTQtMS4xNDIuMDk0LTIuNTg5LjA5NC00LjU1N1YxNC4yYzAtMS45NjggMC0zLjQxNS0uMDk0LTQuNTU3LS4wOTMtMS4xMzYtLjI3NS0xLjkyNy0uNjE0LTIuNTk0YTYuNSA2LjUgMCAwIDAtMi44NDEtMi44NGMtLjY2Ni0uMzQtMS40NTgtLjUyMi0yLjU5NC0uNjE1QzM3LjIxNSAzLjUgMzUuNzY4IDMuNSAzMy44IDMuNUgxNC4yYy0xLjk2OCAwLTMuNDE1IDAtNC41NTcuMDk0LTEuMTM2LjA5My0xLjkyNy4yNzUtMi41OTQuNjE0QTYuNSA2LjUgMCAwIDAgNC4yMSA3LjA1Yy0uMzQuNjY3LS41MjIgMS40NTgtLjYxNSAyLjU5NFptLjE2OS0yLjgyQzMgOC4zMTggMyAxMC4yOCAzIDE0LjJ2MTkuNmMwIDMuOTIgMCA1Ljg4Ljc2MyA3LjM3OGE3IDcgMCAwIDAgMy4wNiAzLjA1OUM4LjMxOCA0NSAxMC4yOCA0NSAxNC4yIDQ1aDE5LjZjMy45MiAwIDUuODggMCA3LjM3OC0uNzYzYTcgNyAwIDAgMCAzLjA1OS0zLjA2QzQ1IDM5LjY4MiA0NSAzNy43MiA0NSAzMy44VjE0LjJjMC0zLjkyIDAtNS44OC0uNzYzLTcuMzc4YTcgNyAwIDAgMC0zLjA2LTMuMDU5QzM5LjY4MiAzIDM3LjcyIDMgMzMuOCAzSDE0LjJjLTMuOTIgMC01Ljg4IDAtNy4zNzguNzYzYTcgNyAwIDAgMC0zLjA1OSAzLjA2WiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PHBhdGggZmlsbD0iI2ZmZiIgZmlsbC1vcGFjaXR5PSIuMiIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNNC41ODUgOS43MTJDNC41MDEgMTAuNzQ2IDQuNSAxMi4wNjMgNC41IDEzLjl2MjAuMmMwIDEuODM3IDAgMy4xNTQuMDg1IDQuMTg4LjA4NCAxLjAyMi4yNDQgMS42NzguNTE0IDIuMjA5QTUuNSA1LjUgMCAwIDAgNy41MDMgNDIuOWMuNTMuMjcgMS4xODcuNDMgMi4yMS41MTQgMS4wMzMuMDg0IDIuMzUuMDg1IDQuMTg3LjA4NWgyMC4yYzEuODM3IDAgMy4xNTQgMCA0LjE4OC0uMDg1IDEuMDIyLS4wODQgMS42NzgtLjI0NCAyLjIwOS0uNTE0YTUuNSA1LjUgMCAwIDAgMi40MDQtMi40MDRjLjI3LS41My40My0xLjE4Ny41MTQtMi4yMS4wODQtMS4wMzMuMDg1LTIuMzUuMDg1LTQuMTg3VjEzLjljMC0xLjgzNyAwLTMuMTU0LS4wODUtNC4xODgtLjA4NC0xLjAyMi0uMjQ0LTEuNjc4LS41MTQtMi4yMDlBNS41IDUuNSAwIDAgMCA0MC40OTYgNS4xYy0uNTMtLjI3LTEuMTg3LS40My0yLjIxLS41MTQtMS4wMzMtLjA4NC0yLjM1LS4wODUtNC4xODctLjA4NUgxMy45Yy0xLjgzNyAwLTMuMTU0IDAtNC4xODguMDg1LTEuMDIyLjA4NC0xLjY3OC4yNDQtMi4yMDkuNTE0QTUuNSA1LjUgMCAwIDAgNS4xIDcuNTAzYy0uMjcuNTMtLjQzIDEuMTg3LS41MTQgMi4yMVpNNC4yMDggNy4wNUMzLjUgOC40NCAzLjUgMTAuMjYgMy41IDEzLjl2MjAuMmMwIDMuNjQgMCA1LjQ2LjcwOCA2Ljg1YTYuNSA2LjUgMCAwIDAgMi44NDEgMi44NDFjMS4zOS43MDkgMy4yMS43MDkgNi44NTEuNzA5aDIwLjJjMy42NCAwIDUuNDYgMCA2Ljg1LS43MDlhNi40OTkgNi40OTkgMCAwIDAgMi44NDEtMi44NGMuNzA5LTEuMzkuNzA5LTMuMjEuNzA5LTYuODUxVjEzLjljMC0zLjY0IDAtNS40Ni0uNzA5LTYuODVhNi41IDYuNSAwIDAgMC0yLjg0LTIuODQyQzM5LjU2IDMuNSAzNy43NCAzLjUgMzQuMSAzLjVIMTMuOWMtMy42NCAwLTUuNDYgMC02Ljg1LjcwOEE2LjUgNi41IDAgMCAwIDQuMjA3IDcuMDVaIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIHN0eWxlPSJtaXgtYmxlbmQtbW9kZTpvdmVybGF5Ii8+PHBhdGggZmlsbD0idXJsKCNlKSIgZD0iTTE4IDExLjM0N2MtNC43MyAyLjI0Ny04IDcuMDY4LTggMTIuNjUzIDAgNS41ODUgMy4yNyAxMC40MDYgOCAxMi42NTNWMjMuOTA4YzAtLjMgMC0uNTY1LjA0Ny0uODI5LjA0LS4yMzIuMTEtLjQ1OC4yMDQtLjY3NC4xMDctLjI0NS4yNTQtLjQ2NS40Mi0uNzE1bC45MDUtMS4zNTdhNi44NiA2Ljg2IDAgMCAwIC4yMTItLjMyN0wxOS43OSAyMGwtLjAwMy0uMDA2YTYuODYgNi44NiAwIDAgMC0uMjEyLS4zMjdsLS45MDQtMS4zNTdjLS4xNjctLjI1LS4zMTQtLjQ3LS40MjEtLjcxNWEyLjk5NCAyLjk5NCAwIDAgMS0uMjA0LS42NzRDMTggMTYuNjU3IDE4IDE2LjM5MiAxOCAxNi4wOTJ2LTQuNzQ1WiIvPjxwYXRoIGZpbGw9InVybCgjZikiIGQ9Ik0zMCAzNi42NTNjNC43My0yLjI0NyA4LTcuMDY4IDgtMTIuNjUzIDAtNS41ODUtMy4yNy0xMC40MDYtOC0xMi42NTN2MTIuNzQ1YzAgLjMgMCAuNTY1LS4wNDcuODI5LS4wNC4yMzItLjExLjQ1OC0uMjA0LjY3NC0uMTA3LjI0NS0uMjU0LjQ2NS0uNDIuNzE1bC0uOTA1IDEuMzU3YTYuODYgNi44NiAwIDAgMC0uMjEyLjMyN0wyOC4yMSAyOGwuMDAzLjAwNmMuMDM5LjA2Ny4wOTguMTU2LjIxMi4zMjdsLjkwNCAxLjM1N2MuMTY3LjI1LjMxNC40Ny40MjEuNzE1LjA5NS4yMTYuMTYzLjQ0Mi4yMDQuNjc0LjA0Ny4yNjQuMDQ3LjUyOS4wNDcuODI5djQuNzQ1WiIvPjxwYXRoIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iLjIiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTIwLjA5MiAzOS43ODJhMiAyIDAgMCAxLS44NzQtLjg3NEMxOSAzOC40OCAxOSAzNy45MiAxOSAzNi44VjIzLjk2OWMwLS4zNiAwLS41NC4wMzEtLjcxNC4wMjgtLjE1NS4wNzMtLjMwNi4xMzYtLjQ1LjA3LS4xNjIuMTctLjMxMS4zNy0uNjExbC44NzEtMS4zMDZjLjIxNC0uMzIxLjMyMS0uNDgyLjM2My0uNjU1YTEgMSAwIDAgMCAwLS40NjZjLS4wNDItLjE3My0uMTQ5LS4zMzQtLjM2My0uNjU0bC0uODctMS4zMDdjLS4yLS4zLS4zLS40NS0uMzctLjYxMWExLjk5OCAxLjk5OCAwIDAgMS0uMTM3LS40NWMtLjAzLS4xNzQtLjAzLS4zNTQtLjAzLS43MTRWMTEuMmMwLTEuMTIgMC0xLjY4LjIxNy0yLjEwOGEyIDIgMCAwIDEgLjg3NC0uODc0QzIwLjUyIDggMjEuMDggOCAyMi4yIDhoMy42YzEuMTIgMCAxLjY4IDAgMi4xMDguMjE4YTIgMiAwIDAgMSAuODc0Ljg3NEMyOSA5LjUyIDI5IDEwLjA4IDI5IDExLjJ2MTIuODMxYzAgLjM2IDAgLjU0LS4wMzEuNzE0YTEuOTk4IDEuOTk4IDAgMCAxLS4xMzYuNDVjLS4wNy4xNjItLjE3LjMxMS0uMzcuNjExbC0uODcxIDEuMzA2Yy0uMjE0LjMyMS0uMzIxLjQ4Mi0uMzYzLjY1NWExIDEgMCAwIDAgMCAuNDY2Yy4wNDIuMTczLjE0OS4zMzQuMzYzLjY1NGwuODcgMS4zMDdjLjIuMy4zLjQ1LjM3MS42MTEuMDYzLjE0NC4xMDkuMjk1LjEzNi40NS4wMzEuMTc0LjAzMS4zNTQuMDMxLjcxNFYzNi44YzAgMS4xMiAwIDEuNjgtLjIxOCAyLjEwOGEyIDIgMCAwIDEtLjg3NC44NzRDMjcuNDggNDAgMjYuOTIgNDAgMjUuOCA0MGgtMy42Yy0xLjEyIDAtMS42OCAwLTIuMTA4LS4yMThaTTE5Ljc5MSAyMGwtLjAwMy0uMDA2YTYuODYgNi44NiAwIDAgMC0uMjEyLS4zMjdsLS44Ny0xLjMwNi0uMDM0LS4wNWMtLjE2Ny0uMjUtLjMxNC0uNDcxLS40MjEtLjcxNmEzIDMgMCAwIDEtLjIwNC0uNjc0QzE4IDE2LjY1NyAxOCAxNi4zOTIgMTggMTYuMDkydi00LjkzYzAtLjUyOCAwLS45ODIuMDMtMS4zNTcuMDMzLS4zOTUuMTA0LS43ODkuMjk3LTEuMTY3YTMgMyAwIDAgMSAxLjMxMS0xLjMxMWMuMzc4LS4xOTMuNzcyLS4yNjQgMS4xNjctLjI5NkMyMS4xOCA3IDIxLjYzNSA3IDIyLjE2MiA3aDMuNjc3Yy41MjcgMCAuOTgyIDAgMS4zNTYuMDMuMzk1LjAzMy43ODkuMTA0IDEuMTY3LjI5N2EzIDMgMCAwIDEgMS4zMTEgMS4zMTFjLjE5My4zNzguMjY0Ljc3Mi4yOTcgMS4xNjcuMDMuMzc1LjAzLjgzLjAzIDEuMzU3djEyLjkzYzAgLjMgMCAuNTY1LS4wNDcuODI5YTMgMyAwIDAgMS0uMjAzLjY3NGMtLjEwOC4yNDUtLjI1NS40NjUtLjQyMi43MTUtLjAxLjAxNy0uMDIyLjAzNC0uMDMzLjA1bC0uODcxIDEuMzA3YTYuODYgNi44NiAwIDAgMC0uMjExLjMyN2wtLjAwNC4wMDYuMDA0LjAwNmMuMDM4LjA2Ny4wOTcuMTU2LjIxLjMyN2wuODcyIDEuMzA2LjAzMy4wNWMuMTY3LjI1LjMxNC40NzEuNDIyLjcxNmEzIDMgMCAwIDEgLjIwMy42NzRjLjA0Ny4yNjQuMDQ3LjUyOS4wNDcuODI5djQuOTNjMCAuNTI4IDAgLjk4My0uMDMgMS4zNTctLjAzMy4zOTUtLjEwNC43ODktLjI5NyAxLjE2N2EzIDMgMCAwIDEtMS4zMTEgMS4zMTFjLS4zNzguMTkzLS43NzIuMjY0LTEuMTY3LjI5Ni0uMzc1LjAzMS0uODMuMDMxLTEuMzU2LjAzMWgtMy42NzdjLS41MjggMC0uOTgyIDAtMS4zNTctLjAzLS4zOTUtLjAzMy0uNzg4LS4xMDQtMS4xNjctLjI5N2EzIDMgMCAwIDEtMS4zMTEtMS4zMTFjLS4xOTMtLjM3OC0uMjY0LS43NzItLjI5Ni0xLjE2N2ExNy4yMyAxNy4yMyAwIDAgMS0uMDMtMS4zNTZ2LTEyLjg3TDE4IDIzLjkwOGMwLS4zIDAtLjU2NS4wNDctLjgyOWEzIDMgMCAwIDEgLjIwNC0uNjc0Yy4xMDctLjI0NS4yNTQtLjQ2NS40Mi0uNzE1bC4wMzQtLjA1Ljg3MS0xLjMwN2E2Ljg2IDYuODYgMCAwIDAgLjIxMi0uMzI3TDE5Ljc5IDIwWiIgY2xpcC1ydWxlPSJldmVub2RkIiBzdHlsZT0ibWl4LWJsZW5kLW1vZGU6b3ZlcmxheSIvPjxwYXRoIGZpbGw9IiMwMDAiIGZpbGwtb3BhY2l0eT0iLjciIGQ9Ik0xOSAxMS4yYzAtMS4xMiAwLTEuNjguMjE4LTIuMTA4YTIgMiAwIDAgMSAuODc0LS44NzRDMjAuNTIgOCAyMS4wOCA4IDIyLjIgOGgzLjZjMS4xMiAwIDEuNjggMCAyLjEwOC4yMThhMiAyIDAgMCAxIC44NzQuODc0QzI5IDkuNTIgMjkgMTAuMDggMjkgMTEuMnYxMi44MzFjMCAuMzYgMCAuNTQtLjAzMS43MTRhMi4wMDMgMi4wMDMgMCAwIDEtLjEzNi40NWMtLjA3LjE2Mi0uMTcuMzExLS4zNy42MTFsLS44NzEgMS4zMDZjLS4yMTQuMzIxLS4zMjEuNDgyLS4zNjMuNjU1YTEgMSAwIDAgMCAwIC40NjZjLjA0Mi4xNzMuMTQ5LjMzNC4zNjMuNjU0bC44NyAxLjMwN2MuMi4zLjMuNDUuMzcxLjYxMS4wNjMuMTQ0LjEwOC4yOTUuMTM2LjQ1LjAzMS4xNzQuMDMxLjM1NC4wMzEuNzE0VjM2LjhjMCAxLjEyIDAgMS42OC0uMjE4IDIuMTA4YTIgMiAwIDAgMS0uODc0Ljg3NEMyNy40OCA0MCAyNi45MiA0MCAyNS44IDQwaC0zLjZjLTEuMTIgMC0xLjY4IDAtMi4xMDgtLjIxOGEyIDIgMCAwIDEtLjg3NC0uODc0QzE5IDM4LjQ4IDE5IDM3LjkyIDE5IDM2LjhWMjMuOTY5YzAtLjM2IDAtLjU0LjAzMS0uNzE0LjAyOC0uMTU1LjA3My0uMzA2LjEzNi0uNDUuMDctLjE2Mi4xNy0uMzExLjM3LS42MTFsLjg3MS0xLjMwNmMuMjE0LS4zMjEuMzIxLS40ODIuMzYzLS42NTVhMSAxIDAgMCAwIDAtLjQ2NmMtLjA0Mi0uMTczLS4xNDktLjMzNC0uMzYzLS42NTRsLS44Ny0xLjMwN2MtLjItLjMtLjMtLjQ1LS4zNzEtLjYxMWEyLjAwMyAyLjAwMyAwIDAgMS0uMTM2LS40NUMxOSAxNi41NzEgMTkgMTYuMzkxIDE5IDE2LjAzMVYxMS4yWiIvPjxkZWZzPjxsaW5lYXJHcmFkaWVudCBpZD0iYSIgeDE9IjI0IiB4Mj0iMjQiIHkxPSIwIiB5Mj0iNDgiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj48c3RvcCBzdG9wLWNvbG9yPSIjMTc0Mjk5Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjMDAxRTU5Ii8+PC9saW5lYXJHcmFkaWVudD48bGluZWFyR3JhZGllbnQgaWQ9ImIiIHgxPSIyNCIgeDI9IjI0IiB5MT0iMCIgeTI9IjQ4IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agc3RvcC1jb2xvcj0iI0QyRDhFNCIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI0MyQzlENiIvPjwvbGluZWFyR3JhZGllbnQ+PGxpbmVhckdyYWRpZW50IGlkPSJlIiB4MT0iMjQiIHgyPSIyNCIgeTE9IjEwIiB5Mj0iMzgiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj48c3RvcCBzdG9wLW9wYWNpdHk9Ii4xMiIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1vcGFjaXR5PSIuMDQiLz48L2xpbmVhckdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0iZiIgeDE9IjI0IiB4Mj0iMjQiIHkxPSIxMCIgeTI9IjM4IiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agc3RvcC1vcGFjaXR5PSIuMTIiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3Atb3BhY2l0eT0iLjA0Ii8+PC9saW5lYXJHcmFkaWVudD48cmFkaWFsR3JhZGllbnQgaWQ9ImMiIGN4PSIwIiBjeT0iMCIgcj0iMSIgZ3JhZGllbnRUcmFuc2Zvcm09InJvdGF0ZSgtNDAuMDc3IDY5LjgxNSA0OC42NjUpIHNjYWxlKDgyLjkwNDgpIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHN0b3Agb2Zmc2V0PSIuMjc2IiBzdG9wLWNvbG9yPSIjMjBGRjREIi8+PHN0b3Agb2Zmc2V0PSIuNDY0IiBzdG9wLWNvbG9yPSIjMTQ5OUZGIi8+PHN0b3Agb2Zmc2V0PSIuNzU1IiBzdG9wLWNvbG9yPSIjRkY2RkM2Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjQkM2N0ZGIi8+PC9yYWRpYWxHcmFkaWVudD48cmFkaWFsR3JhZGllbnQgaWQ9ImQiIGN4PSIwIiBjeT0iMCIgcj0iMSIgZ3JhZGllbnRUcmFuc2Zvcm09InJvdGF0ZSg0NSAyLjUyIC02LjA4Mikgc2NhbGUoNjguNjc3NykiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj48c3RvcCBzdG9wLWNvbG9yPSJyZWQiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwMEEzRkYiLz48L3JhZGlhbEdyYWRpZW50PjwvZGVmcz48L3N2Zz4=";

const src1 =
  "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGZpbGw9Im5vbmUiIHZpZXdCb3g9IjAgMCA0OCA0OCI+PHBhdGggZmlsbD0idXJsKCNhKSIgZD0iTTEuMDkgNS40NkMwIDcuNiAwIDEwLjQgMCAxNnYxNmMwIDUuNiAwIDguNCAxLjA5IDEwLjU0YTEwIDEwIDAgMCAwIDQuMzcgNC4zN0M3LjYgNDggMTAuNCA0OCAxNiA0OGgxNmMxLjc1MiAwIDMuMjMgMCA0LjUtLjAzMyAwLTEuMzYyIDAtMi4wNDQuMDY2LTIuNjE2YTEwIDEwIDAgMCAxIDguNzg1LTguNzg1Yy41NzItLjA2NiAxLjI1NC0uMDY2IDIuNjE2LS4wNjZDNDggMzUuMjMgNDggMzMuNzUyIDQ4IDMyVjE2YzAtNS42IDAtOC40LTEuMDktMTAuNTRhMTAgMTAgMCAwIDAtNC4zNy00LjM3QzQwLjQgMCAzNy42IDAgMzIgMEgxNkMxMC40IDAgNy42IDAgNS40NiAxLjA5YTEwIDEwIDAgMCAwLTQuMzcgNC4zN1oiLz48cGF0aCBmaWxsPSJ1cmwoI2IpIiBkPSJNMS4wOSA1LjQ2QzAgNy42IDAgMTAuNCAwIDE2djE2YzAgNS42IDAgOC40IDEuMDkgMTAuNTRhMTAgMTAgMCAwIDAgNC4zNyA0LjM3QzcuNiA0OCAxMC40IDQ4IDE2IDQ4aDE2YzEuNzUyIDAgMy4yMyAwIDQuNS0uMDMzIDAtMS4zNjIgMC0yLjA0NC4wNjYtMi42MTZhMTAgMTAgMCAwIDEgOC43ODUtOC43ODVjLjU3Mi0uMDY2IDEuMjU0LS4wNjYgMi42MTYtLjA2NkM0OCAzNS4yMyA0OCAzMy43NTIgNDggMzJWMTZjMC01LjYgMC04LjQtMS4wOS0xMC41NGExMCAxMCAwIDAgMC00LjM3LTQuMzdDNDAuNCAwIDM3LjYgMCAzMiAwSDE2QzEwLjQgMCA3LjYgMCA1LjQ2IDEuMDlhMTAgMTAgMCAwIDAtNC4zNyA0LjM3WiIvPjxwYXRoIGZpbGw9IiMwMDAiIGZpbGwtb3BhY2l0eT0iLjA0IiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0zNS41IDM1LjVoMTEuNDg2QzQ3IDM0LjQ3NSA0NyAzMy4zMiA0NyAzMlYxNmMwLTIuODE3IDAtNC44Ny0uMTMzLTYuNDg3LS4xMzEtMS42MDUtLjM4Ny0yLjY5NC0uODQ4LTMuNTk5YTkgOSAwIDAgMC0zLjkzMy0zLjkzM2MtLjkwNS0uNDYxLTEuOTk0LS43MTctMy42LS44NDhDMzYuODcgMSAzNC44MTYgMSAzMiAxSDE2Yy0yLjgxNyAwLTQuODcgMC02LjQ4Ny4xMzMtMS42MDUuMTMxLTIuNjk0LjM4Ny0zLjU5OS44NDhhOSA5IDAgMCAwLTMuOTMzIDMuOTMzYy0uNDYxLjkwNS0uNzE3IDEuOTk0LS44NDggMy42QzEgMTEuMTMgMSAxMy4xODMgMSAxNnYxNmMwIDIuODE3IDAgNC44Ny4xMzMgNi40ODYuMTMxIDEuNjA2LjM4NyAyLjY5NS44NDggMy42YTkgOSAwIDAgMCAzLjkzMyAzLjkzM2MuOTA1LjQ2MSAxLjk5NC43MTcgMy42Ljg0OEMxMS4xMyA0NyAxMy4xODMgNDcgMTYgNDdoMTZjMS4zMiAwIDIuNDc1IDAgMy41LS4wMTRWMzUuNVptMSAxMi40NjdDMzUuMjMgNDggMzMuNzUyIDQ4IDMyIDQ4SDE2Yy01LjYgMC04LjQgMC0xMC41NC0xLjA5YTEwIDEwIDAgMCAxLTQuMzctNC4zN0MwIDQwLjQgMCAzNy42IDAgMzJWMTZjMC01LjYgMC04LjQgMS4wOS0xMC41NGExMCAxMCAwIDAgMSA0LjM3LTQuMzdDNy42IDAgMTAuNCAwIDE2IDBoMTZjNS42IDAgOC40IDAgMTAuNTQgMS4wOWExMCAxMCAwIDAgMSA0LjM3IDQuMzdDNDggNy42IDQ4IDEwLjQgNDggMTZ2MTZjMCAxLjc1MiAwIDMuMjMtLjAzMyA0LjVIMzYuNXYxMS40NjdaIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48cGF0aCBmaWxsPSIjMDAwIiBmaWxsLW9wYWNpdHk9Ii44IiBkPSJNMyAxNC4yYzAtMy45MiAwLTUuODguNzYzLTcuMzc4YTcgNyAwIDAgMSAzLjA2LTMuMDU5QzguMzE4IDMgMTAuMjggMyAxNC4yIDNoMTkuNmMzLjkyIDAgNS44OCAwIDcuMzc4Ljc2M2E3IDcgMCAwIDEgMy4wNTkgMy4wNkM0NSA4LjMxOCA0NSAxMC4yOCA0NSAxNC4ydjE5LjZjMCAzLjkyIDAgNS44OC0uNzYzIDcuMzc4YTcgNyAwIDAgMS0zLjA2IDMuMDU5QzM5LjY4MiA0NSAzNy43MiA0NSAzMy44IDQ1SDE0LjJjLTMuOTIgMC01Ljg4IDAtNy4zNzgtLjc2M2E3IDcgMCAwIDEtMy4wNTktMy4wNkMzIDM5LjY4MiAzIDM3LjcyIDMgMzMuOFYxNC4yWiIvPjxwYXRoIGZpbGw9IiMwMDAiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMzLjggMy41SDE0LjJjLTEuOTY4IDAtMy40MTUgMC00LjU1Ny4wOTQtMS4xMzYuMDkzLTEuOTI3LjI3NS0yLjU5NC42MTRBNi41IDYuNSAwIDAgMCA0LjIxIDcuMDVjLS4zNC42NjctLjUyMiAxLjQ1OC0uNjE1IDIuNTk0QzMuNSAxMC43ODUgMy41IDEyLjIzMiAzLjUgMTQuMnYxOS42YzAgMS45NjggMCAzLjQxNS4wOTQgNC41NTcuMDkzIDEuMTM2LjI3NSAxLjkyOC42MTQgMi41OTRhNi41IDYuNSAwIDAgMCAyLjg0MSAyLjg0Yy42NjcuMzQgMS40NTguNTIyIDIuNTk0LjYxNSAxLjE0Mi4wOTQgMi41ODkuMDk0IDQuNTU3LjA5NGgxOS42YzEuOTY4IDAgMy40MTUgMCA0LjU1Ny0uMDk0IDEuMTM2LS4wOTMgMS45MjgtLjI3NSAyLjU5NC0uNjE0YTYuNDk5IDYuNDk5IDAgMCAwIDIuODQtMi44NDFjLjM0LS42NjYuNTIyLTEuNDU4LjYxNS0yLjU5NC4wOTQtMS4xNDIuMDk0LTIuNTg5LjA5NC00LjU1N1YxNC4yYzAtMS45NjggMC0zLjQxNS0uMDk0LTQuNTU3LS4wOTMtMS4xMzYtLjI3NS0xLjkyNy0uNjE0LTIuNTk0YTYuNSA2LjUgMCAwIDAtMi44NDEtMi44NGMtLjY2Ni0uMzQtMS40NTgtLjUyMi0yLjU5NC0uNjE1QzM3LjIxNSAzLjUgMzUuNzY4IDMuNSAzMy44IDMuNVpNMy43NjMgNi44MjJDMyA4LjMyIDMgMTAuMjggMyAxNC4ydjE5LjZjMCAzLjkyIDAgNS44OC43NjMgNy4zNzhhNyA3IDAgMCAwIDMuMDYgMy4wNTlDOC4zMTggNDUgMTAuMjggNDUgMTQuMiA0NWgxOS42YzMuOTIgMCA1Ljg4IDAgNy4zNzgtLjc2M2E3IDcgMCAwIDAgMy4wNTktMy4wNkM0NSAzOS42ODIgNDUgMzcuNzIgNDUgMzMuOFYxNC4yYzAtMy45MiAwLTUuODgtLjc2My03LjM3OGE3IDcgMCAwIDAtMy4wNi0zLjA1OUMzOS42ODIgMyAzNy43MiAzIDMzLjggM0gxNC4yYy0zLjkyIDAtNS44OCAwLTcuMzc4Ljc2M2E3IDcgMCAwIDAtMy4wNTkgMy4wNloiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjxwYXRoIGZpbGw9IiNERkQ3RDUiIGQ9Ik0yNSAxM2MwLTIuOCAwLTQuMi41NDUtNS4yN2E1IDUgMCAwIDEgMi4xODUtMi4xODVDMjguOCA1IDMwLjIgNSAzMyA1aDJjMi44IDAgNC4yIDAgNS4yNy41NDVhNSA1IDAgMCAxIDIuMTg1IDIuMTg1QzQzIDguOCA0MyAxMC4yIDQzIDEzdjJjMCAyLjggMCA0LjItLjU0NSA1LjI3YTUgNSAwIDAgMS0yLjE4NSAyLjE4NUMzOS4yIDIzIDM3LjggMjMgMzUgMjNoLTJjLTIuOCAwLTQuMiAwLTUuMjctLjU0NWE1IDUgMCAwIDEtMi4xODUtMi4xODVDMjUgMTkuMiAyNSAxNy44IDI1IDE1di0yWiIvPjxwYXRoIGZpbGw9IiNFMUQ3RDUiIGQ9Ik0zOCA1aC04YTUgNSAwIDAgMC01IDV2OGE1IDUgMCAwIDAgNSA1aDhhNSA1IDAgMCAwIDUtNXYtOGE1IDUgMCAwIDAtNS01WiIvPjxwYXRoIGZpbGw9IiNEMjIyMDkiIGQ9Ik0zNy45MzggMTYuODEzaC03Ljg3NnYuNTYyaDcuODc1di0uNTYzWm0wIC41NjJoLTcuODc2di41NjNoNy44NzV2LS41NjNaIi8+PHBhdGggZmlsbD0iI0QyMjIwOSIgZD0iTTM3LjkzOCAxNy45MzhoLTcuODc2di41NjJoNy44NzV2LS41NjNabTAgLjU2MmgtNy44NzZ2LjU2M2g3Ljg3NVYxOC41WiIvPjxwYXRoIGZpbGw9IiNEMjIyMDkiIGQ9Ik0zMS4xODggMTkuMDYzaC0xLjEyNXYuNTYyaDEuMTI1di0uNTYzWm02Ljc1IDBIMzEuNzV2LjU2Mmg2LjE4OHYtLjU2M1ptLTYuNzUuNTYyaC0xLjEyNXYuNTYzaDEuMTI1di0uNTYzWm02Ljc1IDBIMzEuNzV2LjU2M2g2LjE4OHYtLjU2M1oiLz48cGF0aCBmaWxsPSIjRDIyMjA5IiBkPSJNMzEuMTg4IDIwLjE4OGgtMS4xMjV2LjU2MmgxLjEyNXYtLjU2M1ptNi43NSAwSDMxLjc1di41NjJoNi4xODh2LS41NjNabS02Ljc1LjU2MmgtMS4xMjV2LjU2M2gxLjEyNXYtLjU2M1ptNi43NSAwSDMxLjc1di41NjNoNi4xODh2LS41NjNaIi8+PHBhdGggZmlsbD0iI0QyMjIwOSIgZD0iTTMxLjE4OCAyMS4zMTNoLTEuMTI1di41NjJoMS4xMjV2LS41NjNabTYuNzUgMEgzMS43NXYuNTYyaDYuMTg4di0uNTYzWm0tNi43NS41NjJoLTEuMTI1di41NjNoMS4xMjV2LS41NjNabTYuNzUgMEgzMS43NXYuNTYzaDYuMTg4di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNEMjIyMDkiIGQ9Ik0zMS4xODggMjIuNDM4aC0xLjEyNVYyM2gxLjEyNXYtLjU2M1ptNi43NSAwSDMxLjc1VjIzaDYuMTg4di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0zMi44NzUgMTcuOTM4aC0uNTYzdi41NjJoLjU2M3YtLjU2M1ptMi4yNSAwSDM0di41NjJoMS4xMjV2LS41NjNabTEuMTI1IDBoLS41NjN2LjU2MmguNTYzdi0uNTYzWm0tMy4zNzUuNTYyaC0uNTYzdi41NjNoLjU2M1YxOC41Wm0yLjI1IDBIMzR2LjU2M2gxLjEyNVYxOC41Wm0xLjEyNSAwaC0uNTYzdi41NjNoLjU2M1YxOC41WiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0zMy40MzggMTkuMDYzaC0xLjEyNnYuNTYyaDEuMTI2di0uNTYzWm0xLjY4NyAwSDM0di41NjJoMS4xMjV2LS41NjNabTEuNjg4IDBoLTEuMTI2di41NjJoMS4xMjZ2LS41NjNaIi8+PHBhdGggZmlsbD0iI0MxNjcxMCIgZD0iTTMzLjQzOCA4LjM3NWgtLjU2M3YuNTYzaC41NjN2LS41NjNabTEuNjg3IDBIMzR2LjU2M2gxLjEyNXYtLjU2M1oiLz48cGF0aCBmaWxsPSIjRDRBMDE1IiBkPSJNMzEuNzUgOC45MzhoLTEuNjg4VjkuNWgxLjY4OHYtLjU2M1oiLz48cGF0aCBmaWxsPSIjQzE2NzEwIiBkPSJNMzUuNjg4IDguOTM4aC0zLjM3NlY5LjVoMy4zNzZ2LS41NjNaIi8+PHBhdGggZmlsbD0iI0Q0QTAxNSIgZD0iTTM3LjkzOCA4LjkzOEgzNi4yNVY5LjVoMS42ODh2LS41NjNaIi8+PHBhdGggZmlsbD0iI0MxNjcxMCIgZD0iTTMwLjA2MyA5LjVoLTEuMTI1di41NjNoMS4xMjVWOS41WiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zMS43NSA5LjVoLTEuNjg4di41NjNoMS42ODhWOS41WiIvPjxwYXRoIGZpbGw9IiNDMTY3MTAiIGQ9Ik0zNS4xMjUgOS41SDMxLjc1di41NjNoMy4zNzVWOS41WiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zNy45MzggOS41SDM2LjI1di41NjNoMS42ODhWOS41WiIvPjxwYXRoIGZpbGw9IiNDMTY3MTAiIGQ9Ik0zMC4wNjMgMTAuMDYzaC0xLjEyNXYuNTYyaDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zNCAxMC4wNjNoLTMuOTM4di41NjJIMzR2LS41NjNaIi8+PHBhdGggZmlsbD0iI0MxNjcxMCIgZD0iTTM0LjU2MyAxMC4wNjNIMzR2LjU2MmguNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zNy45MzggMTAuMDYzaC0zLjM3NnYuNTYyaDMuMzc2di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNDMTY3MTAiIGQ9Ik0zMC4wNjMgMTAuNjI1aC0xLjY4OHYuNTYzaDEuNjg4di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zMy40MzggMTAuNjI1aC0zLjM3NnYuNTYzaDMuMzc1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNGRkU5MzkiIGQ9Ik0zNS4xMjUgMTAuNjI1aC0xLjY4OHYuNTYzaDEuNjg4di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zNy45MzggMTAuNjI1aC0yLjgxM3YuNTYzaDIuODEzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNDMTY3MTAiIGQ9Ik0zMC4wNjMgMTEuMTg4aC0xLjEyNXYuNTYyaDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zNCAxMS4xODhoLTMuOTM4di41NjJIMzR2LS41NjNaIi8+PHBhdGggZmlsbD0iI0ZGRTkzOSIgZD0iTTM0LjU2MyAxMS4xODhIMzR2LjU2MmguNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zNy45MzggMTEuMTg4aC0zLjM3NnYuNTYyaDMuMzc2di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNDMTY3MTAiIGQ9Ik0zMC4wNjMgMTEuNzVoLTEuMTI1di41NjNoMS4xMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iI0Q0QTAxNSIgZD0iTTM0IDExLjc1aC0zLjkzOHYuNTYzSDM0di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNGRkU5MzkiIGQ9Ik0zNC41NjMgMTEuNzVIMzR2LjU2M2guNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zNy45MzggMTEuNzVoLTMuMzc2di41NjNoMy4zNzZ2LS41NjNaIi8+PHBhdGggZmlsbD0iI0MxNjcxMCIgZD0iTTMwLjA2MyAxMi4zMTNoLTEuNjg4di41NjJoMS42ODh2LS41NjNaIi8+PHBhdGggZmlsbD0iI0Q0QTAxNSIgZD0iTTM0IDEyLjMxM2gtMy45Mzh2LjU2MkgzNHYtLjU2M1oiLz48cGF0aCBmaWxsPSIjRkZFOTM5IiBkPSJNMzQuNTYzIDEyLjMxM0gzNHYuNTYyaC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI0Q0QTAxNSIgZD0iTTM3LjkzOCAxMi4zMTNoLTMuMzc2di41NjJoMy4zNzZ2LS41NjNaIi8+PHBhdGggZmlsbD0iI0MxNjcxMCIgZD0iTTMwLjA2MyAxMi44NzVoLTEuMTI1di41NjNoMS4xMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iI0Q0QTAxNSIgZD0iTTM0IDEyLjg3NWgtMy45Mzh2LjU2M0gzNHYtLjU2M1oiLz48cGF0aCBmaWxsPSIjRkZFOTM5IiBkPSJNMzQuNTYzIDEyLjg3NUgzNHYuNTYzaC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI0Q0QTAxNSIgZD0iTTM3LjkzOCAxMi44NzVoLTMuMzc2di41NjNoMy4zNzZ2LS41NjNaIi8+PHBhdGggZmlsbD0iI0MxNjcxMCIgZD0iTTMwLjA2MyAxMy40MzhoLTEuMTI1VjE0aDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNENEEwMTUiIGQ9Ik0zNCAxMy40MzhoLTMuOTM4VjE0SDM0di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNGRkU5MzkiIGQ9Ik0zNC41NjMgMTMuNDM4SDM0VjE0aC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI0Q0QTAxNSIgZD0iTTM3LjkzOCAxMy40MzhoLTMuMzc2VjE0aDMuMzc2di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNDMTY3MTAiIGQ9Ik0zMC4wNjMgMTRoLTEuNjg4di41NjNoMS42ODhWMTRaIi8+PHBhdGggZmlsbD0iI0QwOEIxMSIgZD0iTTQwLjE4OCAxNEgzMC4wNjJ2LjU2M2gxMC4xMjVWMTRaIi8+PHBhdGggZmlsbD0iI0MxNjcxMCIgZD0iTTMwLjA2MyAxNC41NjNoLTEuMTI1di41NjJoMS4xMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iI0QwOEIxMSIgZD0iTTM3LjkzOCAxNC41NjNoLTcuODc2di41NjJoNy44NzV2LS41NjNaIi8+PHBhdGggZmlsbD0iIzAwMCIgZD0iTTM4LjUgMTQuNTYzaC0uNTYzdi41NjJoLjU2M3YtLjU2M1oiLz48cGF0aCBmaWxsPSIjRDA4QjExIiBkPSJNMzkuMDYzIDE0LjU2M0gzOC41di41NjJoLjU2M3YtLjU2M1oiLz48cGF0aCBmaWxsPSIjMDAwIiBkPSJNMzkuNjI1IDE0LjU2M2gtLjU2M3YuNTYyaC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI0QwOEIxMSIgZD0iTTQwLjE4OCAxNC41NjNoLS41NjN2LjU2MmguNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNDMTY3MTAiIGQ9Ik0zMC4wNjMgMTUuMTI1aC0xLjY4OHYuNTYzaDEuNjg4di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNEMDhCMTEiIGQ9Ik0zMS4xODggMTUuMTI1aC0xLjEyNXYuNTYzaDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNGRkU5MzkiIGQ9Ik0zMS43NSAxNS4xMjVoLS41NjN2LjU2M2guNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiMwMDAiIGQ9Ik0zMi4zMTMgMTUuMTI1aC0uNTYzdi41NjNoLjU2M3YtLjU2M1oiLz48cGF0aCBmaWxsPSIjRkZFOTM5IiBkPSJNMzIuODc1IDE1LjEyNWgtLjU2M3YuNTYzaC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iIzAwMCIgZD0iTTMzLjQzOCAxNS4xMjVoLS41NjN2LjU2M2guNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNGRkU5MzkiIGQ9Ik0zNCAxNS4xMjVoLS41NjN2LjU2M0gzNHYtLjU2M1oiLz48cGF0aCBmaWxsPSIjMDAwIiBkPSJNMzQuNTYzIDE1LjEyNUgzNHYuNTYzaC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI0ZGRTkzOSIgZD0iTTM1LjEyNSAxNS4xMjVoLS41NjN2LjU2M2guNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNEMDhCMTEiIGQ9Ik00MC4xODggMTUuMTI1aC01LjA2M3YuNTYzaDUuMDYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNDMTY3MTAiIGQ9Ik0zMC4wNjMgMTUuNjg4aC0yLjI1di41NjJoMi4yNXYtLjU2M1oiLz48cGF0aCBmaWxsPSIjRDA4QjExIiBkPSJNNDAuMTg4IDE1LjY4OEgzMC4wNjJ2LjU2MmgxMC4xMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iI0MxNjcxMCIgZD0iTTMwLjA2MyAxNi4yNWgtMS42ODh2LjU2M2gxLjY4OHYtLjU2M1oiLz48cGF0aCBmaWxsPSIjRDA4QjExIiBkPSJNNDAuMTg4IDE2LjI1SDMwLjA2MnYuNTYzaDEwLjEyNXYtLjU2M1oiLz48cGF0aCBmaWxsPSIjQzE2NzEwIiBkPSJNMjguOTM4IDE2LjgxM2gtLjU2M3YuNTYyaC41NjN2LS41NjNabTEuMTI1IDBIMjkuNXYuNTYyaC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI0QwOEIxMSIgZD0iTTM3LjkzOCAxNi44MTNoLTcuODc2di41NjJoNy44NzV2LS41NjNaIi8+PHBhdGggZmlsbD0iI0I5MTg1QyIgZD0iTTM0IDExLjE4OGgtMy4zNzV2LjU2MkgzNHYtLjU2M1ptMy45MzggMGgtMy4zNzZ2LjU2MmgzLjM3NnYtLjU2M1ptLTYuNzUuNTYyaC0uNTYzdi41NjNoLjU2M3YtLjU2M1oiLz48cGF0aCBmaWxsPSIjZmZmIiBkPSJNMzIuMzEzIDExLjc1aC0xLjEyNnYuNTYzaDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiMwMDAiIGQ9Ik0zMy40MzggMTEuNzVoLTEuMTI2di41NjNoMS4xMjZ2LS41NjNaIi8+PHBhdGggZmlsbD0iI0I5MTg1QyIgZD0iTTM0IDExLjc1aC0uNTYzdi41NjNIMzR2LS41NjNabTEuMTI1IDBoLS41NjN2LjU2M2guNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0zNi4yNSAxMS43NWgtMS4xMjV2LjU2M2gxLjEyNXYtLjU2M1oiLz48cGF0aCBmaWxsPSIjMDAwIiBkPSJNMzcuMzc1IDExLjc1SDM2LjI1di41NjNoMS4xMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iI0I5MTg1QyIgZD0iTTM3LjkzOCAxMS43NWgtLjU2M3YuNTYzaC41NjN2LS41NjNabS02Ljc1LjU2M2gtMi4yNXYuNTYyaDIuMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTMyLjMxMyAxMi4zMTNoLTEuMTI2di41NjJoMS4xMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iIzAwMCIgZD0iTTMzLjQzOCAxMi4zMTNoLTEuMTI2di41NjJoMS4xMjZ2LS41NjNaIi8+PHBhdGggZmlsbD0iI0I5MTg1QyIgZD0iTTM1LjEyNSAxMi4zMTNoLTEuNjg4di41NjJoMS42ODh2LS41NjNaIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTM2LjI1IDEyLjMxM2gtMS4xMjV2LjU2MmgxLjEyNXYtLjU2M1oiLz48cGF0aCBmaWxsPSIjMDAwIiBkPSJNMzcuMzc1IDEyLjMxM0gzNi4yNXYuNTYyaDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNCOTE4NUMiIGQ9Ik0zNy45MzggMTIuMzEzaC0uNTYzdi41NjJoLjU2M3YtLjU2M1ptLTguNDM4LjU2MmgtLjU2M3YuNTYzaC41NjN2LS41NjNabTEuNjg4IDBoLS41NjN2LjU2M2guNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNmZmYiIGQ9Ik0zMi4zMTMgMTIuODc1aC0xLjEyNnYuNTYzaDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiMwMDAiIGQ9Ik0zMy40MzggMTIuODc1aC0xLjEyNnYuNTYzaDEuMTI2di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNCOTE4NUMiIGQ9Ik0zNCAxMi44NzVoLS41NjN2LjU2M0gzNHYtLjU2M1ptMS4xMjUgMGgtLjU2M3YuNTYzaC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTM2LjI1IDEyLjg3NWgtMS4xMjV2LjU2M2gxLjEyNXYtLjU2M1oiLz48cGF0aCBmaWxsPSIjMDAwIiBkPSJNMzcuMzc1IDEyLjg3NUgzNi4yNXYuNTYzaDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiNCOTE4NUMiIGQ9Ik0zNy45MzggMTIuODc1aC0uNTYzdi41NjNoLjU2M3YtLjU2M1ptLTguNDM4LjU2M2gtLjU2M1YxNGguNTYzdi0uNTYzWm0xLjY4OCAwaC0uNTYzVjE0aC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTMyLjMxMyAxMy40MzhoLTEuMTI2VjE0aDEuMTI1di0uNTYzWiIvPjxwYXRoIGZpbGw9IiMwMDAiIGQ9Ik0zMy40MzggMTMuNDM4aC0xLjEyNlYxNGgxLjEyNnYtLjU2M1oiLz48cGF0aCBmaWxsPSIjQjkxODVDIiBkPSJNMzQgMTMuNDM4aC0uNTYzVjE0SDM0di0uNTYzWm0xLjEyNSAwaC0uNTYzVjE0aC41NjN2LS41NjNaIi8+PHBhdGggZmlsbD0iI2ZmZiIgZD0iTTM2LjI1IDEzLjQzOGgtMS4xMjVWMTRoMS4xMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iIzAwMCIgZD0iTTM3LjM3NSAxMy40MzhIMzYuMjVWMTRoMS4xMjV2LS41NjNaIi8+PHBhdGggZmlsbD0iI0I5MTg1QyIgZD0iTTM3LjkzOCAxMy40MzhoLS41NjNWMTRoLjU2M3YtLjU2M1pNMzQgMTRoLTMuMzc1di41NjNIMzRWMTRabTMuOTM4IDBoLTMuMzc2di41NjNoMy4zNzZWMTRaIi8+PHBhdGggZmlsbD0iI2ZmZiIgZmlsbC1vcGFjaXR5PSIuMyIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMzUgNS41aC0yYy0xLjQwOCAwLTIuNDM1IDAtMy4yNDMuMDY2LS44MDMuMDY2LTEuMzQ3LjE5NC0xLjguNDI0YTQuNSA0LjUgMCAwIDAtMS45NjYgMS45NjdjLS4yMzEuNDUzLS4zNTkuOTk3LS40MjQgMS44LS4wNjcuODA4LS4wNjcgMS44MzUtLjA2NyAzLjI0M3YyYzAgMS40MDggMCAyLjQzNS4wNjcgMy4yNDMuMDY1LjgwMy4xOTMgMS4zNDcuNDI0IDEuOGE0LjUgNC41IDAgMCAwIDEuOTY2IDEuOTY2Yy40NTMuMjMxLjk5Ny4zNTkgMS44LjQyNC44MDguMDY3IDEuODM1LjA2NyAzLjI0My4wNjdoMmMxLjQwOCAwIDIuNDM1IDAgMy4yNDMtLjA2Ny44MDMtLjA2NSAxLjM0Ny0uMTkzIDEuOC0uNDI0YTQuNSA0LjUgMCAwIDAgMS45NjctMS45NjZjLjIzLS40NTMuMzU4LS45OTcuNDI0LTEuOC4wNjYtLjgwOC4wNjYtMS44MzUuMDY2LTMuMjQzdi0yYzAtMS40MDggMC0yLjQzNS0uMDY2LTMuMjQzLS4wNjYtLjgwMy0uMTk0LTEuMzQ3LS40MjQtMS44YTQuNSA0LjUgMCAwIDAtMS45NjctMS45NjdjLS40NTMtLjIzLS45OTctLjM1OC0xLjgtLjQyNEMzNy40MzUgNS41IDM2LjQwOCA1LjUgMzUgNS41Wm0tOS40NTUgMi4yM0MyNSA4LjggMjUgMTAuMiAyNSAxM3YyYzAgMi44IDAgNC4yLjU0NSA1LjI3YTUgNSAwIDAgMCAyLjE4NSAyLjE4NUMyOC44IDIzIDMwLjIgMjMgMzMgMjNoMmMyLjggMCA0LjIgMCA1LjI3LS41NDVhNSA1IDAgMCAwIDIuMTg1LTIuMTg1QzQzIDE5LjIgNDMgMTcuOCA0MyAxNXYtMmMwLTIuOCAwLTQuMi0uNTQ1LTUuMjdhNSA1IDAgMCAwLTIuMTg1LTIuMTg1QzM5LjIgNSAzNy44IDUgMzUgNWgtMmMtMi44IDAtNC4yIDAtNS4yNy41NDVhNSA1IDAgMCAwLTIuMTg1IDIuMTg1WiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PHBhdGggZmlsbD0iIzU2NENCRiIgZD0iTTUgMzNjMC0yLjggMC00LjIuNTQ1LTUuMjdhNSA1IDAgMCAxIDIuMTg1LTIuMTg1QzguOCAyNSAxMC4yIDI1IDEzIDI1aDJjMi44IDAgNC4yIDAgNS4yNy41NDVhNSA1IDAgMCAxIDIuMTg1IDIuMTg1QzIzIDI4LjggMjMgMzAuMiAyMyAzM3YyYzAgMi44IDAgNC4yLS41NDUgNS4yN2E1IDUgMCAwIDEtMi4xODUgMi4xODVDMTkuMiA0MyAxNy44IDQzIDE1IDQzaC0yYy0yLjggMC00LjIgMC01LjI3LS41NDVhNSA1IDAgMCAxLTIuMTg1LTIuMTg1QzUgMzkuMiA1IDM3LjggNSAzNXYtMloiLz48cGF0aCBmaWxsPSIjRkY2NkIzIiBkPSJNMTEuMTg4IDI2LjEyNWguNTYydjIuODEzaC41NjN2LTIuODEzaC41NjJWMjkuNWguNTYzdi0zLjM3NUgxNFYyOS41aC41NjN2LTMuMzc1aC41NjJ2Mi44MTNoLjU2M3YtMi44MTNoLjU2MnYyLjI1aC41NjN2LTEuNjg4aC41NjJ2Mi4yNWgtLjU2M3YuNTYzaC0uNTYydi41NjNoLTEuMTI1di41NjJoLTIuODEzdi0uNTYzaC0xLjEyNFYyOS41aC0uNTYzdi0uNTYzaC0uNTYzdi0yLjI1aC41NjN2MS42ODhoLjU2M3YtMi4yNVoiLz48cGF0aCBmaWxsPSIjQjNGRkNDIiBkPSJNMTMuNDM4IDMwLjYyNUgxNHYuNTYzaDEuMTI1djIuMjVoMS4xMjV2LS41NjNoLjU2M1YzNGgtMS42ODh2MS4xMjVoLS41NjN2MS4xMjVoLjU2M3Y1LjYyNWgtLjU2M3YtNS4wNjNIMTR2LS41NjJoLTEuNjg4di0xLjEyNWguNTYzdi41NjNIMTR2LTEuMTI2aC41NjNWMzEuNzVoLTEuMTI2di0xLjEyNVoiLz48cGF0aCBmaWxsPSIjMDAwIiBmaWxsLW9wYWNpdHk9Ii45IiBkPSJNMTYuMjUgMjYuMTI1aC41NjN2Mi4yNWgtLjU2M3YtMi4yNVptLTUuNjI1LjU2M2guNTYzdjEuNjg3aC0uNTYzdi0xLjY4OFoiLz48cGF0aCBmaWxsPSIjMDAwIiBmaWxsLW9wYWNpdHk9Ii45IiBkPSJNMTcuOTM4IDI2LjY4OGgtLjU2M3YyLjI1aC0uNTYzdi41NjJoLS41NjJ2LjU2M2guNTYzVjI5LjVoLjU2MnYtLjU2M2guNTYzdi0yLjI1Wm0tNi4xODgtLjU2M2guNTYzdjIuODEzaC0uNTYzdi0yLjgxM1ptMy45MzggMGgtLjU2M3YyLjgxM2guNTYzdi0yLjgxM1ptLTIuODEzIDBoLjU2M1YyOS41aC0uNTYzdi0zLjM3NVptMS42ODggMEgxNFYyOS41aC41NjN2LTMuMzc1Wm0uNTYyIDMuOTM4aC41NjN2LjU2MmgtLjU2M3YtLjU2M1ptLS41NjIuNTYySDE0di41NjNoLjU2M3YtLjU2M1ptLjU2Mi41NjNoLjU2M3YyLjI1aC0uNTYzdi0yLjI1Wm0yLjI1IDEuNjg3aC0uNTYzVjM0aC41NjN2LTEuMTI1Wk0xNS4xMjUgMzRoLjU2M3YxLjEyNWgtLjU2M1YzNFptMCAyLjI1di0xLjEyNWgtLjU2M3YxLjEyNWguNTYzWm0wIDB2NS42MjVoLjU2M1YzNi4yNWgtLjU2M1ptLTIuMjUtMS4xMjVoLjU2M3YuNTYzaC0uNTYzdi0uNTYzWiIvPjxwYXRoIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iLjEyIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xNSAyNS41aC0yYy0xLjQwOCAwLTIuNDM1IDAtMy4yNDMuMDY3LS44MDMuMDY1LTEuMzQ3LjE5My0xLjguNDI0YTQuNSA0LjUgMCAwIDAtMS45NjcgMS45NjZjLS4yMy40NTMtLjM1OC45OTctLjQyNCAxLjhDNS41IDMwLjU2NSA1LjUgMzEuNTkyIDUuNSAzM3YyYzAgMS40MDggMCAyLjQzNS4wNjYgMy4yNDMuMDY2LjgwMy4xOTQgMS4zNDcuNDI0IDEuOGE0LjUgNC41IDAgMCAwIDEuOTY3IDEuOTY3Yy40NTMuMjMuOTk3LjM1OCAxLjguNDI0LjgwOC4wNjYgMS44MzUuMDY2IDMuMjQzLjA2NmgyYzEuNDA4IDAgMi40MzUgMCAzLjI0My0uMDY2LjgwMy0uMDY2IDEuMzQ3LS4xOTQgMS44LS40MjRhNC41IDQuNSAwIDAgMCAxLjk2Ni0xLjk2N2MuMjMxLS40NTMuMzU5LS45OTcuNDI0LTEuOC4wNjctLjgwOC4wNjctMS44MzUuMDY3LTMuMjQzdi0yYzAtMS40MDggMC0yLjQzNS0uMDY3LTMuMjQzLS4wNjUtLjgwMy0uMTkzLTEuMzQ3LS40MjQtMS44YTQuNSA0LjUgMCAwIDAtMS45NjYtMS45NjZjLS40NTMtLjIzMS0uOTk3LS4zNTktMS44LS40MjQtLjgwOC0uMDY3LTEuODM1LS4wNjctMy4yNDMtLjA2N1ptLTkuNDU1IDIuMjNDNSAyOC44IDUgMzAuMiA1IDMzdjJjMCAyLjggMCA0LjIuNTQ1IDUuMjdhNSA1IDAgMCAwIDIuMTg1IDIuMTg1QzguOCA0MyAxMC4yIDQzIDEzIDQzaDJjMi44IDAgNC4yIDAgNS4yNy0uNTQ1YTUgNSAwIDAgMCAyLjE4NS0yLjE4NUMyMyAzOS4yIDIzIDM3LjggMjMgMzV2LTJjMC0yLjggMC00LjItLjU0NS01LjI3YTUgNSAwIDAgMC0yLjE4NS0yLjE4NUMxOS4yIDI1IDE3LjggMjUgMTUgMjVoLTJjLTIuOCAwLTQuMiAwLTUuMjcuNTQ1YTUgNSAwIDAgMC0yLjE4NSAyLjE4NVoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjxwYXRoIGZpbGw9IiMxNzJEOTkiIGQ9Ik01IDEzYzAtMi44IDAtNC4yLjU0NS01LjI3QTUgNSAwIDAgMSA3LjczIDUuNTQ1QzguOCA1IDEwLjIgNSAxMyA1aDJjMi44IDAgNC4yIDAgNS4yNy41NDVhNSA1IDAgMCAxIDIuMTg1IDIuMTg1QzIzIDguOCAyMyAxMC4yIDIzIDEzdjJjMCAyLjggMCA0LjItLjU0NSA1LjI3YTUgNSAwIDAgMS0yLjE4NSAyLjE4NUMxOS4yIDIzIDE3LjggMjMgMTUgMjNoLTJjLTIuOCAwLTQuMiAwLTUuMjctLjU0NWE1IDUgMCAwIDEtMi4xODUtMi4xODVDNSAxOS4yIDUgMTcuOCA1IDE1di0yWiIvPjxwYXRoIGZpbGw9IiMwMEEyRDgiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTExLjMgMTMuMUg4LjZ2LjloMi43di0uOVptMCAuOWgxLjh2LjloLjl2MS44aC0uOXYtLjloLS45di0uOWgtLjlWMTRabTIuNyAyLjdoLjl2Mi43SDE0di0yLjdaIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48cGF0aCBmaWxsPSIjMDBERTZGIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMS4zIDEyLjJIOC42di45aDIuN3YtLjlabTAgLjloMS44di45aC0xLjh2LS45Wm0yLjcgMS44aC0uOVYxNGguOXYuOVptLjkgMS44SDE0di0xLjhoLjl2MS44Wm0wIDBoLjl2Mi43aC0uOXYtMi43WiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PHBhdGggZmlsbD0iI0ZGRUIwMCIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMTEuMyAxMS4zSDguNnYuOWgyLjd2LS45Wm0wIC45aDEuOHYuOWgtMS44di0uOVpNMTQgMTRoLS45di0uOWguOXYuOVptLjkuOUgxNFYxNGguOXYuOVptLjkgMS44aC0uOXYtMS44aC45djEuOFptMCAwaC45djIuN2gtLjl2LTIuN1oiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjxwYXRoIGZpbGw9IiNGQTAiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTExLjMgMTAuNEg4LjZ2LjloMi43di0uOVptMCAuOUgxNHYuOWguOXYuOWguOXYuOWguOXYxLjhoLjl2My42aC0uOXYtMi43aC0uOXYtMS44aC0uOVYxNEgxNHYtLjloLS45di0uOWgtMS44di0uOVoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjxwYXRoIGZpbGw9IiNERDNEMUMiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTEyLjIgOS41SDguNnYuOWgyLjd2LjlIMTR2LjloLjl2LjloLjl2LjloLjl2MS44aC45djMuNmguOXYtMy42aC0uOVYxNGgtLjl2LS45aC0uOXYtLjloLS45di0uOUgxNHYtLjloLTEuOHYtLjlaIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48cGF0aCBmaWxsPSIjQzAzMDc4IiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMi4yIDguNkg4LjZ2LjloMy42di0uOVptMCAuOUgxNHYuOWgtMS44di0uOVptNS40IDQuNWgtLjl2LS45aC0uOXYtLjloLS45di0uOUgxNHYtLjloMS44di45aC45di45aC45VjE0Wm0uOSAxLjhoLS45VjE0aC45djEuOFptMCAwaC45djMuNmgtLjl2LTMuNloiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjxwYXRoIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iLjEyIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xNSA1LjVoLTJjLTEuNDA4IDAtMi40MzUgMC0zLjI0My4wNjYtLjgwMy4wNjYtMS4zNDcuMTk0LTEuOC40MjRBNC41IDQuNSAwIDAgMCA1Ljk5IDcuOTU3Yy0uMjMuNDUzLS4zNTguOTk3LS40MjQgMS44QzUuNSAxMC41NjUgNS41IDExLjU5MiA1LjUgMTN2MmMwIDEuNDA4IDAgMi40MzUuMDY2IDMuMjQzLjA2Ni44MDMuMTk0IDEuMzQ3LjQyNCAxLjhhNC41IDQuNSAwIDAgMCAxLjk2NyAxLjk2NmMuNDUzLjIzMS45OTcuMzU5IDEuOC40MjQuODA4LjA2NyAxLjgzNS4wNjcgMy4yNDMuMDY3aDJjMS40MDggMCAyLjQzNSAwIDMuMjQzLS4wNjcuODAzLS4wNjUgMS4zNDctLjE5MyAxLjgtLjQyNGE0LjUgNC41IDAgMCAwIDEuOTY2LTEuOTY2Yy4yMzEtLjQ1My4zNTktLjk5Ny40MjQtMS44LjA2Ny0uODA4LjA2Ny0xLjgzNS4wNjctMy4yNDN2LTJjMC0xLjQwOCAwLTIuNDM1LS4wNjctMy4yNDMtLjA2NS0uODAzLS4xOTMtMS4zNDctLjQyNC0xLjhhNC41IDQuNSAwIDAgMC0xLjk2Ni0xLjk2N2MtLjQ1My0uMjMtLjk5Ny0uMzU4LTEuOC0uNDI0QzE3LjQzNSA1LjUgMTYuNDA4IDUuNSAxNSA1LjVaTTUuNTQ1IDcuNzNDNSA4LjggNSAxMC4yIDUgMTN2MmMwIDIuOCAwIDQuMi41NDUgNS4yN2E1IDUgMCAwIDAgMi4xODUgMi4xODVDOC44IDIzIDEwLjIgMjMgMTMgMjNoMmMyLjggMCA0LjIgMCA1LjI3LS41NDVhNSA1IDAgMCAwIDIuMTg1LTIuMTg1QzIzIDE5LjIgMjMgMTcuOCAyMyAxNXYtMmMwLTIuOCAwLTQuMi0uNTQ1LTUuMjdhNSA1IDAgMCAwLTIuMTg1LTIuMTg1QzE5LjIgNSAxNy44IDUgMTUgNWgtMmMtMi44IDAtNC4yIDAtNS4yNy41NDVBNSA1IDAgMCAwIDUuNTQ1IDcuNzNaIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48cGF0aCBmaWxsPSIjOTlCM0ZGIiBkPSJNNDggMzYuNUM0OCA0Mi44NTEgNDIuODUxIDQ4IDM2LjUgNDhTMjUgNDIuODUxIDI1IDM2LjUgMzAuMTQ5IDI1IDM2LjUgMjUgNDggMzAuMTQ5IDQ4IDM2LjVaIi8+PHBhdGggZmlsbD0iIzAwMCIgZmlsbC1vcGFjaXR5PSIuMTIiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTM2LjUgNDcuNWM2LjA3NSAwIDExLTQuOTI1IDExLTExcy00LjkyNS0xMS0xMS0xMS0xMSA0LjkyNS0xMSAxMSA0LjkyNSAxMSAxMSAxMVptMCAuNUM0Mi44NTEgNDggNDggNDIuODUxIDQ4IDM2LjVTNDIuODUxIDI1IDM2LjUgMjUgMjUgMzAuMTQ5IDI1IDM2LjUgMzAuMTQ5IDQ4IDM2LjUgNDhaIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiLz48cGF0aCBmaWxsPSIjN0Y5MUVCIiBkPSJNNDYgMzYuNWE5LjUgOS41IDAgMSAxLTE5IDAgOS41IDkuNSAwIDAgMSAxOSAwWiIvPjxwYXRoIGZpbGw9IiMwMDAiIGZpbGwtb3BhY2l0eT0iLjEyIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0zNi41IDQ1LjVhOSA5IDAgMSAwIDAtMTggOSA5IDAgMCAwIDAgMThabTAgLjVhOS41IDkuNSAwIDEgMCAwLTE5IDkuNSA5LjUgMCAwIDAgMCAxOVoiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjxwYXRoIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iLjIiIGZpbGwtcnVsZT0iZXZlbm9kZCIgZD0iTTMxLjkxMiAzNy4wMzdhLjUuNSAwIDAgMS0uMTM5LS42NjVsNC4yOTgtNy4xM2EuNS41IDAgMCAxIC44NTYgMGw0LjI5NyA3LjEzYS41LjUgMCAwIDEtLjEzNy42NjQuNS41IDAgMCAxIC4xMTkuNjk4bC00LjMgNi4wNTVhLjUuNSAwIDAgMS0uODE1IDBsLTQuMjk3LTYuMDU1YS41LjUgMCAwIDEgLjExOC0uNjk3Wm0uMjkuNDA4IDQuMjk3IDIuNTM4IDQuMy0yLjUzOC00LjMgNi4wNTUtNC4yOTctNi4wNTVabTAtLjgxNSA0LjI5Ny03LjEzIDQuMjk3IDcuMTMtNC4yOTcgMi41NC00LjI5Ny0yLjU0WiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PHBhdGggZmlsbD0iIzAwMCIgZmlsbC1vcGFjaXR5PSIuNTUiIGQ9Ik0zNi40OTkgMjkuNXY5LjY3bDQuMjk3LTIuNTQtNC4yOTctNy4xM1oiLz48cGF0aCBmaWxsPSIjMDAwIiBmaWxsLW9wYWNpdHk9Ii4zIiBkPSJtMzYuNDk5IDI5LjUtNC4yOTcgNy4xMyA0LjI5NyAyLjU0VjI5LjVaIi8+PHBhdGggZmlsbD0iIzAwMCIgZmlsbC1vcGFjaXR5PSIuNTUiIGQ9Ik0zNi40OTkgMzkuOTgzVjQzLjVsNC4zLTYuMDU1LTQuMyAyLjUzOFoiLz48cGF0aCBmaWxsPSIjMDAwIiBmaWxsLW9wYWNpdHk9Ii4zIiBkPSJNMzYuNDk5IDQzLjV2LTMuNTE3bC00LjI5Ny0yLjUzOCA0LjI5NyA2LjA1NVoiLz48cGF0aCBmaWxsPSIjMDAwIiBkPSJtMzYuNDk5IDM5LjE3IDQuMjk3LTIuNTQtNC4yOTctMS45NTN2NC40OTNaIi8+PHBhdGggZmlsbD0iIzAwMCIgZmlsbC1vcGFjaXR5PSIuNiIgZD0ibTMyLjIwMiAzNi42MyA0LjI5NyAyLjU0di00LjQ5M2wtNC4yOTcgMS45NTNaIi8+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJhIiB4MT0iMjQiIHgyPSIyNCIgeTE9IjAiIHkyPSI0OCIgZ3JhZGllbnRVbml0cz0idXNlclNwYWNlT25Vc2UiPjxzdG9wIHN0b3AtY29sb3I9IiMxNzQyOTkiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMwMDFFNTkiLz48L2xpbmVhckdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0iYiIgeDE9IjI0IiB4Mj0iMjQiIHkxPSIwIiB5Mj0iNDgiIGdyYWRpZW50VW5pdHM9InVzZXJTcGFjZU9uVXNlIj48c3RvcCBzdG9wLWNvbG9yPSIjRDJEOEU0Ii8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjQzJDOUQ2Ii8+PC9saW5lYXJHcmFkaWVudD48L2RlZnM+PC9zdmc+";
