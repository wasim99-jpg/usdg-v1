import { Col, Row } from "antd";
import React from "react";

export default function Gran2({size}) {
  return (
    <div className="mg-top-200">
      <Row justify="space-between">
        <Col xl={10} lg={10} md={24} xs={24} sm={24}>
          <p  className={`${size == 'xl' ? 'fs-3rem' : 'fs-2rem'} fw-bold`}>Want to Contribute to CRYSTAL?</p>
        </Col>
        <Col xl={12} lg={12} md={24} xs={24} sm={24}>
          <p>
            Olympus Grants' mission is to expand the econOHMy, targeting
            projects that will bring new groups of participants into the Olympus
            ecosystem and extend OHM into new Web3 communities.
          </p>
        </Col>
      </Row>
      <Row gutter={[12, 12]}>
        <Col xl={8} lg={8} md={24} xs={24} sm={24}>
          <div className="bd-1-solid-black bd-rad-30 pd-1rem">
            <img
              height={80}
              src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6247321de4c3070a5cbae2fa_image-2.png"
              alt=""
            />
            <p className="fs-2rem">Education</p>
            <p className="h-50">Projects that educate about Olympus</p>
          </div>
        </Col>
        <Col xl={8} lg={8} md={24} xs={24} sm={24}>
          <div className="bd-1-solid-black bd-rad-30 pd-1rem">
            <img
              height={80}
              src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6247321cd836151c73e3017b_image-1.png"
              alt=""
            />
            <p className="fs-2rem">Infrastructure</p>
            <p className="h-50">Projects that improve/expand infrastructure of Olympus</p>
          </div>
        </Col>
        <Col xl={8} lg={8} md={24} xs={24} sm={24}>
          <div className="bd-1-solid-black bd-rad-30 pd-1rem">
            <img
              height={80}
              src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6247321d08457b46b8cd79ef_image.png"
              alt=""
            />
            <p className="fs-2rem">Utility</p>
            <p  className="h-50">Projects that increase utility of OHM</p>
          </div>
        </Col>
      </Row>
    </div>
  );
}
