import React, { useEffect, useState } from 'react'
import Gran1 from './Gran1'
import Gran2 from './Gran2'
import Gran3 from './Gran3'
import Gran4 from './Gran4'

export default function IndexGrant({size}) {
  const [paddingHor, setPaddingHor] = useState('pd-hor-3rem')
  useEffect(() => {
    if (size == 'lg') {
      setPaddingHor('pd-hor-3rem')
    }
    else if(size == 'md'){
      setPaddingHor('pd-hor-2rem')
    }
    else if (size == 'sm' || size == 'xs') {
      setPaddingHor('pd-hor-1rem')
    }
  }, [size])
  return (
    <div className={`${paddingHor}`}>
        <Gran1 size={size}/>
        <Gran2 size={size}/>
        <Gran3 size={size}/>
        <Gran4 size={size}/>
    </div>
  )
}
