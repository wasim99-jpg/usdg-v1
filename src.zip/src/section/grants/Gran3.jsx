import { Col, Row } from "antd";
import React from "react";
import ArrowRight from "../../asset/img/arrow-right.png";

export default function Gran3({size}) {
  return (
    <div className="mg-top-200">
      <p className={`${size == 'xl' ? 'fs-3rem' : 'fs-2rem'} fw-bold`}>Meet the Grantees</p>
      <Row>
        <Col xl={6} lg={6} md={0} xs={0} sm={0}></Col>
        <Col xl={18} lg={18}  md={24} xs={24} sm={24}>
          <Row gutter={[8, 8]}>
            <Col xl={8} lg={12} md={8} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray pd-1rem">
                <div className="d-flex jus-between ">
                  <img
                    height={40}
                    src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624e13e9bc4d64553a0ea915_solana_logo.svg"
                    alt=""
                  />
                  <img src={ArrowRight} alt="" height={30}/>
                </div>
                <div className="mg-top-40 h-120">
                    <p className="fs-1dot2rem mg-0">Solana</p>
                    <p className="fs-0dot8rem">Integrating CRYSTAL into Solana ecosystem.</p>
                </div>
              </div>
            </Col>
            <Col xl={8} lg={12} md={8} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray pd-1rem">
                <div className="d-flex jus-between ">
                  <img
                    height={40}
                    src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/6255bca53726a34ecccc3bcc_terra_logo%201.png"
                    alt=""
                  />
                  <img src={ArrowRight} alt="" height={30}/>
                </div>
                <div className="mg-top-40 h-120">
                    <p className="fs-1dot2rem mg-0">Terra</p>
                    <p className="fs-0dot8rem">Integrating CRYSTAL into Terra ecosystem.</p>
                </div>
              </div>
            </Col>
            <Col xl={8}  lg={12} md={8} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray pd-1rem">
                <div className="d-flex jus-between ">
                  <img
                    height={40}
                    src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624724e05cf06e396fd5953b_metamars_logo%201.png"
                    alt=""
                  />
                  <img src={ArrowRight} alt="" height={30}/>
                </div>
                <div className="mg-top-40 h-120">
                    <p className="fs-1dot2rem mg-0">MetaMars</p>
                    <p className="fs-0dot8rem">A collection of “no-loss” arcade games that enables everyone to play for free, but rewards the best space cadets for their mastery of the Martian landscape </p>
                </div>
              </div>
            </Col>
            <Col xl={8} lg={12} md={8} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray pd-1rem">
                <div className="d-flex jus-between ">
                  <img
                    height={40}
                    src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/624724f5786c440fb5aaf20c_Group%2025.png"
                    alt=""
                  />
                  <img src={ArrowRight} alt="" height={30}/>
                </div>
                <div className="mg-top-40 h-120">
                    <p className="fs-1dot2rem mg-0">Playground</p>
                    <p className="fs-0dot8rem">Arms users with tools and knowledge to improve their strategies and understanding of Olympus in particular, and DeFi more generally.</p>
                </div>
              </div>
            </Col>
            <Col xl={8} lg={12} md={8} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray pd-1rem">
                <div className="d-flex jus-between ">
                  <img
                    height={40}
                    src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/62472528fa2e2d375c33b6c4_Group%2026.png"
                    alt=""
                  />
                  <img src={ArrowRight} alt="" height={30}/>
                </div>
                <div className="mg-top-40 h-120">
                    <p className="fs-1dot2rem mg-0">Mover DAO</p>
                    <p className="fs-0dot8rem">Creating an Olympus payment app and implementing permissionless, gasless transactions.</p>
                </div>
              </div>
            </Col>
            <Col xl={8} lg={12} md={8} xs={24} sm={24}>
              <div className="bd-top-bot-1-solid-gray pd-1rem">
                <div className="d-flex jus-between ">
                  <img
                    height={40}
                    src="https://assets.website-files.com/6224c291c2e3b006b3d956cb/6247256d8ece7d035c2ac25b_metricsdao_logo%201.png"
                    alt=""
                  />
                  <img src={ArrowRight} alt="" height={30}/>
                </div>
                <div className="mg-top-40 h-120">
                    <p className="fs-1dot2rem mg-0">EntropyFi</p>
                    <p className="fs-0dot8rem">Provides safer risk-on and risk-off options for OHM stakers via soft-hedge and soft-leverage.</p>
                </div>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>
    </div>
  );
}
