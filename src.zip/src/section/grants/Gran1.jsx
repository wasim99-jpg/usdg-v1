import { Col, Row } from "antd";
import React from "react";
import BaseButton from "../../component/BaseButton";

export default function Gran1({size}) {
  return (
    <div>
      <Row justify="space-between" gutter={[, 30]}>

        <Col xl={{span: 12, order: 2}} lg={{span: 12, order: 2}} md={24} xs={24} sm={24}>
          <video
            id="hero-video"
            autoplay=""
            loop=""
            class="content-cover"
            muted=""
            playsinline=""
            data-wf-ignore="true"
            data-object-fit="cover"
            style={{ width: "100%", borderRadius: 30 }}
          >
            <source
              src="https://storage.googleapis.com/landing-page-420/Web%20Videos%20%5BFor%20Hosting%5D/grants-desktop.mp4"
              data-src="https://storage.googleapis.com/landing-page-420/Web%20Videos%20%5BFor%20Hosting%5D/grants-desktop.mp4"
              data-wf-ignore="true"
            />
          </video>
        </Col>
        <Col xl={{span: 10, order: 1}} lg={{span: 12, order: 1}} md={24} xs={24} sm={24}>
          <p  className={`${size == 'xl' ? 'fs-3rem' : 'fs-2rem'} fw-bold`}>
            Olympus Community Grants Program expanding the econOHMy
          </p>
          <p>
            Introducing Olympus’ Grants Program for activating and extending the
            Olympus ecosystem
          </p>
          <div className={size != 'xl' || size != 'lg' ? 'txt-center': ''}>
            <BaseButton
              bgHv="white"
              content="Apply for grants"
              bgColor="black"
              color="white"
              px={20}
              py={10}
              bRad={20}
            />
          </div>
        </Col>
      </Row>
    </div>
  );
}
