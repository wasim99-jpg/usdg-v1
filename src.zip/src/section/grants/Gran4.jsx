import { Col, Row } from "antd";
import React from "react";
import BaseButton from "../../component/BaseButton";

export default function Gran4({size}) {
  return (
    <div className="mg-top-200">
      <Row justify="space-between">
        <Col xl={10} lg={10} md={24} sm={24} xs={24}>
          <p className={`${size == 'xl' ? 'fs-3rem' : 'fs-2rem'} fw-bold`}>What is CRYSTAL Grants?</p>
        </Col>
        <Col xl={12} lg={10} md={24} sm={24} xs={24}>
          <Row gutter={10}>
            <Col xl={12} lg={12} md={24} sm={24} xs={24}>
              <p className="fs-1rem">
              CRYSTAL Grants is designed to fill various gaps in the CRYSTAL
                ecosystem by funding projects which support the DAO’s
                initiatives but don’t fit into existing projects. Where a token
                swap, incubator investment, or yield-redirection is not quite
                right, CRYSTAL Grants will fill the gap. The OGP(CRYSTAL Grants
                Program) is funded with $1.5 M of DAO approved $OHM. OGP 1 will
                run over a 3.3 month period as an MVP and reevaluate{" "}
              </p>
            </Col>
            <Col span={12}  lg={12} md={24} sm={24} xs={24}>
              <p className="fs-1rem">
              after that period, wherein a report will be provided to the
                community with suggested next actions. OGP is built to bolster
                the objectives of other departments such as Partnerships, CRYSTAL
                Pro, Incubator, and Give in ways that require a more flexible
                funding mechanism. And in true LFG spirit, CRYSTAL has selected 13
                new initial grantees (and a partnership with Gitcoin) to help
                kick off our Grants Program!
              </p>
            </Col>
          </Row>
        </Col>
      </Row>
      <div className="mg-top-200 txt-center">
        <p className={`${size == 'xl' ? 'fs-3rem' : 'fs-2rem'} fw-bold`}>Explore our Grants Program</p>
        <p className="fs-1rem">
          Olympus Grants is your go to for getting involved in the Olympus
          Ecosystem
        </p>
        <div className="mg-bot-20">
          <BaseButton
            bgHv="white"
            content="Apply now"
            bgColor="black"
            color="white"
            px={20}
            py={10}
            bRad={20}
          />
        </div>
        <div>
          <img
            width='100%'
            style={{maxWidth: 400}}
            src="https://assets.website-files.com/621f51702b01b7fee7ff903a/6246e99c2f302ea48df041e8_Group%2023.png"
            alt=""
          />
        </div>
      </div>
    </div>
  );
}
