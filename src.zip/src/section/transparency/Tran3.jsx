import { Col, Row } from "antd";
import React from "react";

export default function Tran3({size}) {
  return (
    <div className="mg-top-200 cl-black">
      <Row>
        <Col xl={8} lg={8} md={0} xs={0} sm={0}></Col>
        <Col xl={16} lg={16} md={24} xs={24} sm={24}>
          <p className={`${size == 'xl' || size == 'lg' ? 'fs-3rem': 'fs-2rem'} fw-bold mg-0`}>Governance Flows</p>
          <p className="">
            Olympus' Treasury and Governance are two of our protocol's most
            important aspects. Discover the assets, addresses, and reports for
            these elements and how governance shapes them, below.
          </p>
          <div className="txt-center">
            <img
              width='100%'
              src="https://assets.website-files.com/621f51702b01b7fee7ff903a/62873dc64ff1f9107efeb2ba_Group%207043.svg"
              alt=""
            />
          </div>
        </Col>
      </Row>
    </div>
  );
}
