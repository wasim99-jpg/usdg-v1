import { Col, Row } from 'antd';
import React from 'react';
import ArrowRight from "../../asset/img/arrow-right.png";

export default function Tran5({size}) {
  return (
    <div className="cl-black mg-top-200">
        <p className={`${size == 'xl' || size == 'lg' ? 'fs-3rem': 'fs-2rem'} fw-bold`}>Related Links</p>
        <Row gutter={[16, 16]} className='mg-bot-20'>
            <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                <div className='bd-1-solid-black bd-rad-30 pd-1rem cu-po hv-2 trans-0dot4s'>
                    <div className='d-flex jus-between'>
                        <p className={`${size == 'xl' ? 'fs-2rem': 'fs-1dot2rem'}`}>Bonding</p>
                        <img src={ArrowRight} alt="" height={30}/>
                    </div>
                    <div className='h-30'></div>
                </div>
            </Col>
            <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                <div className='bd-1-solid-black bd-rad-30 pd-1rem cu-po hv-2 trans-0dot4s'>
                    <div className='d-flex jus-between'>
                        <p className={`${size == 'xl' ? 'fs-2rem': 'fs-1dot2rem'}`}>Docs</p>
                        <img src={ArrowRight} alt="" height={30}/>
                    </div>
                    <div className='h-30'></div>
                </div>
            </Col>
            <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                <div className='bd-1-solid-black bd-rad-30 pd-1rem cu-po hv-2 trans-0dot4s'>
                    <div className='d-flex jus-between'>
                        <p className={`${size == 'xl' ? 'fs-2rem': 'fs-1dot2rem'}`}>Forum</p>
                        <img src={ArrowRight} alt="" height={30}/>
                    </div>
                    <div className='h-30'></div>
                </div>
            </Col>
            <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                <div className='bd-1-solid-black bd-rad-30 pd-1rem cu-po hv-2 trans-0dot4s'>
                    <div className='d-flex jus-between'>
                        <p className={`${size == 'xl' ? 'fs-2rem': 'fs-1dot2rem'}`}>CRYSTAL Grants</p>
                        <img src={ArrowRight} alt="" height={30}/>
                    </div>
                    <div className='h-30'></div>
                </div>
            </Col>
            <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                <div className='bd-1-solid-black bd-rad-30 pd-1rem cu-po hv-2 trans-0dot4s'>
                    <div className='d-flex jus-between'>
                        <p className={`${size == 'xl' ? 'fs-2rem': 'fs-1dot2rem'}`}>Docs</p>
                        <img src={ArrowRight} alt="" height={30}/>
                    </div>
                    <div className='h-30'></div>
                </div>
            </Col>
            <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                <div className='bd-1-solid-black bd-rad-30 pd-1rem cu-po hv-2 trans-0dot4s'>
                    <div className='d-flex jus-between'>
                        <p className={`${size == 'xl' ? 'fs-2rem': 'fs-1dot2rem'}`}>CRYSTAL Pro</p>
                        <img src={ArrowRight} alt="" height={30}/>
                    </div>
                    <div className='h-30'></div>
                </div>
            </Col>
            <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                <div className='bd-1-solid-black bd-rad-30 pd-1rem cu-po hv-2 trans-0dot4s'>
                    <div className='d-flex jus-between'>
                        <p className={`${size == 'xl' ? 'fs-2rem': 'fs-1dot2rem'}`}>Staking</p>
                        <img src={ArrowRight} alt="" height={30}/>
                    </div>
                    <div className='h-30'></div>
                </div>
            </Col>
            <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                <div className='bd-1-solid-black bd-rad-30 pd-1rem cu-po hv-2 trans-0dot4s'>
                    <div className='d-flex jus-between'>
                        <p className={`${size == 'xl' ? 'fs-2rem': 'fs-1dot2rem'}`}>Treasury Dashboard</p>
                        <img src={ArrowRight} alt="" height={30}/>
                    </div>
                    <div className='h-30'></div>
                </div>
            </Col>

        </Row>
    </div>
  )
}
