import { Col, Row } from "antd";
import React from "react";
import BaseButton from "../../component/BaseButton";
import ArrowRight from "../../asset/img/arrow-right.png";

export default function Tran2({size}) {
  return (
    <div className="cl-black mg-top-200">
      <Row>
        <Col xl={8} lg={8} md={0} xs={0} sm={0}>
          <p className="fs-1dot2rem" style={{ fontWeight: 600 }}>
            Policy
          </p>
          <p className="fs-1dot2rem" style={{ fontWeight: 600 }}>
            Governance flows
          </p>

          <p className="fs-1dot2rem" style={{ fontWeight: 600 }}>
            Audits
          </p>
        </Col>
        <Col xl={16} lg={16} md={24} xs={24} sm={24}>
          <p className={`${size == 'xl' || size == 'lg' ? 'fs-3rem': 'fs-2rem'} fw-bold`} >Policy Reports</p>
          <Row gutter={[24, 24]}>
            <Col xl={12} lg={12} md={24} xs={24} sm={24}>
              <div className="bg-cl-white pd-2rem bd-rad-30 cu-po trans-0dot3s hv-2">
                <p className="fs-0dot8rem cl-gray">JUNE 9, 2022</p>
                <p className="fs-1dot2rem">May 2022 Policy Report</p>
                <div style={{marginTop: 80}}>
                  <BaseButton
                    bgHv="black"
                    bgColor="white"
                    color="white"
                    px={20}
                    py={5}
                    bRad={20}
                    content={
                      <img src={ArrowRight} style={{ height: 26 }} alt="" />
                    }
                  />
                </div>
              </div>
            </Col>
            <Col xl={12} lg={12} md={24} xs={24} sm={24}>
              <div className="bg-cl-white pd-2rem bd-rad-30 cu-po trans-0dot3s hv-2">
                <p className="fs-0dot8rem cl-gray">JUNE 9, 2022</p>
                <p className="fs-1dot2rem">May 2022 Policy Report</p>
                <div style={{marginTop: 80}}>
                  <BaseButton
                    bgHv="black"
                    bgColor="white"
                    color="white"
                    px={20}
                    py={5}
                    bRad={20}
                    content={
                      <img src={ArrowRight} style={{ height: 26 }} alt="" />
                    }
                  />
                </div>
              </div>
            </Col>
            <Col xl={12} lg={12} md={24} xs={24} sm={24}>
              <div className="bg-cl-white pd-2rem bd-rad-30 cu-po trans-0dot3s hv-2">
                <p className="fs-0dot8rem cl-gray">JUNE 9, 2022</p>
                <p className="fs-1dot2rem">May 2022 Policy Report</p>
                <div style={{marginTop: 80}}>
                  <BaseButton
                    bgHv="black"
                    bgColor="white"
                    color="white"
                    px={20}
                    py={5}
                    bRad={20}
                    content={
                      <img src={ArrowRight} style={{ height: 26 }} alt="" />
                    }
                  />
                </div>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>
    </div>
  );
}
