import { Col, Row } from "antd";
import React, { useState } from "react";

export default function Tran1({size}) {

  const [isShown, setIsShown] = useState(false);
  const handleClick = event => {
    setIsShown(current => !current);
    setIsShown(true);
  };

  return (
    <div className="cl-black">
      <Row align="bottom" gutter={32}>
        <Col xl={8} lg={8} md={24}>
          <p className={`${size == 'xl' || size == 'lg' ? 'fs-3rem': 'fs-2rem'}  cl-gray fw-bold mg-0`}>Transparency</p>

          <p>
            CRYSTAL is committed to transparency, so the platform provides verified
            users with temporary read-only logins so that they can audit our numbers
            should they wish to do so independently. Click on "Generate Login" to create one now.
          </p>
        </Col>
        <Col xl={16} lg={16} md={24}>
            <div> 
            <button onClick={handleClick}>Click</button>
            </div>
            <Row className="bd-1-solid-black pd-2rem bd-rad-30" gutter={[,32]}>
                
                
                    <Col xl={8} lg={8} md={12} xs={12} sm={12}>
                        <p>Login URL (FTX)</p>
                        <p className={`${size == 'xl' || size == 'lg' ? 'fs-2rem': 'fs-1dot2rem'} fw-bold mg-0`}>
                          
                        <a href="https://ftx.com/login/KD90b4Sp" target="_blank" rel="noreferrer"> Click Here</a>
                        
                        </p>
                    </Col>
                    <Col xl={8} lg={8} md={12} xs={12} sm={12}>
                        <p>Password</p>
                        <p className={`${size == 'xl' || size == 'lg' ? 'fs-2rem': 'fs-1dot2rem'} fw-bold mg-0`}>ad@$hkafd2FD</p>
                    </Col>
                    <Col xl={8} lg={8} md={24} xs={24} sm={24}>
                        <p>Valid For</p>
                        <p className={`${size == 'xl' || size == 'lg' ? 'fs-2rem': 'fs-1dot2rem'} fw-bold mg-0`}>1 Hour</p>
                    </Col>
               
 

            </Row>
        </Col>
      </Row>
    </div>
  );
}
