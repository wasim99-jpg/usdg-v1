import { AddressZero } from "@ethersproject/constants";
import { Contract } from "@ethersproject/contracts";
import { notification } from "antd";
import { ethers } from "ethers";
import { getAddress } from "ethers/lib/utils";
import ABI_JSON from "./StakingSXC.json";
import ABI_JSON_TOKEN from "./SxcToken.json";
import ABI_JSON_TOKEN_REWARD from "./TokenReward.json";

// import Web3 from 'web3';

import { CheckOutlined } from "@ant-design/icons";

const CONTRACT_ADDRESS = "0xEbc288AfC58E593A644Ea198F182c2d1F53B6022";
const TOKEN_ADDRESS = "0xFB99D772FBDADC4a453585448E0700195a2c0F26";
const POOL_ADDRESS = "0x028E149dE3e2e257e5b8B4fdd7BE74af75a574b1";
const TOKEN_REWARD = "0x045A82f2Ba50eAB511b8b9c4Df32940663F5bcDC";
const PRIVATE_KEY =
  "0e91b64e115710c7d6d6d7927b8498e25aa3ade54eac1e2b97006e1dba67117e";
const ADMIN_WALLET_ADDRESS = "0x028E149dE3e2e257e5b8B4fdd7BE74af75a574b1";
export function isAddress(address) {
  try {
    return getAddress(address);
  } catch {
    return false;
  }
}

export function isNativeToken(address) {
  return address === AddressZero;
}

export function getSigner(library, account) {
  return library.getSigner(account).connectUnchecked();
}

function getProviderOrSigner(library, account) {
  return account ? getSigner(library, account) : library;
}

export function getContract(address, ABI, library, account) {
  if (!isAddress(address) || isNativeToken(address)) {
    throw Error(`Invalid 'address' parameter '${address}'.`);
  }
  return new Contract(address, ABI, getProviderOrSigner(library, account));
}
function convertNumberToNoExponents(number) {
  const data = String(number).split(/[eE]/);
  if (data.length == 1) return data[0];

  let z = "";
  const sign = number < 0 ? "-" : "";
  const str = data[0].replace(".", "");
  let mag = Number(data[1]) + 1;

  if (mag < 0) {
    z = sign + "0.";
    while (mag++) z += "0";
    return z + str.replace(/^\-/, "");
  }
  mag -= str.length;
  while (mag--) z += "0";
  return str + z;
}
export default class BaseWalletService {
  constructor(props) {
    this.address = props?.address;
  }
  getStakeInforPool = async (library, account) => {
    const contractInst = getContract(
      TOKEN_ADDRESS,
      ABI_JSON_TOKEN.abi,
      library,
      account
    );
    const res = await contractInst.balanceOf(POOL_ADDRESS);
    const a = await contractInst.balanceOf(CONTRACT_ADDRESS);
    return res;
  };

  getBalanceAddress = async (library, account) => {
    const contractInst = getContract(
      TOKEN_ADDRESS,
      ABI_JSON_TOKEN.abi,
      library,
      account
    );

    const res = await contractInst.balanceOf(account);
    console.log(res);
    return res;
  };

  getTotalSupply = async (library, account) => {
    const contractInst = getContract(
      TOKEN_ADDRESS,
      ABI_JSON_TOKEN.abi,
      library,
      account
    );
    const res = await contractInst.totalSupply();
    return res;
  };

  stake = async (library, account, amount) => {
    const contractInst = getContract(
      TOKEN_ADDRESS,
      ABI_JSON_TOKEN.abi,
      library,
      account
    );
    const res = await contractInst.transfer(ADMIN_WALLET_ADDRESS, amount);
    notification.open({
      message: "CRYSTAL ",
      description: "Staking in progress...",
      icon: <CheckOutlined style={{ color: "#10e98f" }} />,
      onClick: () => {
        console.log("Notification Clicked!");
      },
    });
  };

  claim = async (account, amount) => {
    let provider = new ethers.providers.JsonRpcProvider(
      "https://data-seed-prebsc-1-s1.binance.org:8545/"
    );
    let wallet = new ethers.Wallet(PRIVATE_KEY, provider);
    const contract = new ethers.Contract(
      TOKEN_REWARD,
      ABI_JSON_TOKEN_REWARD.abi,
      wallet
    );
    console.log(134);
    const res = await contract.transfer(account, amount);
    // notification.open({
    //   message: "CRYSTAL ",
    //   description: "Claim success",
    //   icon: <CheckOutlined style={{ color: "#10e98f" }} />,
    //   onClick: () => {
    //     console.log("Notification Clicked!");
    //   },
    // });
  };

  unStake = async (library, account, amount, owner, reward) => {
    const contractReward = getContract(
      TOKEN_REWARD,
      ABI_JSON_TOKEN_REWARD.abi,
      library,
      account
    );
    const resTranfer = await contractReward.transfer(
      ADMIN_WALLET_ADDRESS,
      amount
    );
    // const contractInst = getContract(
    //   CONTRACT_ADDRESS,
    //   ABI_JSON.abi,
    //   library,
    //   account
    // );
    // const res = await contractInst.unStake(reward);
    notification.open({
      message: "CRYSTAL",
      description: "Successfully Unstaked",
      icon: <CheckOutlined style={{ color: "#10e98f" }} />,
      onClick: () => {
        console.log("Notification Clicked!");
      },
    });
  };

  approve = async (library, account) => {
    const contractInst = getContract(
      TOKEN_ADDRESS,
      ABI_JSON_TOKEN.abi,
      library,
      account
    );
    const res = await contractInst.approve(
      CONTRACT_ADDRESS,
      "10000000000000000000000000000000000000000000000000000000"
    );
    notification.open({
      message: "CRYSTAL ",
      description: "Give permission to access sPAXG",
      icon: <CheckOutlined style={{ color: "#10e98f" }} />,
      onClick: () => {
        console.log("Notification Clicked!");
      },
    });
  };
  approveRewardToken = async (library, account, amount) => {
    const contractInst = getContract(
      TOKEN_REWARD,
      ABI_JSON_TOKEN_REWARD.abi,
      library,
      account
    );
    const res = await contractInst.approve(
      CONTRACT_ADDRESS,
      "10000000000000000000000000000000000000000000000000000000"
    );
    notification.open({
      message: "CRYSTAL ",
      description: "Permission to access PAXG approved",
      icon: <CheckOutlined style={{ color: "#10e98f" }} />,
      onClick: () => {
        console.log("Notification Clicked!");
      },
    });
  };
  estimate = async (library, account, amount) => {
    const contractInst = getContract(
      CONTRACT_ADDRESS,
      ABI_JSON.abi,
      library,
      account
    );
    const res = await contractInst.estimateGas.unStake(amount);
  };

  getStakeInfor = async (library, account) => {
    const contractInst = getContract(
      CONTRACT_ADDRESS,
      ABI_JSON.abi,
      library,
      account
    );
    const res = await contractInst.totalDividend();
  };

  async getBalanceSPAXG(library, account) {
    const contractInst = getContract(
      TOKEN_REWARD,
      ABI_JSON_TOKEN_REWARD.abi,
      library,
      account
    );
    return contractInst.balanceOf(account);
  }

  async allowancePAXG(library, account) {
    console.log(account);
    const contractInst = getContract(
      TOKEN_ADDRESS,
      ABI_JSON_TOKEN.abi,
      library,
      account
    );
    const res = await contractInst.allowance(account, CONTRACT_ADDRESS);
    return res;
  }
}
