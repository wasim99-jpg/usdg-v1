const axios = require("axios");

axios.defaults.baseURL = "http://45.118.144.93:3500";

export async function getCurrentIndex() {
  try {
    const response = await axios.get("usdg");
    return response.data;
  } catch (error) {
    console.error(error);
  }
}

export async function updateAPY(apy, fee, timeClaim) {
  try {
    const response = await axios.put("usdg", {
      APY: apy,
      fee,
      time: timeClaim,
    });
    return response.data;
  } catch (error) {
    console.error(error);
  }
}

export async function claimToken(account, amount) {
  try {
    const response = await axios.post("usdg/claim", {
      account,
      amount,
    });
    return response.data;
  } catch (error) {
    console.error(error);
  }
}

export async function unStakeFunc(account, amount) {
  try {
    const response = await axios.post("usdg/unstake", {
      account,
      amount,
    });
    return response.data;
  } catch (error) {
    console.error(error);
  }
}
