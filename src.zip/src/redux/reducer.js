const initialState = {
  address: "",
  balance: 0,
};

export const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    case "Connect_Wallet":
      return {
        ...state,
        address: action.payload.address,
      };
    case "GetBalance":
      return {
        ...state,
        balance: action.payload,
      };
    default:
      return state;
  }
};
