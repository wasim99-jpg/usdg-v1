export const Connect_Wallet = (address) => {
  return {
    type: "Connect_Wallet",
    payload: address,
  };
};

export const GetBalance = (balance) => {
  return {
    type: "GetBalance",
    payload: balance,
  };
};
